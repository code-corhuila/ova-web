/* =====================================================================
   OVA CORHUILA · base interaction (generic, template)
   Reading bar · scroll-spy nav · scroll-to-top · code tabs ·
   self-check quiz (data-correct / data-exp) · checklist persistence.
   Vanilla JS · no dependencies · SCORM-safe (self-contained).
   ===================================================================== */
document.addEventListener('DOMContentLoaded', () => {

    const bar = document.getElementById('readingBar');
    if (bar) window.addEventListener('scroll', () => {
        const h = document.documentElement;
        bar.style.width = Math.min(100, (h.scrollTop / (h.scrollHeight - h.clientHeight)) * 100) + '%';
    });

    const navLinks = Array.from(document.querySelectorAll('.main-nav a'));
    // getElementById NO lanza por sintaxis (querySelector('#1-...') sí); robusto ante cualquier id.
    const sections = navLinks.map(a => document.getElementById(a.getAttribute('href').slice(1))).filter(Boolean);
    if (sections.length) {
        const navUl = document.querySelector('.main-nav ul');
        const spy = () => {
            const y = window.scrollY + 140;
            let cur = sections[0];
            sections.forEach(s => { if (s.offsetTop <= y) cur = s; });
            navLinks.forEach(a => {
                const on = a.getAttribute('href') === '#' + (cur ? cur.id : '');
                a.classList.toggle('active', on);
                // La barra es de una sola fila con scroll horizontal: arrastra el
                // enlace activo a la vista para que no quede fuera del área visible.
                if (on && navUl && navUl.scrollWidth > navUl.clientWidth) {
                    const li = a.parentElement;
                    const izq = li.offsetLeft - navUl.clientWidth / 2 + li.offsetWidth / 2;
                    navUl.scrollTo({ left: Math.max(0, izq), behavior: 'smooth' });
                }
            });
        };
        window.addEventListener('scroll', spy); spy();
    }

    /* Encabezado que se esconde al bajar y reaparece al subir. Con 10+ secciones
       la barra fija robaba un tercio de la pantalla durante toda la lectura. */
    const header = document.querySelector('.main-header');
    if (header) {
        let ultimoY = window.scrollY;
        window.addEventListener('scroll', () => {
            const y = window.scrollY;
            const bajando = y > ultimoY;
            // No esconder cerca del tope, ni con el menú móvil abierto, ni por micro-movimientos.
            if (Math.abs(y - ultimoY) > 6 && y > 220 && !header.querySelector('.main-nav.open')) {
                header.classList.toggle('nav-hidden', bajando);
            } else if (y <= 220) {
                header.classList.remove('nav-hidden');
            }
            ultimoY = y;
        }, { passive: true });
        // Al saltar a una sección desde el menú, el encabezado debe quedar visible.
        navLinks.forEach(a => a.addEventListener('click', () => header.classList.remove('nav-hidden')));
    }

    const topBtn = document.getElementById('scrollTopBtn');
    if (topBtn) {
        window.addEventListener('scroll', () => { topBtn.style.display = window.scrollY > 320 ? 'block' : 'none'; });
        topBtn.addEventListener('click', () => window.scrollTo({ top: 0, behavior: 'smooth' }));
    }

    // Menú plegable (hamburguesa) en móvil
    const navToggle = document.querySelector('.nav-toggle');
    const mainNav = document.querySelector('.main-nav');
    if (navToggle && mainNav) {
        navToggle.addEventListener('click', () => {
            const open = mainNav.classList.toggle('open');
            navToggle.setAttribute('aria-expanded', open ? 'true' : 'false');
        });
        mainNav.querySelectorAll('a').forEach(a => a.addEventListener('click', () => {
            mainNav.classList.remove('open');
            navToggle.setAttribute('aria-expanded', 'false');
        }));
    }

    document.querySelectorAll('.tab-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            const id = btn.dataset.tab, t = btn.closest('.tabs');
            t.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
            t.querySelectorAll('.tab-panel').forEach(p => p.classList.remove('active'));
            btn.classList.add('active');
            const panel = document.getElementById(id);
            if (panel) panel.classList.add('active');
        });
    });

    const quiz = document.getElementById('quiz');
    if (quiz) {
        const _en = (document.documentElement.lang || 'es').toLowerCase() === 'en';
        const questions = Array.from(quiz.querySelectorAll('.q'));
        let answered = 0, correct = 0;
        const answeredEl = document.getElementById('quizAnswered');
        const showResult = () => {
            const res = document.getElementById('quizResult');
            if (!res) return;
            const sc = document.getElementById('quizScore');
            if (sc) sc.textContent = correct + '/' + questions.length;
            const msg = document.getElementById('quizMsg');
            if (msg) {
                if (correct === questions.length) msg.textContent = _en ? 'Excellent! You have mastered the topic.' : '¡Excelente! Dominas el tema.';
                else if (correct >= questions.length / 2) msg.textContent = _en ? 'Good. Review the points marked in red.' : 'Bien. Repasa los puntos marcados en rojo.';
                else msg.textContent = _en ? 'Review the content and try again.' : 'Repasa el contenido y vuelve a intentarlo.';
            }
            res.classList.add('show');
            res.scrollIntoView({ behavior: 'smooth', block: 'center' });
        };
        questions.forEach(q => {
            const opts = Array.from(q.querySelectorAll('.opt'));
            const fb = q.querySelector('.feedback');
            const exp = q.dataset.exp || '';
            // Shuffle option order on load (Fisher-Yates) so the correct answer
            // is not always first. Correctness travels with each option (data-c).
            for (let i = opts.length - 1; i > 0; i--) {
                const j = Math.floor(Math.random() * (i + 1));
                const tmp = opts[i]; opts[i] = opts[j]; opts[j] = tmp;
            }
            opts.forEach(o => q.insertBefore(o, fb));   // re-place in shuffled order
            const correctOpt = () => q.querySelector('.opt[data-c="1"]');
            opts.forEach(opt => {
                opt.addEventListener('click', () => {
                    if (q.dataset.done) return;
                    q.dataset.done = '1'; answered++;
                    if (answeredEl) answeredEl.textContent = answered;
                    opts.forEach(o => o.disabled = true);
                    const ok = correctOpt();
                    if (ok) ok.classList.add('correct');
                    if (opt.dataset.c === '1') {
                        correct++;
                        opt.insertAdjacentHTML('beforeend', '<span class="mark">✓</span>');
                        if (fb) { fb.className = 'feedback ok show'; fb.textContent = (_en ? 'Correct! ' : '¡Correcto! ') + exp; }
                    } else {
                        opt.classList.add('wrong');
                        opt.insertAdjacentHTML('beforeend', '<span class="mark">✕</span>');
                        if (ok) ok.insertAdjacentHTML('beforeend', '<span class="mark">✓</span>');
                        if (fb) { fb.className = 'feedback no show'; fb.textContent = (_en ? 'Review: ' : 'Revisa: ') + exp; }
                    }
                    if (answered === questions.length) showResult();
                });
            });
        });
    }

    document.querySelectorAll('.checklist input[type=checkbox]').forEach((b, i) => {
        const k = 'ova_chk_' + location.pathname + '_' + i;
        try { b.checked = localStorage.getItem(k) === '1'; } catch (e) {}
        b.addEventListener('change', () => { try { localStorage.setItem(k, b.checked ? '1' : '0'); } catch (e) {} });
    });
});
