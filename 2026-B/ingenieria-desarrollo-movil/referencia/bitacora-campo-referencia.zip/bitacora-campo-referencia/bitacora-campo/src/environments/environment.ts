// Desarrollo (ng serve, ng build --configuration development, cap run android).
// apiUrl: null => la URL se decide por plataforma en core/network/api-url.ts
// (10.0.2.2:3000 en el emulador de Android, localhost:3000 en el navegador).
// Teléfono físico: escriba aquí 'http://<IP-del-computador>:3000'.
export const environment = {
  production: false,
  apiUrl: null as string | null,
};
