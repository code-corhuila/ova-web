// Producción (ng build, que usa la configuración "production" de angular.json).
// La API va SIEMPRE por HTTPS: el build de release no permite tráfico en texto plano.
// Reemplace el dominio .example (reservado) por el backend real del proyecto.
export const environment = {
  production: true,
  apiUrl: 'https://api.bitacora-campo.example' as string | null,
};
