/** Valor guardado en la caché junto con el instante en que se guardó. */
export interface EntradaCache<T> {
  readonly valor: T;
  /** ISO 8601 */
  readonly guardadoEn: string;
}

/**
 * Puerto: caché de lectura clave/valor para trabajar sin conexión (ADR-002).
 * No guarda secretos: para eso está TokenStore.
 */
export interface CacheLocal {
  leer<T>(clave: string): Promise<EntradaCache<T> | null>;
  guardar<T>(clave: string, valor: T): Promise<void>;
  /** Borra todo lo de la caché (se llama al cerrar sesión). */
  limpiar(): Promise<void>;
}
