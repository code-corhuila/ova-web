/**
 * Puerto: capacidad de tomar una foto. TypeScript puro.
 * El caso de uso CapturarEvidencia depende de esta interfaz, nunca del plugin.
 */
export interface Camara {
  /**
   * Abre la cámara y devuelve la foto como data URL (`data:image/jpeg;base64,...`).
   * @throws PermisoDenegadoError si la persona niega el permiso.
   */
  tomarFoto(): Promise<string>;
}
