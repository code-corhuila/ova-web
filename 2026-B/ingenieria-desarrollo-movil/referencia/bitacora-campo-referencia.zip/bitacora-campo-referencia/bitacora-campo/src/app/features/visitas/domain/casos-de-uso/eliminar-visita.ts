import { ErrorValidacion } from '../../../../core/errores/errores-dominio';
import { MENSAJE_REALIZADA_NO_SE_ELIMINA } from '../reglas-visita';
import { Visita } from '../visita';
import { VisitasRepository } from '../visitas.repository';

/** Caso de uso: eliminar una visita. Regla: las realizadas son registro histórico y no se borran. */
export class EliminarVisita {
  constructor(private readonly repositorio: VisitasRepository) {}

  async ejecutar(visita: Visita): Promise<void> {
    if (visita.estado === 'realizada') throw new ErrorValidacion(MENSAJE_REALIZADA_NO_SE_ELIMINA);
    await this.repositorio.eliminar(visita.id);
  }
}
