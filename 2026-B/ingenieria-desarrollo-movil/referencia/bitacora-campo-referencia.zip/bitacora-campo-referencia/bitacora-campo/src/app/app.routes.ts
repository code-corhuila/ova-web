import { Routes } from '@angular/router';
import { authGuard, invitadoGuard } from './core/sesion/auth.guard';
import { provideVisitas } from './core/di/visitas.providers';

/**
 * TABLA DE RUTAS CENTRAL — única fuente de verdad de qué pantallas existen y cómo se llega a
 * ellas. Debe coincidir con docs/01-arquitectura/navegacion.md.
 *
 * - El guard se declara AQUÍ, una vez, para todo el grupo /visitas; ninguna pantalla revisa la sesión.
 * - Las rutas pasan identificadores (:id), nunca objetos; el destino vuelve a pedir el dato.
 * - Cada pantalla se carga perezosamente (loadComponent): el bundle inicial no las incluye.
 */
export const routes: Routes = [
  { path: '', redirectTo: 'visitas', pathMatch: 'full' },
  {
    path: 'login',
    canActivate: [invitadoGuard],
    loadComponent: () => import('./features/auth/presentation/login/login.page').then((m) => m.LoginPage),
  },
  {
    path: 'visitas',
    canActivate: [authGuard],
    providers: [provideVisitas()],
    children: [
      {
        path: '',
        loadComponent: () => import('./features/visitas/presentation/lista/visitas-lista.page').then((m) => m.VisitasListaPage),
      },
      {
        path: 'nueva',
        loadComponent: () => import('./features/visitas/presentation/form/visita-form.page').then((m) => m.VisitaFormPage),
      },
      {
        path: ':id',
        loadComponent: () => import('./features/visitas/presentation/form/visita-form.page').then((m) => m.VisitaFormPage),
      },
    ],
  },
  { path: '**', redirectTo: 'visitas' },
];
