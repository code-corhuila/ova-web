import { provideHttpClient, withInterceptors } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { ErrorServidor, ErrorSinConexion } from '../../../core/errores/errores-dominio';
import { API_URL } from '../../../core/network/api-url';
import { erroresInterceptor } from '../../../core/network/errores.interceptor';
import { CACHE_LOCAL } from '../../../core/storage/storage.tokens';
import { CacheLocalFalsa } from '../../../../testing/almacenamiento.falso';
import { unDto, unaVisita } from '../../../../testing/visitas.ejemplo';
import { CLAVE_CACHE_VISITAS, VisitasHttpRepository } from './visitas-http.repository';

describe('VisitasHttpRepository', () => {
  let repo: VisitasHttpRepository;
  let http: HttpTestingController;
  let cache: CacheLocalFalsa;

  beforeEach(() => {
    cache = new CacheLocalFalsa('2026-10-05T12:00:00.000Z');
    TestBed.configureTestingModule({
      providers: [
        // Con el interceptor de errores real: el repositorio recibe errores de dominio, como en la app.
        provideHttpClient(withInterceptors([erroresInterceptor])),
        provideHttpClientTesting(),
        { provide: API_URL, useValue: 'http://api' },
        { provide: CACHE_LOCAL, useValue: cache },
      ],
    });
    repo = TestBed.inject(VisitasHttpRepository);
    http = TestBed.inject(HttpTestingController);
  });
  afterEach(() => http.verify());

  async function errorDe(p: Promise<unknown>): Promise<unknown> {
    try {
      await p;
    } catch (e) {
      return e;
    }
    return null;
  }

  it('listar_enLinea_mapeaAlDominioYGuardaLaRespuestaEnCache', async () => {
    const p = repo.listar();
    http.expectOne('http://api/visitas').flush([unDto({ id: 'a' })]);

    const lista = await p;

    expect(lista.desactualizado).toBe(false);
    expect(lista.visitas[0].id).toBe('a');
    expect(lista.visitas[0].creadaEn instanceof Date).toBe(true);
    expect((await cache.leer<unknown[]>(CLAVE_CACHE_VISITAS))?.valor.length).toBe(1);
  });

  it('listar_sinConexionConCache_devuelveLoGuardadoMarcadoDesactualizado', async () => {
    await cache.guardar(CLAVE_CACHE_VISITAS, [unDto({ id: 'guardada' })]);

    const p = repo.listar();
    http.expectOne('http://api/visitas').error(new ProgressEvent('error'));
    const lista = await p;

    expect(lista.desactualizado).toBe(true);
    expect(lista.visitas.map((v) => v.id)).toEqual(['guardada']);
    expect(lista.sincronizadoEn).toEqual(new Date('2026-10-05T12:00:00.000Z'));
  });

  it('listar_sinConexionNiCache_lanzaErrorSinConexion', async () => {
    const p = repo.listar();
    http.expectOne('http://api/visitas').error(new ProgressEvent('error'));

    expect((await errorDe(p)) instanceof ErrorSinConexion).toBe(true);
  });

  it('listar_conError500_noUsaLaCacheYPropagaErrorServidor', async () => {
    await cache.guardar(CLAVE_CACHE_VISITAS, [unDto()]);

    const p = repo.listar();
    http.expectOne('http://api/visitas').flush({ error: 'x' }, { status: 500, statusText: 'Error' });

    expect((await errorDe(p)) instanceof ErrorServidor).toBe(true);
  });

  it('crear_enviaElDtoDeEntradaYAgregaLaVisitaALaCache', async () => {
    await cache.guardar(CLAVE_CACHE_VISITAS, [unDto({ id: 'a' })]);
    const datos = unaVisita({ cliente: 'Nuevo cliente', ubicacion: { lat: 2, lng: -75 } });

    const p = repo.crear(datos);
    await Promise.resolve();
    const req = http.expectOne('http://api/visitas');
    expect(req.request.method).toBe('POST');
    expect(req.request.body.lat).toBe(2);
    expect(req.request.body.cliente).toBe('Nuevo cliente');
    req.flush(unDto({ id: 'n1', cliente: 'Nuevo cliente', lat: 2, lng: -75 }));
    const creada = await p;

    expect(creada.id).toBe('n1');
    const ids = (await cache.leer<{ id: string }[]>(CLAVE_CACHE_VISITAS))?.valor.map((v) => v.id);
    expect(ids).toEqual(['a', 'n1']);
  });

  it('eliminar_quitaLaVisitaDeLaCache', async () => {
    await cache.guardar(CLAVE_CACHE_VISITAS, [unDto({ id: 'a' }), unDto({ id: 'b' })]);

    const p = repo.eliminar('a');
    const req = http.expectOne('http://api/visitas/a');
    expect(req.request.method).toBe('DELETE');
    req.flush(null, { status: 204, statusText: 'No Content' });
    await p;

    const ids = (await cache.leer<{ id: string }[]>(CLAVE_CACHE_VISITAS))?.valor.map((v) => v.id);
    expect(ids).toEqual(['b']);
  });
});
