import { Sesion } from './sesion';

/** Puerto del dominio de autenticación. La implementación vive en data/auth-http.repository.ts. */
export interface AuthRepository {
  /** @throws CredencialesInvalidasError si el usuario o la clave no coinciden. */
  iniciarSesion(usuario: string, clave: string): Promise<Sesion>;
  cerrarSesion(): Promise<void>;
}
