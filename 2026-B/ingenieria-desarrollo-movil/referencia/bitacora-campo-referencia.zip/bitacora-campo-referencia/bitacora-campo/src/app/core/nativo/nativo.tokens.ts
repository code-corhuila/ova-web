import { InjectionToken } from '@angular/core';
import { Camara } from './camara.port';
import { CamaraCapacitor } from './camara-capacitor';
import { Ubicacion } from './ubicacion.port';
import { UbicacionCapacitor } from './ubicacion-capacitor';

/** Puerto Camara → adaptador Capacitor. Las pruebas lo reemplazan por una cámara falsa. */
export const CAMARA = new InjectionToken<Camara>('CAMARA', {
  providedIn: 'root',
  factory: () => new CamaraCapacitor(),
});

/** Puerto Ubicacion → adaptador Capacitor. */
export const UBICACION = new InjectionToken<Ubicacion>('UBICACION', {
  providedIn: 'root',
  factory: () => new UbicacionCapacitor(),
});
