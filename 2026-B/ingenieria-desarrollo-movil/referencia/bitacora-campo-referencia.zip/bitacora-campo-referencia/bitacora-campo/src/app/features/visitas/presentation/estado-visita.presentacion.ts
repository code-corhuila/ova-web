import { EstadoVisita } from '../domain/visita';

/** Cómo se MUESTRA cada estado (asunto de presentación, por eso no está en domain/). */
export const ETIQUETA_ESTADO: Readonly<Record<EstadoVisita, string>> = {
  pendiente: 'Pendiente',
  realizada: 'Realizada',
  cancelada: 'Cancelada',
};

/** Colores de Ionic. El badge muestra además el texto: el color nunca es el único indicador. */
export const COLOR_ESTADO: Readonly<Record<EstadoVisita, string>> = {
  pendiente: 'warning',
  realizada: 'success',
  cancelada: 'medium',
};
