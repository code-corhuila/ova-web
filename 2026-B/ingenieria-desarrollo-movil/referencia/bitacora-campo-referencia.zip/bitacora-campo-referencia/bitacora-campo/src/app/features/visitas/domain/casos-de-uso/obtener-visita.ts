import { ErrorValidacion } from '../../../../core/errores/errores-dominio';
import { Visita } from '../visita';
import { VisitasRepository } from '../visitas.repository';

/** Caso de uso: traer una visita por id (las rutas pasan ids, no objetos; ver navegacion.md). */
export class ObtenerVisita {
  constructor(private readonly repositorio: VisitasRepository) {}

  ejecutar(id: string): Promise<Visita> {
    if (id.trim().length === 0) return Promise.reject(new ErrorValidacion('Falta el id de la visita.'));
    return this.repositorio.obtener(id);
  }
}
