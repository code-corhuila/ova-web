import { ScrollingModule } from '@angular/cdk/scrolling';
import { Component, effect, inject, signal } from '@angular/core';
import { RouterLink } from '@angular/router';
import {
  IonBadge,
  IonButton,
  IonButtons,
  IonContent,
  IonFab,
  IonFabButton,
  IonHeader,
  IonIcon,
  IonItem,
  IonItemOption,
  IonItemOptions,
  IonItemSliding,
  IonLabel,
  IonList,
  IonMenuButton,
  IonModal,
  IonRefresher,
  IonRefresherContent,
  IonSpinner,
  IonTitle,
  IonToolbar,
  RefresherCustomEvent,
  ToastController,
} from '@ionic/angular';
import { addIcons } from 'ionicons';
import { add, helpCircleOutline, trash } from 'ionicons/icons';
import { BannerOfflineComponent } from '../../../../shared/banner-offline/banner-offline.component';
import { EstadoVacioComponent } from '../../../../shared/estado-vacio/estado-vacio.component';
import { MensajeErrorComponent } from '../../../../shared/mensaje-error/mensaje-error.component';
import { Visita } from '../../domain/visita';
import { COLOR_ESTADO, ETIQUETA_ESTADO } from '../estado-visita.presentacion';
import { VisitasListaViewModel } from './visitas-lista.view-model';

/** Alto fijo de cada fila: lo necesita el virtual scroll (coincide con --bc-alto-item-lista). */
export const ALTO_ITEM_PX = 72;

/**
 * Pantalla /visitas. Renderiza el estado del ViewModel y le delega cada intención.
 * Lista con virtual scroll (@angular/cdk): solo existen en el DOM las filas visibles.
 */
@Component({
  selector: 'app-visitas-lista',
  templateUrl: './visitas-lista.page.html',
  styleUrl: './visitas-lista.page.scss',
  providers: [VisitasListaViewModel],
  imports: [
    RouterLink,
    ScrollingModule,
    IonHeader,
    IonToolbar,
    IonTitle,
    IonButtons,
    IonButton,
    IonMenuButton,
    IonContent,
    IonRefresher,
    IonRefresherContent,
    IonList,
    IonItemSliding,
    IonItem,
    IonLabel,
    IonBadge,
    IonItemOptions,
    IonItemOption,
    IonIcon,
    IonFab,
    IonFabButton,
    IonSpinner,
    IonModal,
    EstadoVacioComponent,
    MensajeErrorComponent,
    BannerOfflineComponent,
  ],
})
export class VisitasListaPage {
  private readonly toasts = inject(ToastController);
  protected readonly vm = inject(VisitasListaViewModel);
  protected readonly estado = this.vm.estado;
  protected readonly ayudaAbierta = signal(false);
  protected readonly altoItem = ALTO_ITEM_PX;
  protected readonly color = COLOR_ESTADO;
  protected readonly etiqueta = ETIQUETA_ESTADO;
  protected readonly porId = (_: number, v: Visita) => v.id;

  constructor() {
    addIcons({ add, trash, helpCircleOutline });
    effect(() => {
      const aviso = this.estado().aviso;
      if (aviso) void this.mostrarAviso(aviso);
    });
  }

  /** Ciclo de vida de Ionic: corre cada vez que la pantalla vuelve a primer plano (p. ej. tras guardar). */
  ionViewWillEnter(): void {
    void this.vm.cargar();
  }

  async refrescar(evento: RefresherCustomEvent): Promise<void> {
    await this.vm.cargar();
    await evento.target.complete();
  }

  async eliminar(visita: Visita, deslizable: IonItemSliding): Promise<void> {
    await deslizable.close();
    await this.vm.eliminar(visita);
  }

  private async mostrarAviso(mensaje: string): Promise<void> {
    this.vm.descartarAviso();
    const toast = await this.toasts.create({ message: mensaje, duration: 2500, position: 'bottom' });
    await toast.present();
  }
}
