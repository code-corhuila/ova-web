import { ErrorValidacion } from '../../../../core/errores/errores-dominio';
import { VisitasRepositoryFalso } from '../../../../../testing/visitas-repository.falso';
import { DatosVisita } from '../visita';
import { ActualizarVisita } from './actualizar-visita';

describe('ActualizarVisita', () => {
  const base: DatosVisita = {
    cliente: 'Piscícola Betania',
    direccion: '',
    estado: 'cancelada',
    observaciones: ' Reprogramar ',
    foto: null,
    ubicacion: null,
  };

  it('actualizar_conDatosValidos_enviaElIdYLosDatosNormalizados', async () => {
    const repo = new VisitasRepositoryFalso();

    await new ActualizarVisita(repo).ejecutar('s3', base);

    expect(repo.actualizadas).toEqual([{ id: 's3', datos: { ...base, observaciones: 'Reprogramar' } }]);
  });

  it('actualizar_conObservacionesDemasiadoLargas_lanzaErrorValidacion', async () => {
    const repo = new VisitasRepositoryFalso();
    let error: unknown = null;

    try {
      await new ActualizarVisita(repo).ejecutar('s3', { ...base, observaciones: 'x'.repeat(501) });
    } catch (e) {
      error = e;
    }

    expect(error instanceof ErrorValidacion).toBe(true);
    expect(repo.actualizadas.length).toBe(0);
  });
});
