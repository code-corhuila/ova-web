import { DecimalPipe } from '@angular/common';
import { Component, OnInit, inject, input } from '@angular/core';
import { NonNullableFormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import {
  IonBackButton,
  IonButton,
  IonButtons,
  IonContent,
  IonHeader,
  IonIcon,
  IonInput,
  IonItem,
  IonList,
  IonNote,
  IonSelect,
  IonSelectOption,
  IonSpinner,
  IonText,
  IonTextarea,
  IonTitle,
  IonToolbar,
  NavController,
} from '@ionic/angular';
import { addIcons } from 'ionicons';
import { cameraOutline, locationOutline } from 'ionicons/icons';
import { MensajeErrorComponent } from '../../../../shared/mensaje-error/mensaje-error.component';
import { LIMITES_VISITA } from '../../domain/reglas-visita';
import { ESTADOS_VISITA, EstadoVisita } from '../../domain/visita';
import { ETIQUETA_ESTADO } from '../estado-visita.presentacion';
import { sinSoloEspacios } from './validadores';
import { VisitaFormViewModel } from './visita-form.view-model';

/** Pantalla /visitas/nueva y /visitas/:id. El formulario reactivo es estado de la vista; las reglas, del dominio. */
@Component({
  selector: 'app-visita-form',
  templateUrl: './visita-form.page.html',
  styleUrl: './visita-form.page.scss',
  providers: [VisitaFormViewModel],
  imports: [
    ReactiveFormsModule,
    DecimalPipe,
    IonHeader,
    IonToolbar,
    IonTitle,
    IonButtons,
    IonBackButton,
    IonContent,
    IonList,
    IonItem,
    IonInput,
    IonTextarea,
    IonSelect,
    IonSelectOption,
    IonButton,
    IonIcon,
    IonNote,
    IonText,
    IonSpinner,
    MensajeErrorComponent,
  ],
})
export class VisitaFormPage implements OnInit {
  /** Parámetro :id de la ruta (withComponentInputBinding). Ausente en /visitas/nueva. */
  readonly id = input<string>();

  private readonly fb = inject(NonNullableFormBuilder);
  private readonly nav = inject(NavController);
  protected readonly vm = inject(VisitaFormViewModel);
  protected readonly estado = this.vm.estado;
  protected readonly estados = ESTADOS_VISITA;
  protected readonly etiqueta = ETIQUETA_ESTADO;
  protected readonly limites = LIMITES_VISITA;

  protected readonly form = this.fb.group({
    cliente: ['', [Validators.required, Validators.minLength(LIMITES_VISITA.clienteMin), Validators.maxLength(LIMITES_VISITA.clienteMax), sinSoloEspacios]],
    direccion: ['', Validators.maxLength(LIMITES_VISITA.direccionMax)],
    estado: this.fb.control<EstadoVisita>('pendiente', Validators.required),
    observaciones: ['', Validators.maxLength(LIMITES_VISITA.observacionesMax)],
  });

  constructor() {
    addIcons({ cameraOutline, locationOutline });
  }

  async ngOnInit(): Promise<void> {
    await this.cargar();
  }

  async cargar(): Promise<void> {
    const campos = await this.vm.iniciar(this.id() ?? null);
    if (campos) this.form.setValue(campos);
  }

  async guardar(): Promise<void> {
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }
    if (await this.vm.guardar(this.form.getRawValue())) await this.nav.navigateBack('/visitas');
  }
}
