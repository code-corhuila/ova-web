import { FormControl } from '@angular/forms';
import { sinSoloEspacios } from './validadores';

describe('sinSoloEspacios', () => {
  it('validar_textoDeSoloEspacios_devuelveErrorSoloEspacios', () => {
    expect(sinSoloEspacios(new FormControl('   '))).toEqual({ soloEspacios: true });
  });

  it('validar_textoReal_esValido', () => {
    expect(sinSoloEspacios(new FormControl(' Acueducto '))).toBeNull();
  });

  it('validar_textoVacio_loDejaARequired', () => {
    expect(sinSoloEspacios(new FormControl(''))).toBeNull();
  });
});
