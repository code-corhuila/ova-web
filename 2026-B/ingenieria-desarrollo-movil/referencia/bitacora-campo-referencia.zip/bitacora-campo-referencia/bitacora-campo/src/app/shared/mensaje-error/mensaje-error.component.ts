import { ChangeDetectionStrategy, Component, input, output } from '@angular/core';
import { IonButton, IonIcon } from '@ionic/angular';
import { addIcons } from 'ionicons';
import { alertCircleOutline } from 'ionicons/icons';

/** Error bloqueante con acción de recuperación (toda falla visible tiene mensaje Y acción). */
@Component({
  selector: 'app-mensaje-error',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [IonIcon, IonButton],
  template: `
    <div class="mensaje-error" role="alert">
      <ion-icon name="alert-circle-outline" color="danger" aria-hidden="true"></ion-icon>
      <p>{{ mensaje() }}</p>
      <ion-button (click)="reintentar.emit()">Reintentar</ion-button>
    </div>
  `,
  styles: `
    .mensaje-error { display: flex; flex-direction: column; align-items: center; gap: var(--bc-espacio-md);
      padding: var(--bc-espacio-xl) var(--bc-espacio-lg); text-align: center; }
    ion-icon { font-size: 48px; }
    p { margin: 0; color: var(--bc-color-texto); }
    ion-button { min-height: var(--bc-alto-minimo-toque); }
  `,
})
export class MensajeErrorComponent {
  readonly mensaje = input.required<string>();
  readonly reintentar = output<void>();

  constructor() {
    addIcons({ alertCircleOutline });
  }
}
