import type { Camara } from '../../../../core/nativo/camara.port';
import { PermisoDenegadoError } from '../../../../core/nativo/permiso-denegado.error';
import type { Ubicacion } from '../../../../core/nativo/ubicacion.port';
import { Coordenadas } from '../visita';

export interface Evidencia {
  readonly foto: string;
  readonly ubicacion: Coordenadas | null;
  /** Mensaje para la persona cuando la ubicación no se pudo obtener. */
  readonly aviso: string | null;
}

export const AVISO_SIN_UBICACION = 'No se pudo obtener la ubicación; la visita se guarda sin coordenadas.';

/**
 * Caso de uso: capturar la evidencia de una visita.
 * - La FOTO es obligatoria: si la cámara falla (o se niega el permiso) el error se propaga.
 * - La UBICACIÓN es «mejor esfuerzo»: si falla, se conserva la foto y se devuelve un aviso.
 * Depende de los puertos Camara y Ubicacion, nunca de los plugins de Capacitor.
 */
export class CapturarEvidencia {
  constructor(
    private readonly camara: Camara,
    private readonly ubicacion: Ubicacion,
  ) {}

  async ejecutar(): Promise<Evidencia> {
    const foto = await this.camara.tomarFoto();
    try {
      return { foto, ubicacion: await this.ubicacion.obtenerActual(), aviso: null };
    } catch (e) {
      const aviso = e instanceof PermisoDenegadoError ? e.message : AVISO_SIN_UBICACION;
      return { foto, ubicacion: null, aviso };
    }
  }
}
