import { TestBed } from '@angular/core/testing';
import { AuthRepositoryFalso } from '../../../../../testing/auth-repository.falso';
import { CredencialesInvalidasError } from '../../domain/credenciales-invalidas.error';
import { IniciarSesion } from '../../domain/iniciar-sesion';
import { ESTADO_LOGIN_INICIAL, EstadoLogin, LoginViewModel } from './login.view-model';

describe('LoginViewModel', () => {
  let repo: AuthRepositoryFalso;
  let vm: LoginViewModel;

  beforeEach(() => {
    repo = new AuthRepositoryFalso();
    TestBed.configureTestingModule({
      providers: [LoginViewModel, { provide: IniciarSesion, useValue: new IniciarSesion(repo) }],
    });
    vm = TestBed.inject(LoginViewModel);
  });

  it('estado_alCrear_esInicial', () => {
    expect(vm.estado()).toEqual(ESTADO_LOGIN_INICIAL);
  });

  it('ingresar_credencialesValidas_pasaPorEnviandoYTerminaEnExito', async () => {
    const fases: EstadoLogin['fase'][] = [];
    const p = vm.ingresar('tecnico', 'campo123');
    fases.push(vm.estado().fase);

    expect(await p).toBe(true);
    fases.push(vm.estado().fase);
    expect(fases).toEqual(['enviando', 'exito']);
    expect(vm.estado().nombre).toBe('Técnica de campo');
  });

  it('ingresar_credencialesInvalidas_terminaEnErrorConMensajeClaro', async () => {
    repo.error = new CredencialesInvalidasError();

    expect(await vm.ingresar('tecnico', 'otraclave')).toBe(false);
    expect(vm.estado()).toEqual({ fase: 'error', error: 'Usuario o clave incorrectos.', nombre: null });
  });
});
