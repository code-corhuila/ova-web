import { DestroyRef, Injectable, inject } from '@angular/core';
import { toSignal } from '@angular/core/rxjs-interop';
import { BehaviorSubject } from 'rxjs';
import { mensajeDeError } from '../../../../core/errores/errores-dominio';
import { EliminarVisita } from '../../domain/casos-de-uso/eliminar-visita';
import { ListarVisitas } from '../../domain/casos-de-uso/listar-visitas';
import { ResumenVisitas, resumirVisitas } from '../../domain/reglas-visita';
import { ListaVisitas, Visita } from '../../domain/visita';

/** Fases de la pantalla: exactamente una a la vez (01-arquitectura/feature-visitas.md). */
export type FaseLista = 'cargando' | 'cargado' | 'vacio' | 'error' | 'offline';

/** Estado inmutable de la lista. La pantalla renderiza SOLO a partir de este objeto. */
export interface EstadoLista {
  readonly fase: FaseLista;
  readonly visitas: readonly Visita[];
  readonly resumen: ResumenVisitas;
  /** Mensaje del estado `error` (bloqueante). */
  readonly error: string | null;
  /** Cuándo se sincronizó; en `offline` es la fecha de la caché. */
  readonly sincronizadoEn: Date | null;
  /** Mensaje transitorio (toast): eliminada, no se pudo eliminar, no se pudo refrescar... */
  readonly aviso: string | null;
}

export const ESTADO_LISTA_INICIAL: EstadoLista = {
  fase: 'cargando',
  visitas: [],
  resumen: resumirVisitas([]),
  error: null,
  sincronizadoEn: null,
  aviso: null,
};

/**
 * ViewModel de /visitas (ADR-001: MVVM con estado inmutable).
 * - El estado vive en un BehaviorSubject PRIVADO; la vista lo lee como signal (toSignal).
 * - Toda transición crea un objeto nuevo ({...previo, cambio}); nada se muta.
 * - Se provee a nivel de componente: nace y muere con la pantalla. Al destruirse ignora
 *   respuestas tardías; si llegan dos cargas, gana la más reciente.
 */
@Injectable()
export class VisitasListaViewModel {
  private readonly listarVisitas = inject(ListarVisitas);
  private readonly eliminarVisita = inject(EliminarVisita);
  private readonly estado$ = new BehaviorSubject<EstadoLista>(ESTADO_LISTA_INICIAL);
  private ultimaCarga = 0;
  private activo = true;

  readonly estado = toSignal(this.estado$, { requireSync: true });

  constructor() {
    inject(DestroyRef).onDestroy(() => (this.activo = false));
  }

  async cargar(): Promise<void> {
    const carga = ++this.ultimaCarga;
    const previo = this.estado$.value;
    const hayDatosEnPantalla = previo.visitas.length > 0;
    if (!hayDatosEnPantalla) this.emitir({ ...previo, fase: 'cargando', error: null });
    try {
      const lista = await this.listarVisitas.ejecutar();
      if (carga === this.ultimaCarga) this.emitir(estadoDesde(lista));
    } catch (e) {
      if (carga !== this.ultimaCarga) return;
      // Con datos en pantalla, un fallo al refrescar no borra la lista: solo avisa.
      this.emitir(
        hayDatosEnPantalla
          ? { ...this.estado$.value, aviso: mensajeDeError(e) }
          : { ...ESTADO_LISTA_INICIAL, fase: 'error', error: mensajeDeError(e) },
      );
    }
  }

  async eliminar(visita: Visita): Promise<void> {
    try {
      await this.eliminarVisita.ejecutar(visita);
      const previo = this.estado$.value;
      const visitas = previo.visitas.filter((v) => v.id !== visita.id);
      const fase: FaseLista = visitas.length === 0 && previo.fase === 'cargado' ? 'vacio' : previo.fase;
      this.emitir({ ...previo, fase, visitas, resumen: resumirVisitas(visitas), aviso: 'Visita eliminada.' });
    } catch (e) {
      this.emitir({ ...this.estado$.value, aviso: mensajeDeError(e) });
    }
  }

  descartarAviso(): void {
    if (this.estado$.value.aviso !== null) this.emitir({ ...this.estado$.value, aviso: null });
  }

  private emitir(estado: EstadoLista): void {
    if (this.activo) this.estado$.next(estado);
  }
}

function estadoDesde(lista: ListaVisitas): EstadoLista {
  const base = {
    visitas: lista.visitas,
    resumen: resumirVisitas(lista.visitas),
    error: null,
    sincronizadoEn: lista.sincronizadoEn,
    aviso: null,
  };
  if (lista.desactualizado) return { ...base, fase: 'offline' };
  return { ...base, fase: lista.visitas.length === 0 ? 'vacio' : 'cargado' };
}
