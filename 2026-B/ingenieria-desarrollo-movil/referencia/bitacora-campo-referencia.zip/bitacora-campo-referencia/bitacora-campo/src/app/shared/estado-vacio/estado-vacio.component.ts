import { ChangeDetectionStrategy, Component, input, output } from '@angular/core';
import { IonButton, IonIcon } from '@ionic/angular';
import { addIcons } from 'ionicons';
import { documentTextOutline } from 'ionicons/icons';

/** Estado vacío reutilizable: ícono + mensaje + acción opcional. Solo presentación. */
@Component({
  selector: 'app-estado-vacio',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [IonIcon, IonButton],
  template: `
    <div class="estado-vacio" role="status">
      <ion-icon name="document-text-outline" aria-hidden="true"></ion-icon>
      <p>{{ mensaje() }}</p>
      @if (accion(); as texto) {
        <ion-button fill="outline" (click)="accionar.emit()">{{ texto }}</ion-button>
      }
    </div>
  `,
  styles: `
    .estado-vacio { display: flex; flex-direction: column; align-items: center; gap: var(--bc-espacio-md);
      padding: var(--bc-espacio-xl) var(--bc-espacio-lg); text-align: center; color: var(--bc-color-texto-suave); }
    ion-icon { font-size: 48px; }
    p { margin: 0; font-size: var(--bc-texto-cuerpo); }
    ion-button { min-height: var(--bc-alto-minimo-toque); }
  `,
})
export class EstadoVacioComponent {
  readonly mensaje = input.required<string>();
  readonly accion = input<string | null>(null);
  readonly accionar = output<void>();

  constructor() {
    addIcons({ documentTextOutline });
  }
}
