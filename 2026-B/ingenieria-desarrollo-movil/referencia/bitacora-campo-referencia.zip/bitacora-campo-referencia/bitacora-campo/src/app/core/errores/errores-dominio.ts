/**
 * Errores de dominio compartidos por toda la app.
 *
 * TypeScript puro (sin Angular, sin HttpClient, sin Capacitor): los puede importar `domain/`.
 * La capa de red traduce los errores técnicos (HttpErrorResponse, TimeoutError) a estos tipos
 * en `core/network/mapear-error-http.ts`, así ninguna pantalla ve un error HTTP crudo.
 */
export abstract class ErrorDominio extends Error {
  /** Código estable para lógica y analítica; el `message` es el texto para la persona usuaria. */
  abstract readonly codigo: string;
}

export class ErrorSinConexion extends ErrorDominio {
  readonly codigo = 'SIN_CONEXION';
  constructor() {
    super('No hay conexión con el servidor.');
  }
}

export class ErrorTiempoAgotado extends ErrorDominio {
  readonly codigo = 'TIEMPO_AGOTADO';
  constructor() {
    super('El servidor tardó demasiado en responder.');
  }
}

export class ErrorSesionExpirada extends ErrorDominio {
  readonly codigo = 'SESION_EXPIRADA';
  constructor() {
    super('Tu sesión expiró. Ingresa de nuevo.');
  }
}

export class ErrorValidacion extends ErrorDominio {
  readonly codigo = 'VALIDACION';
}

export class ErrorNoEncontrado extends ErrorDominio {
  readonly codigo = 'NO_ENCONTRADO';
  constructor() {
    super('El registro ya no existe.');
  }
}

export class ErrorServidor extends ErrorDominio {
  readonly codigo = 'SERVIDOR';
  constructor() {
    super('El servidor tuvo un problema. Intenta de nuevo en unos minutos.');
  }
}

/** El servidor respondió algo que no cumple el contrato (fallar fuerte, no adivinar). */
export class ErrorDatosInvalidos extends ErrorDominio {
  readonly codigo = 'DATOS_INVALIDOS';
  constructor(readonly detalle: string) {
    super('El servidor respondió con datos inesperados.');
  }
}

export class ErrorInesperado extends ErrorDominio {
  readonly codigo = 'INESPERADO';
  constructor() {
    super('Ocurrió un error inesperado.');
  }
}

/** Errores en los que tiene sentido usar la caché de lectura. */
export function esErrorDeConectividad(e: unknown): boolean {
  return e instanceof ErrorSinConexion || e instanceof ErrorTiempoAgotado;
}

/** Texto para mostrar en pantalla a partir de cualquier error. */
export function mensajeDeError(e: unknown): string {
  return e instanceof ErrorDominio ? e.message : new ErrorInesperado().message;
}
