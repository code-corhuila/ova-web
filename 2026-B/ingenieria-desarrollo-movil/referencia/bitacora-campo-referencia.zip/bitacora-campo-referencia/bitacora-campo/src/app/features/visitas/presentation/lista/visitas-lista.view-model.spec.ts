import { TestBed } from '@angular/core/testing';
import { ErrorServidor, ErrorSinConexion } from '../../../../core/errores/errores-dominio';
import { VisitasRepositoryFalso } from '../../../../../testing/visitas-repository.falso';
import { unaVisita } from '../../../../../testing/visitas.ejemplo';
import { EliminarVisita } from '../../domain/casos-de-uso/eliminar-visita';
import { ListarVisitas } from '../../domain/casos-de-uso/listar-visitas';
import { MENSAJE_REALIZADA_NO_SE_ELIMINA } from '../../domain/reglas-visita';
import { VisitasListaViewModel } from './visitas-lista.view-model';

describe('VisitasListaViewModel', () => {
  let repo: VisitasRepositoryFalso;
  let vm: VisitasListaViewModel;

  beforeEach(() => {
    repo = new VisitasRepositoryFalso();
    // Se falsea solo la dependencia directa de los casos de uso: el puerto del repositorio.
    TestBed.configureTestingModule({
      providers: [
        VisitasListaViewModel,
        { provide: ListarVisitas, useValue: new ListarVisitas(repo) },
        { provide: EliminarVisita, useValue: new EliminarVisita(repo) },
      ],
    });
    vm = TestBed.inject(VisitasListaViewModel);
  });

  it('cargar_conVisitas_pasaDeCargandoACargadoConResumen', async () => {
    repo.lista = { ...repo.lista, visitas: [unaVisita({ id: 'a' }), unaVisita({ id: 'b', estado: 'realizada' })] };

    const p = vm.cargar();
    expect(vm.estado().fase).toBe('cargando');
    await p;

    expect(vm.estado().fase).toBe('cargado');
    expect(vm.estado().visitas.length).toBe(2);
    expect(vm.estado().resumen).toEqual({ pendiente: 1, realizada: 1, cancelada: 0, total: 2 });
  });

  it('cargar_sinVisitas_terminaEnVacio', async () => {
    await vm.cargar();
    expect(vm.estado().fase).toBe('vacio');
  });

  it('cargar_desdeCache_terminaEnOfflineConLaFechaDeSincronizacion', async () => {
    repo.lista = { visitas: [unaVisita()], desactualizado: true, sincronizadoEn: new Date('2026-10-04T08:00:00Z') };

    await vm.cargar();

    expect(vm.estado().fase).toBe('offline');
    expect(vm.estado().sincronizadoEn).toEqual(new Date('2026-10-04T08:00:00Z'));
    expect(vm.estado().visitas.length).toBe(1);
  });

  it('cargar_sinRedNiCache_terminaEnErrorConMensaje', async () => {
    repo.errorAlListar = new ErrorSinConexion();

    await vm.cargar();

    expect(vm.estado().fase).toBe('error');
    expect(vm.estado().error).toBe('No hay conexión con el servidor.');
  });

  it('cargar_falloAlRefrescarConDatosEnPantalla_conservaLaListaYAvisa', async () => {
    repo.lista = { ...repo.lista, visitas: [unaVisita()] };
    await vm.cargar();
    repo.errorAlListar = new ErrorServidor();

    await vm.cargar();

    expect(vm.estado().fase).toBe('cargado');
    expect(vm.estado().visitas.length).toBe(1);
    expect(vm.estado().aviso).toBe(new ErrorServidor().message);
  });

  it('cargar_dosCargasSeguidas_ganaLaMasReciente', async () => {
    let soltarPrimera: () => void = () => undefined;
    repo.pausa = new Promise<void>((r) => (soltarPrimera = r));
    repo.lista = { ...repo.lista, visitas: [unaVisita({ id: 'vieja' })] };
    const primera = vm.cargar();

    repo.pausa = null;
    repo.lista = { ...repo.lista, visitas: [unaVisita({ id: 'nueva' })] };
    await vm.cargar();
    soltarPrimera();
    await primera;

    expect(vm.estado().visitas.map((v) => v.id)).toEqual(['nueva']);
  });

  it('eliminar_visitaPendiente_laQuitaYAvisa', async () => {
    repo.lista = { ...repo.lista, visitas: [unaVisita({ id: 'a' }), unaVisita({ id: 'b' })] };
    await vm.cargar();

    await vm.eliminar(vm.estado().visitas[0]);

    expect(vm.estado().visitas.map((v) => v.id)).toEqual(['b']);
    expect(vm.estado().aviso).toBe('Visita eliminada.');
  });

  it('eliminar_ultimaVisita_pasaAVacio', async () => {
    repo.lista = { ...repo.lista, visitas: [unaVisita({ id: 'a' })] };
    await vm.cargar();

    await vm.eliminar(vm.estado().visitas[0]);

    expect(vm.estado().fase).toBe('vacio');
  });

  it('eliminar_visitaRealizada_noLaQuitaYMuestraLaRegla', async () => {
    repo.lista = { ...repo.lista, visitas: [unaVisita({ id: 'r', estado: 'realizada' })] };
    await vm.cargar();

    await vm.eliminar(vm.estado().visitas[0]);

    expect(vm.estado().visitas.length).toBe(1);
    expect(vm.estado().aviso).toBe(MENSAJE_REALIZADA_NO_SE_ELIMINA);
    expect(repo.eliminadas).toEqual([]);
  });

  it('descartarAviso_limpiaElMensajeTransitorio', async () => {
    repo.lista = { ...repo.lista, visitas: [unaVisita({ id: 'a' })] };
    await vm.cargar();
    await vm.eliminar(vm.estado().visitas[0]);

    vm.descartarAviso();

    expect(vm.estado().aviso).toBeNull();
  });
});
