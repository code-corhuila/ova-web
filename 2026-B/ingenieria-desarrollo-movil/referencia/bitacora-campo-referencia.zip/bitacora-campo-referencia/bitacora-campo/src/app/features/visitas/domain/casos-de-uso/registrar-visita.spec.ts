import { ErrorValidacion } from '../../../../core/errores/errores-dominio';
import { VisitasRepositoryFalso } from '../../../../../testing/visitas-repository.falso';
import { MENSAJE_REALIZADA_SIN_FOTO } from '../reglas-visita';
import { DatosVisita } from '../visita';
import { RegistrarVisita } from './registrar-visita';

const datos = (cambios: Partial<DatosVisita> = {}): DatosVisita => ({
  cliente: 'Acueducto Veredal La Plata',
  direccion: 'La Plata, Huila',
  estado: 'pendiente',
  observaciones: '',
  foto: null,
  ubicacion: null,
  ...cambios,
});

async function errorDe(p: Promise<unknown>): Promise<unknown> {
  try {
    await p;
  } catch (e) {
    return e;
  }
  return null;
}

describe('RegistrarVisita', () => {
  it('registrar_conDatosValidos_recortaEspaciosYDelegaEnElRepositorio', async () => {
    const repo = new VisitasRepositoryFalso();

    await new RegistrarVisita(repo).ejecutar(datos({ cliente: '  Acueducto  ', direccion: ' La Plata ' }));

    expect(repo.creadas.length).toBe(1);
    expect(repo.creadas[0].cliente).toBe('Acueducto');
    expect(repo.creadas[0].direccion).toBe('La Plata');
  });

  it('registrar_conClienteDeSoloEspacios_lanzaErrorValidacionSinIrALaRed', async () => {
    const repo = new VisitasRepositoryFalso();

    const error = await errorDe(new RegistrarVisita(repo).ejecutar(datos({ cliente: '     ' })));

    expect(error instanceof ErrorValidacion).toBe(true);
    expect(repo.creadas.length).toBe(0);
  });

  it('registrar_realizadaSinFoto_lanzaErrorValidacion', async () => {
    const repo = new VisitasRepositoryFalso();

    const error = await errorDe(new RegistrarVisita(repo).ejecutar(datos({ estado: 'realizada', foto: null })));

    expect((error as Error).message).toBe(MENSAJE_REALIZADA_SIN_FOTO);
    expect(repo.creadas.length).toBe(0);
  });

  it('registrar_realizadaConFoto_seAcepta', async () => {
    const repo = new VisitasRepositoryFalso();

    const v = await new RegistrarVisita(repo).ejecutar(datos({ estado: 'realizada', foto: 'data:image/jpeg;base64,AAA' }));

    expect(v.estado).toBe('realizada');
  });
});
