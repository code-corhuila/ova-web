import { HttpInterceptorFn } from '@angular/common/http';
import { catchError, throwError } from 'rxjs';
import { mapearErrorHttp } from './mapear-error-http';

/**
 * Frontera de errores: de aquí hacia arriba (repositorios, casos de uso, ViewModels) solo
 * circulan errores de dominio. Va justo después de correlation-id (antes de auth y timeout) para ver el error final, después del
 * reintento por refresh y del timeout.
 */
export const erroresInterceptor: HttpInterceptorFn = (req, next) =>
  next(req).pipe(catchError((e: unknown) => throwError(() => mapearErrorHttp(e))));
