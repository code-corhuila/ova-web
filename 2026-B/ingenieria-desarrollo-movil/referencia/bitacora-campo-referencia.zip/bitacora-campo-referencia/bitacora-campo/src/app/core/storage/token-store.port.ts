/** Par de tokens de la sesión (ver 03-api-y-datos/autenticacion.md). */
export interface TokensSesion {
  readonly accessToken: string;
  readonly refreshToken: string;
}

/**
 * Puerto: dónde se guardan los tokens. El resto de la app no sabe si es Keychain, Keystore o
 * memoria; las pruebas lo reemplazan por un doble en memoria (ADR-004).
 */
export interface TokenStore {
  leer(): Promise<TokensSesion | null>;
  guardar(tokens: TokensSesion): Promise<void>;
  borrar(): Promise<void>;
}
