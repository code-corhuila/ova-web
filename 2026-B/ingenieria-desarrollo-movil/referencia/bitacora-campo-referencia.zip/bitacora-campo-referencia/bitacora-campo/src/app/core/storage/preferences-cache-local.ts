import { Preferences } from '@capacitor/preferences';
import { CacheLocal, EntradaCache } from './cache-local.port';

const PREFIJO = 'cache.';

/**
 * Adaptador de CacheLocal sobre @capacitor/preferences (SharedPreferences en Android,
 * UserDefaults en iOS, localStorage en web). Guarda JSON con la marca de tiempo.
 */
export class PreferencesCacheLocal implements CacheLocal {
  constructor(private readonly reloj: () => Date = () => new Date()) {}

  async leer<T>(clave: string): Promise<EntradaCache<T> | null> {
    const { value } = await Preferences.get({ key: PREFIJO + clave });
    if (value === null) return null;
    try {
      return JSON.parse(value) as EntradaCache<T>;
    } catch {
      // Entrada corrupta: se descarta en lugar de romper la pantalla.
      await Preferences.remove({ key: PREFIJO + clave });
      return null;
    }
  }

  async guardar<T>(clave: string, valor: T): Promise<void> {
    const entrada: EntradaCache<T> = { valor, guardadoEn: this.reloj().toISOString() };
    await Preferences.set({ key: PREFIJO + clave, value: JSON.stringify(entrada) });
  }

  async limpiar(): Promise<void> {
    const { keys } = await Preferences.keys();
    await Promise.all(keys.filter((k) => k.startsWith(PREFIJO)).map((key) => Preferences.remove({ key })));
  }
}
