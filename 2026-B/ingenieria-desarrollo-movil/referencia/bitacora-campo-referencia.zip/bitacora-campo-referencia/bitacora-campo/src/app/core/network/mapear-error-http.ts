import { HttpErrorResponse } from '@angular/common/http';
import { TimeoutError } from 'rxjs';
import {
  ErrorDominio,
  ErrorInesperado,
  ErrorNoEncontrado,
  ErrorServidor,
  ErrorSesionExpirada,
  ErrorSinConexion,
  ErrorTiempoAgotado,
  ErrorValidacion,
} from '../errores/errores-dominio';

/**
 * Traduce un error técnico de red a un error de dominio (tabla de 03-api-y-datos/endpoint-visitas.md).
 * Función pura: se prueba sin TestBed.
 */
export function mapearErrorHttp(e: unknown): ErrorDominio {
  if (e instanceof ErrorDominio) return e;
  if (e instanceof TimeoutError) return new ErrorTiempoAgotado();
  if (e instanceof HttpErrorResponse) {
    if (e.status === 0) return new ErrorSinConexion();
    if (e.status === 401) return new ErrorSesionExpirada();
    if (e.status === 404) return new ErrorNoEncontrado();
    if (e.status === 400 || e.status === 422) {
      const detalle = typeof e.error?.error === 'string' ? e.error.error : 'Revisa los datos enviados.';
      return new ErrorValidacion(detalle);
    }
    if (e.status >= 500) return new ErrorServidor();
  }
  return new ErrorInesperado();
}
