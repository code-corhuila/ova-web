import { VisitasRepositoryFalso } from '../../../../../testing/visitas-repository.falso';
import { unaVisita } from '../../../../../testing/visitas.ejemplo';
import { ListarVisitas } from './listar-visitas';

describe('ListarVisitas', () => {
  it('listar_conVariosEstados_ponePendientesPrimeroYLuegoLasMasRecientes', async () => {
    const repo = new VisitasRepositoryFalso();
    repo.lista = {
      ...repo.lista,
      visitas: [
        unaVisita({ id: 'realizada-nueva', estado: 'realizada', creadaEn: new Date('2026-10-05T10:00:00Z') }),
        unaVisita({ id: 'pendiente-vieja', estado: 'pendiente', creadaEn: new Date('2026-10-01T10:00:00Z') }),
        unaVisita({ id: 'pendiente-nueva', estado: 'pendiente', creadaEn: new Date('2026-10-04T10:00:00Z') }),
      ],
    };

    const resultado = await new ListarVisitas(repo).ejecutar();

    expect(resultado.visitas.map((v) => v.id)).toEqual(['pendiente-nueva', 'pendiente-vieja', 'realizada-nueva']);
  });

  it('listar_desdeCache_conservaLaMarcaDesactualizado', async () => {
    const repo = new VisitasRepositoryFalso();
    repo.lista = { ...repo.lista, desactualizado: true };

    const resultado = await new ListarVisitas(repo).ejecutar();

    expect(resultado.desactualizado).toBe(true);
    expect(resultado.sincronizadoEn).toEqual(repo.lista.sincronizadoEn);
  });
});
