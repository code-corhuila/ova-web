/**
 * Forma EXACTA del JSON de la API (api-simulada/README.md). Solo vive en data/:
 * la UI y el dominio nunca ven un DTO.
 */
export interface VisitaDto {
  id: string;
  cliente: string;
  direccion: string;
  estado: string;
  observaciones: string;
  foto: string | null;
  lat: number | null;
  lng: number | null;
  /** ISO 8601 */
  creada: string;
  /** ISO 8601; ausente en registros antiguos */
  actualizada?: string;
}

/** Cuerpo de POST /visitas y PUT /visitas/:id. */
export interface VisitaEntradaDto {
  cliente: string;
  direccion: string;
  estado: string;
  observaciones: string;
  foto: string | null;
  lat: number | null;
  lng: number | null;
}
