import { TestBed } from '@angular/core/testing';
import { ErrorNoEncontrado, ErrorSinConexion } from '../../../../core/errores/errores-dominio';
import { PermisoDenegadoError } from '../../../../core/nativo/permiso-denegado.error';
import { CamaraFalsa, UbicacionFalsa } from '../../../../../testing/nativo.falso';
import { VisitasRepositoryFalso } from '../../../../../testing/visitas-repository.falso';
import { unaVisita } from '../../../../../testing/visitas.ejemplo';
import { ActualizarVisita } from '../../domain/casos-de-uso/actualizar-visita';
import { AVISO_SIN_UBICACION, CapturarEvidencia } from '../../domain/casos-de-uso/capturar-evidencia';
import { ObtenerVisita } from '../../domain/casos-de-uso/obtener-visita';
import { RegistrarVisita } from '../../domain/casos-de-uso/registrar-visita';
import { MENSAJE_REALIZADA_SIN_FOTO } from '../../domain/reglas-visita';
import { Camara } from '../../../../core/nativo/camara.port';
import { Ubicacion } from '../../../../core/nativo/ubicacion.port';
import { CamposVisita, VisitaFormViewModel } from './visita-form.view-model';

describe('VisitaFormViewModel', () => {
  let repo: VisitasRepositoryFalso;

  function crear(camara: Camara = new CamaraFalsa('data:image/jpeg;base64,AAA'), ubicacion: Ubicacion = new UbicacionFalsa({ lat: 2.93, lng: -75.28 })) {
    TestBed.configureTestingModule({
      providers: [
        VisitaFormViewModel,
        { provide: ObtenerVisita, useValue: new ObtenerVisita(repo) },
        { provide: RegistrarVisita, useValue: new RegistrarVisita(repo) },
        { provide: ActualizarVisita, useValue: new ActualizarVisita(repo) },
        { provide: CapturarEvidencia, useValue: new CapturarEvidencia(camara, ubicacion) },
      ],
    });
    return TestBed.inject(VisitaFormViewModel);
  }

  const campos = (cambios: Partial<CamposVisita> = {}): CamposVisita => ({
    cliente: 'Lácteos del Huila',
    direccion: 'Zona industrial, Neiva',
    estado: 'pendiente',
    observaciones: '',
    ...cambios,
  });

  beforeEach(() => (repo = new VisitasRepositoryFalso()));

  it('iniciar_sinId_quedaEditandoEnModoNueva', async () => {
    const vm = crear();

    expect(await vm.iniciar(null)).toBeNull();
    expect(vm.estado().fase).toBe('editando');
    expect(vm.estado().modo).toBe('nueva');
  });

  it('iniciar_conId_pasaPorCargandoYDevuelveLosCamposConSuEvidencia', async () => {
    repo.visitaPorId = unaVisita({ cliente: 'Arrocera Campoalegre', foto: 'f', ubicacion: { lat: 1, lng: 2 } });
    const vm = crear();

    const p = vm.iniciar('s10');
    expect(vm.estado().fase).toBe('cargando');
    const datos = await p;

    expect(datos?.cliente).toBe('Arrocera Campoalegre');
    expect(vm.estado().fase).toBe('editando');
    expect(vm.estado().modo).toBe('edicion');
    expect(vm.estado().foto).toBe('f');
    expect(vm.estado().ubicacion).toEqual({ lat: 1, lng: 2 });
  });

  it('iniciar_conIdInexistente_terminaEnError', async () => {
    repo.errorAlListar = new ErrorNoEncontrado();
    const vm = crear();

    await vm.iniciar('nada');

    expect(vm.estado().fase).toBe('error');
    expect(vm.estado().error).toBe('El registro ya no existe.');
  });

  it('guardar_nueva_registraConLaEvidenciaCapturadaYTerminaEnGuardado', async () => {
    const vm = crear();
    await vm.iniciar(null);
    await vm.tomarEvidencia();

    expect(await vm.guardar(campos({ estado: 'realizada' }))).toBe(true);

    expect(vm.estado().fase).toBe('guardado');
    expect(repo.creadas[0].foto).toBe('data:image/jpeg;base64,AAA');
    expect(repo.creadas[0].ubicacion).toEqual({ lat: 2.93, lng: -75.28 });
  });

  it('guardar_realizadaSinFoto_vuelveAEditandoConElMensajeDeLaRegla', async () => {
    const vm = crear();
    await vm.iniciar(null);

    expect(await vm.guardar(campos({ estado: 'realizada' }))).toBe(false);

    expect(vm.estado().fase).toBe('editando');
    expect(vm.estado().error).toBe(MENSAJE_REALIZADA_SIN_FOTO);
    expect(repo.creadas.length).toBe(0);
  });

  it('guardar_edicionSinRed_muestraErrorYPermiteReintentar', async () => {
    const vm = crear();
    await vm.iniciar('s1');
    repo.errorAlEscribir = new ErrorSinConexion();

    expect(await vm.guardar(campos())).toBe(false);
    expect(vm.estado().error).toBe('No hay conexión con el servidor.');

    repo.errorAlEscribir = null;
    expect(await vm.guardar(campos())).toBe(true);
    expect(repo.actualizadas[0].id).toBe('s1');
  });

  it('tomarEvidencia_sinUbicacion_guardaLaFotoYMuestraAviso', async () => {
    const vm = crear(new CamaraFalsa('foto'), new UbicacionFalsa(new Error('GPS apagado')));

    await vm.tomarEvidencia();

    expect(vm.estado().foto).toBe('foto');
    expect(vm.estado().ubicacion).toBeNull();
    expect(vm.estado().aviso).toBe(AVISO_SIN_UBICACION);
    expect(vm.estado().capturando).toBe(false);
  });

  it('tomarEvidencia_sinPermisoDeCamara_muestraElErrorYNoCambiaLaFoto', async () => {
    const vm = crear(new CamaraFalsa(new PermisoDenegadoError('cámara')));

    await vm.tomarEvidencia();

    expect(vm.estado().foto).toBeNull();
    expect(vm.estado().error).toContain('Sin permiso de cámara');
  });
});
