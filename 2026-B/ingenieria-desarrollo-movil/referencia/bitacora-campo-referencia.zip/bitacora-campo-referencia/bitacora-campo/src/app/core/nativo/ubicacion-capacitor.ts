import { Capacitor } from '@capacitor/core';
import { Geolocation } from '@capacitor/geolocation';
import { Coordenadas, Ubicacion } from './ubicacion.port';
import { PermisoDenegadoError } from './permiso-denegado.error';

/**
 * Adaptador del puerto Ubicacion sobre @capacitor/geolocation 8.x.
 * Permiso just-in-time (solo cuando se captura la evidencia). En web el navegador muestra su
 * propio aviso: `requestPermissions` no existe allí, por eso solo se llama en nativo.
 */
export class UbicacionCapacitor implements Ubicacion {
  async obtenerActual(): Promise<Coordenadas> {
    if (Capacitor.isNativePlatform()) {
      let estado = await Geolocation.checkPermissions(); // lanza si los servicios de ubicación están apagados
      if (estado.location === 'prompt' || estado.location === 'prompt-with-rationale') {
        estado = await Geolocation.requestPermissions({ permissions: ['location'] });
      }
      if (estado.location === 'denied') throw new PermisoDenegadoError('ubicación');
    }

    const posicion = await Geolocation.getCurrentPosition({ enableHighAccuracy: true, timeout: 10_000, maximumAge: 30_000 });
    return { lat: posicion.coords.latitude, lng: posicion.coords.longitude };
  }
}
