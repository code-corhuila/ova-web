import { HttpErrorResponse } from '@angular/common/http';
import { TimeoutError } from 'rxjs';
import {
  ErrorInesperado,
  ErrorNoEncontrado,
  ErrorServidor,
  ErrorSesionExpirada,
  ErrorSinConexion,
  ErrorTiempoAgotado,
  ErrorValidacion,
} from '../errores/errores-dominio';
import { mapearErrorHttp } from './mapear-error-http';

describe('mapearErrorHttp', () => {
  it('mapear_status0_esErrorSinConexion', () => {
    expect(mapearErrorHttp(new HttpErrorResponse({ status: 0 })) instanceof ErrorSinConexion).toBe(true);
  });

  it('mapear_timeout_esErrorTiempoAgotado', () => {
    expect(mapearErrorHttp(new TimeoutError()) instanceof ErrorTiempoAgotado).toBe(true);
  });

  it('mapear_401_esErrorSesionExpirada', () => {
    expect(mapearErrorHttp(new HttpErrorResponse({ status: 401 })) instanceof ErrorSesionExpirada).toBe(true);
  });

  it('mapear_400ConMensajeDeLaApi_esErrorValidacionConEseMensaje', () => {
    const e = mapearErrorHttp(new HttpErrorResponse({ status: 400, error: { error: 'cliente: mínimo 3 caracteres' } }));
    expect(e instanceof ErrorValidacion).toBe(true);
    expect(e.message).toBe('cliente: mínimo 3 caracteres');
  });

  it('mapear_404_esErrorNoEncontrado', () => {
    expect(mapearErrorHttp(new HttpErrorResponse({ status: 404 })) instanceof ErrorNoEncontrado).toBe(true);
  });

  it('mapear_503_esErrorServidor', () => {
    expect(mapearErrorHttp(new HttpErrorResponse({ status: 503 })) instanceof ErrorServidor).toBe(true);
  });

  it('mapear_errorDeDominio_loDejaPasarIgual', () => {
    const original = new ErrorSinConexion();
    expect(mapearErrorHttp(original)).toBe(original);
  });

  it('mapear_cualquierOtraCosa_esErrorInesperado', () => {
    expect(mapearErrorHttp('ups') instanceof ErrorInesperado).toBe(true);
  });
});
