import { InjectionToken, Provider, inject } from '@angular/core';
import { CAMARA, UBICACION } from '../nativo/nativo.tokens';
import { VisitasHttpRepository } from '../../features/visitas/data/visitas-http.repository';
import { ActualizarVisita } from '../../features/visitas/domain/casos-de-uso/actualizar-visita';
import { CapturarEvidencia } from '../../features/visitas/domain/casos-de-uso/capturar-evidencia';
import { EliminarVisita } from '../../features/visitas/domain/casos-de-uso/eliminar-visita';
import { ListarVisitas } from '../../features/visitas/domain/casos-de-uso/listar-visitas';
import { ObtenerVisita } from '../../features/visitas/domain/casos-de-uso/obtener-visita';
import { RegistrarVisita } from '../../features/visitas/domain/casos-de-uso/registrar-visita';
import { VisitasRepository } from '../../features/visitas/domain/visitas.repository';

/**
 * Raíz de composición (core/di/) para la feature visitas. core/di/ es el ÚNICO lugar que conoce
 * a la vez el dominio (casos de uso, puerto) y data/ (implementación concreta). Presentation
 * inyecta casos de uso; nunca importa data/.
 *
 * Los casos de uso son clases de TypeScript puro; aquí se construyen con sus dependencias.
 * Se registran en la ruta /visitas (app.routes.ts): solo existen mientras se usa la feature.
 */
export const VISITAS_REPOSITORY = new InjectionToken<VisitasRepository>('VISITAS_REPOSITORY', {
  providedIn: 'root',
  factory: () => inject(VisitasHttpRepository),
});

export function provideVisitas(): Provider[] {
  return [
    { provide: ListarVisitas, useFactory: () => new ListarVisitas(inject(VISITAS_REPOSITORY)) },
    { provide: ObtenerVisita, useFactory: () => new ObtenerVisita(inject(VISITAS_REPOSITORY)) },
    { provide: RegistrarVisita, useFactory: () => new RegistrarVisita(inject(VISITAS_REPOSITORY)) },
    { provide: ActualizarVisita, useFactory: () => new ActualizarVisita(inject(VISITAS_REPOSITORY)) },
    { provide: EliminarVisita, useFactory: () => new EliminarVisita(inject(VISITAS_REPOSITORY)) },
    { provide: CapturarEvidencia, useFactory: () => new CapturarEvidencia(inject(CAMARA), inject(UBICACION)) },
  ];
}
