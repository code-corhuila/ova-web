import { AuthRepository } from './auth.repository';

/** Caso de uso: cerrar sesión (revoca el refresh token y borra tokens y caché). */
export class CerrarSesion {
  constructor(private readonly repositorio: AuthRepository) {}

  ejecutar(): Promise<void> {
    return this.repositorio.cerrarSesion();
  }
}
