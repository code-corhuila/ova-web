import { ErrorDominio } from '../errores/errores-dominio';

export type RecursoNativo = 'cámara' | 'ubicación';

/** La persona negó (o tiene negado) un permiso del sistema. TypeScript puro: lo usa domain/. */
export class PermisoDenegadoError extends ErrorDominio {
  readonly codigo = 'PERMISO_DENEGADO';

  constructor(readonly recurso: RecursoNativo) {
    super(`Sin permiso de ${recurso}. Actívalo en Ajustes > Aplicaciones > Bitácora de Campo > Permisos.`);
  }
}
