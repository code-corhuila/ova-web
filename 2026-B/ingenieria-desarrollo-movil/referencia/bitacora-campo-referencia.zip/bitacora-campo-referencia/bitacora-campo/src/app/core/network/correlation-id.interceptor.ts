import { HttpInterceptorFn } from '@angular/common/http';

export const ENCABEZADO_CORRELACION = 'X-Correlation-Id';

/** Cada petición lleva un id único: permite seguirla en los logs de la app y del servidor. */
export const correlationIdInterceptor: HttpInterceptorFn = (req, next) =>
  next(req.clone({ setHeaders: { [ENCABEZADO_CORRELACION]: nuevoIdCorrelacion() } }));

export function nuevoIdCorrelacion(): string {
  if (typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function') return crypto.randomUUID();
  return `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 10)}`;
}
