import { SecureStorage } from '@aparajita/capacitor-secure-storage';
import { TokenStore, TokensSesion } from './token-store.port';

const CLAVE = 'bitacora.sesion';

/**
 * Adaptador de TokenStore sobre @aparajita/capacitor-secure-storage:
 * iOS → Keychain; Android → AES-GCM con llave del Android Keystore.
 * En el navegador el plugin usa localStorage SIN cifrar: solo sirve para depurar (ADR-004).
 */
export class SecureTokenStore implements TokenStore {
  async leer(): Promise<TokensSesion | null> {
    const valor = await SecureStorage.get(CLAVE);
    return esTokensSesion(valor) ? valor : null;
  }

  async guardar(tokens: TokensSesion): Promise<void> {
    await SecureStorage.set(CLAVE, { accessToken: tokens.accessToken, refreshToken: tokens.refreshToken });
  }

  async borrar(): Promise<void> {
    await SecureStorage.remove(CLAVE);
  }
}

function esTokensSesion(v: unknown): v is TokensSesion {
  if (typeof v !== 'object' || v === null) return false;
  const t = v as Record<string, unknown>;
  return typeof t['accessToken'] === 'string' && typeof t['refreshToken'] === 'string';
}
