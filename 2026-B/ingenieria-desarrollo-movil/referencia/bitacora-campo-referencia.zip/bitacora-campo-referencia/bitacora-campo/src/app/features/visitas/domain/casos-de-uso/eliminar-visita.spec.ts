import { ErrorValidacion } from '../../../../core/errores/errores-dominio';
import { VisitasRepositoryFalso } from '../../../../../testing/visitas-repository.falso';
import { unaVisita } from '../../../../../testing/visitas.ejemplo';
import { MENSAJE_REALIZADA_NO_SE_ELIMINA } from '../reglas-visita';
import { EliminarVisita } from './eliminar-visita';

describe('EliminarVisita', () => {
  it('eliminar_visitaPendiente_laEliminaEnElRepositorio', async () => {
    const repo = new VisitasRepositoryFalso();

    await new EliminarVisita(repo).ejecutar(unaVisita({ id: 'p1', estado: 'pendiente' }));

    expect(repo.eliminadas).toEqual(['p1']);
  });

  it('eliminar_visitaRealizada_lanzaErrorValidacionYNoLlamaAlRepositorio', async () => {
    const repo = new VisitasRepositoryFalso();
    let error: unknown = null;

    try {
      await new EliminarVisita(repo).ejecutar(unaVisita({ id: 'r1', estado: 'realizada' }));
    } catch (e) {
      error = e;
    }

    expect(error instanceof ErrorValidacion).toBe(true);
    expect((error as Error).message).toBe(MENSAJE_REALIZADA_NO_SE_ELIMINA);
    expect(repo.eliminadas).toEqual([]);
  });
});
