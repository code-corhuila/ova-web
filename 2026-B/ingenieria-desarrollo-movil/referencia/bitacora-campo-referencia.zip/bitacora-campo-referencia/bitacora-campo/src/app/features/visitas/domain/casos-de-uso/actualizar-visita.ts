import { validarDatosVisita } from '../reglas-visita';
import { DatosVisita, Visita } from '../visita';
import { VisitasRepository } from '../visitas.repository';

/** Caso de uso: actualizar una visita existente con las mismas reglas del registro. */
export class ActualizarVisita {
  constructor(private readonly repositorio: VisitasRepository) {}

  async ejecutar(id: string, datos: DatosVisita): Promise<Visita> {
    return this.repositorio.actualizar(id, validarDatosVisita(datos));
  }
}
