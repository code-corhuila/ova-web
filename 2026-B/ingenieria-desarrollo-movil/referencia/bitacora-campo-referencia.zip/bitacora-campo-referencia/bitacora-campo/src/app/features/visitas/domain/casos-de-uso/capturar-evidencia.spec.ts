import { PermisoDenegadoError } from '../../../../core/nativo/permiso-denegado.error';
import { CamaraFalsa, UbicacionFalsa } from '../../../../../testing/nativo.falso';
import { AVISO_SIN_UBICACION, CapturarEvidencia } from './capturar-evidencia';

describe('CapturarEvidencia', () => {
  it('capturar_conCamaraYUbicacion_devuelveFotoYCoordenadasSinAviso', async () => {
    const caso = new CapturarEvidencia(new CamaraFalsa('data:image/jpeg;base64,AAA'), new UbicacionFalsa({ lat: 2.93, lng: -75.28 }));

    expect(await caso.ejecutar()).toEqual({ foto: 'data:image/jpeg;base64,AAA', ubicacion: { lat: 2.93, lng: -75.28 }, aviso: null });
  });

  it('capturar_sinPermisoDeCamara_propagaPermisoDenegadoError', async () => {
    const caso = new CapturarEvidencia(new CamaraFalsa(new PermisoDenegadoError('cámara')), new UbicacionFalsa({ lat: 0, lng: 0 }));
    let error: unknown = null;

    try {
      await caso.ejecutar();
    } catch (e) {
      error = e;
    }

    expect(error instanceof PermisoDenegadoError).toBe(true);
  });

  it('capturar_conGpsFallando_conservaLaFotoYAvisa', async () => {
    const caso = new CapturarEvidencia(new CamaraFalsa('foto'), new UbicacionFalsa(new Error('GPS apagado')));

    const evidencia = await caso.ejecutar();

    expect(evidencia.foto).toBe('foto');
    expect(evidencia.ubicacion).toBeNull();
    expect(evidencia.aviso).toBe(AVISO_SIN_UBICACION);
  });

  it('capturar_sinPermisoDeUbicacion_avisaComoActivarloEnAjustes', async () => {
    const caso = new CapturarEvidencia(new CamaraFalsa('foto'), new UbicacionFalsa(new PermisoDenegadoError('ubicación')));

    expect((await caso.ejecutar()).aviso).toContain('Ajustes');
  });
});
