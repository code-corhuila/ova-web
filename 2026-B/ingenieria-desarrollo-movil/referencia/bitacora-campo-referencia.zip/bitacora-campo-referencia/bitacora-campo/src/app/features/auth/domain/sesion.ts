/** Entidad: la sesión de la persona técnica que inició sesión. Los tokens NO viven aquí (son infraestructura). */
export interface Sesion {
  readonly nombre: string;
}
