import { ErrorValidacion } from '../../../core/errores/errores-dominio';
import { AuthRepository } from './auth.repository';
import { Sesion } from './sesion';

export const LONGITUD_MINIMA_CLAVE = 6;

/** Caso de uso: iniciar sesión. Valida la entrada antes de ir a la red. */
export class IniciarSesion {
  constructor(private readonly repositorio: AuthRepository) {}

  ejecutar(usuario: string, clave: string): Promise<Sesion> {
    const usuarioLimpio = usuario.trim();
    if (usuarioLimpio.length === 0) return Promise.reject(new ErrorValidacion('Escribe tu usuario.'));
    if (clave.length < LONGITUD_MINIMA_CLAVE) {
      return Promise.reject(new ErrorValidacion(`La clave tiene mínimo ${LONGITUD_MINIMA_CLAVE} caracteres.`));
    }
    return this.repositorio.iniciarSesion(usuarioLimpio, clave);
  }
}
