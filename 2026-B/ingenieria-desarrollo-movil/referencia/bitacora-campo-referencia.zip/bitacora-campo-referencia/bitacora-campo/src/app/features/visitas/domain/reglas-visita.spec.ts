import { unaVisita } from '../../../../testing/visitas.ejemplo';
import { resumirVisitas } from './reglas-visita';

describe('resumirVisitas', () => {
  it('resumir_listaMixta_cuentaPorEstadoYTotal', () => {
    const visitas = [unaVisita({ estado: 'pendiente' }), unaVisita({ estado: 'realizada' }), unaVisita({ estado: 'pendiente' })];
    expect(resumirVisitas(visitas)).toEqual({ pendiente: 2, realizada: 1, cancelada: 0, total: 3 });
  });

  it('resumir_listaVacia_daCeros', () => {
    expect(resumirVisitas([])).toEqual({ pendiente: 0, realizada: 0, cancelada: 0, total: 0 });
  });
});
