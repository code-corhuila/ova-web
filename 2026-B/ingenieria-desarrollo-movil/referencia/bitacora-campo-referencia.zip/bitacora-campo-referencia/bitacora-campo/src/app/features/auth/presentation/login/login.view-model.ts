import { Injectable, inject } from '@angular/core';
import { toSignal } from '@angular/core/rxjs-interop';
import { BehaviorSubject } from 'rxjs';
import { mensajeDeError } from '../../../../core/errores/errores-dominio';
import { IniciarSesion } from '../../domain/iniciar-sesion';

export type FaseLogin = 'inicial' | 'enviando' | 'error' | 'exito';

/** Estado inmutable de la pantalla de login (ADR-001). */
export interface EstadoLogin {
  readonly fase: FaseLogin;
  readonly error: string | null;
  readonly nombre: string | null;
}

export const ESTADO_LOGIN_INICIAL: EstadoLogin = { fase: 'inicial', error: null, nombre: null };

/** ViewModel de /login: un BehaviorSubject privado, expuesto como signal de solo lectura. */
@Injectable()
export class LoginViewModel {
  private readonly iniciarSesion = inject(IniciarSesion);
  private readonly estado$ = new BehaviorSubject<EstadoLogin>(ESTADO_LOGIN_INICIAL);

  readonly estado = toSignal(this.estado$, { requireSync: true });

  /** @returns true si la sesión quedó iniciada (la pantalla navega). */
  async ingresar(usuario: string, clave: string): Promise<boolean> {
    if (this.estado$.value.fase === 'enviando') return false;
    this.estado$.next({ fase: 'enviando', error: null, nombre: null });
    try {
      const sesion = await this.iniciarSesion.ejecutar(usuario, clave);
      this.estado$.next({ fase: 'exito', error: null, nombre: sesion.nombre });
      return true;
    } catch (e) {
      this.estado$.next({ fase: 'error', error: mensajeDeError(e), nombre: null });
      return false;
    }
  }
}
