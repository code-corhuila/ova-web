/** Cuerpo de POST /auth/login (contrato de api-simulada/README.md). */
export interface LoginSolicitudDto {
  usuario: string;
  clave: string;
}

/** Respuesta 200 de POST /auth/login. */
export interface LoginRespuestaDto {
  accessToken: string;
  refreshToken: string;
  nombre: string;
}
