import { Capacitor } from '@capacitor/core';
import { Camera, CameraDirection } from '@capacitor/camera';
import { Camara } from './camara.port';
import { PermisoDenegadoError } from './permiso-denegado.error';

/**
 * Adaptador del puerto Camara sobre @capacitor/camera 8.x (API nueva `takePhoto`, desde 8.1).
 *
 * Permiso just-in-time: se verifica y se pide JUSTO antes de abrir la cámara, cuando la persona
 * pulsó «Tomar foto», no al iniciar la app. En Android el plugin no declara el permiso CAMERA
 * (usa el intent del sistema) y `checkPermissions` responde `granted`; en iOS sí se pide.
 */
export class CamaraCapacitor implements Camara {
  async tomarFoto(): Promise<string> {
    if (Capacitor.isNativePlatform()) {
      let estado = await Camera.checkPermissions();
      if (estado.camera === 'prompt' || estado.camera === 'prompt-with-rationale') {
        estado = await Camera.requestPermissions({ permissions: ['camera'] });
      }
      if (estado.camera === 'denied') throw new PermisoDenegadoError('cámara');
    }

    const foto = await Camera.takePhoto({
      quality: 60,
      targetWidth: 1024,
      targetHeight: 1024,
      correctOrientation: true,
      cameraDirection: CameraDirection.Rear,
      includeMetadata: true,
    });
    if (!foto.thumbnail) throw new Error('La cámara no devolvió imagen.');
    // En nativo `thumbnail` es una versión reducida (suficiente como evidencia y liviana para la API);
    // en web es la imagen completa. Android/iOS pueden reportar 'jpg' en vez de 'jpeg'.
    const formato = (foto.metadata?.format ?? 'jpeg').replace('jpg', 'jpeg');
    return `data:image/${formato};base64,${foto.thumbnail}`;
  }
}
