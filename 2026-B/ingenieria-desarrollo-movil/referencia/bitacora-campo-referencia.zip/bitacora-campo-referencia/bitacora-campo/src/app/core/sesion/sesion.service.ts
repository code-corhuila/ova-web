import { HttpBackend, HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Injectable, inject, signal } from '@angular/core';
import { Subject, firstValueFrom, timeout } from 'rxjs';
import { ErrorSesionExpirada } from '../errores/errores-dominio';
import { API_URL } from '../network/api-url';
import { mapearErrorHttp } from '../network/mapear-error-http';
import { CACHE_LOCAL, TOKEN_STORE } from '../storage/storage.tokens';
import { TokensSesion } from '../storage/token-store.port';

const TIEMPO_LIMITE_REFRESH_MS = 10_000;

/**
 * Dueño único de los tokens de la sesión (03-api-y-datos/autenticacion.md):
 * - los guarda en el TokenStore seguro y los mantiene en memoria para el interceptor;
 * - renueva el access token con el refresh token, UNA renovación a la vez (serializada);
 * - si la renovación es rechazada, cierra la sesión y avisa por `expirada$`
 *   (el shell de la app navega al login; la capa de red no conoce rutas).
 *
 * Las llamadas a /auth/refresh y /auth/logout usan un HttpClient SIN interceptores
 * (construido sobre HttpBackend) para no entrar en un ciclo con el interceptor de auth.
 */
@Injectable({ providedIn: 'root' })
export class SesionService {
  private readonly tokenStore = inject(TOKEN_STORE);
  private readonly cache = inject(CACHE_LOCAL);
  private readonly api = inject(API_URL);
  private readonly httpSinInterceptores = new HttpClient(inject(HttpBackend));

  private tokens: TokensSesion | null = null;
  private refrescoEnCurso: Promise<string> | null = null;
  private readonly estadoAutenticado = signal(false);
  private readonly expiradaSubject = new Subject<void>();

  /** true mientras haya una sesión; lo leen el guard y el menú. */
  readonly autenticado = this.estadoAutenticado.asReadonly();
  /** Emite cuando la sesión se cierra porque el refresh token ya no sirve. */
  readonly expirada$ = this.expiradaSubject.asObservable();

  get accessToken(): string | null {
    return this.tokens?.accessToken ?? null;
  }

  /** Lee la sesión guardada al arrancar la app (provideAppInitializer). */
  async restaurar(): Promise<void> {
    try {
      this.establecer(await this.tokenStore.leer());
    } catch {
      // Almacenamiento ilegible (p. ej. llave del Keystore invalidada): se arranca sin sesión.
      this.establecer(null);
    }
  }

  /** Guarda los tokens recién emitidos por /auth/login. */
  async iniciar(tokens: TokensSesion): Promise<void> {
    await this.tokenStore.guardar(tokens);
    this.establecer(tokens);
  }

  /**
   * Devuelve un access token vigente. Si `tokenRechazado` ya no es el actual (otra petición
   * renovó primero), reutiliza el nuevo sin volver a llamar a la API.
   * Varias peticiones con 401 simultáneo comparten UNA sola llamada a /auth/refresh.
   */
  refrescar(tokenRechazado?: string): Promise<string> {
    const actual = this.accessToken;
    if (actual && tokenRechazado && actual !== tokenRechazado) return Promise.resolve(actual);
    this.refrescoEnCurso ??= this.pedirNuevoAccessToken().finally(() => (this.refrescoEnCurso = null));
    return this.refrescoEnCurso;
  }

  /** Cierre voluntario: revoca el refresh token (si hay red) y borra tokens y caché. */
  async cerrar(): Promise<void> {
    const refreshToken = this.tokens?.refreshToken;
    if (refreshToken) {
      try {
        await firstValueFrom(
          this.httpSinInterceptores
            .post(`${this.api}/auth/logout`, { refreshToken })
            .pipe(timeout(TIEMPO_LIMITE_REFRESH_MS)),
        );
      } catch {
        // Sin red no se puede revocar en el servidor; igual se borra todo localmente.
      }
    }
    await this.limpiarLocal();
  }

  private async pedirNuevoAccessToken(): Promise<string> {
    const actuales = this.tokens;
    if (!actuales) throw new ErrorSesionExpirada();
    try {
      const respuesta = await firstValueFrom(
        this.httpSinInterceptores
          .post<{ accessToken?: unknown }>(`${this.api}/auth/refresh`, { refreshToken: actuales.refreshToken })
          .pipe(timeout(TIEMPO_LIMITE_REFRESH_MS)),
      );
      if (typeof respuesta.accessToken !== 'string') throw new ErrorSesionExpirada();
      const nuevos: TokensSesion = { accessToken: respuesta.accessToken, refreshToken: actuales.refreshToken };
      await this.tokenStore.guardar(nuevos);
      this.establecer(nuevos);
      return nuevos.accessToken;
    } catch (e) {
      const rechazado = e instanceof ErrorSesionExpirada || (e instanceof HttpErrorResponse && (e.status === 401 || e.status === 400));
      if (rechazado) {
        await this.limpiarLocal();
        this.expiradaSubject.next();
        throw new ErrorSesionExpirada();
      }
      // Sin red o servidor caído: NO se cierra la sesión; el error sube ya traducido.
      throw mapearErrorHttp(e);
    }
  }

  private async limpiarLocal(): Promise<void> {
    this.establecer(null);
    await Promise.all([this.tokenStore.borrar(), this.cache.limpiar()]);
  }

  private establecer(tokens: TokensSesion | null): void {
    this.tokens = tokens;
    this.estadoAutenticado.set(tokens !== null);
  }
}
