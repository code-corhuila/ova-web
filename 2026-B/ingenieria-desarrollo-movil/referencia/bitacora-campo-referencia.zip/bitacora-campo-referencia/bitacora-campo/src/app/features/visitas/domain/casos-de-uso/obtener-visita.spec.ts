import { ErrorValidacion } from '../../../../core/errores/errores-dominio';
import { VisitasRepositoryFalso } from '../../../../../testing/visitas-repository.falso';
import { ObtenerVisita } from './obtener-visita';

describe('ObtenerVisita', () => {
  it('obtener_conId_devuelveLaVisitaDelRepositorio', async () => {
    const v = await new ObtenerVisita(new VisitasRepositoryFalso()).ejecutar('s7');
    expect(v.id).toBe('s7');
  });

  it('obtener_sinId_lanzaErrorValidacion', async () => {
    let error: unknown = null;
    try {
      await new ObtenerVisita(new VisitasRepositoryFalso()).ejecutar('  ');
    } catch (e) {
      error = e;
    }
    expect(error instanceof ErrorValidacion).toBe(true);
  });
});
