import { TestBed } from '@angular/core/testing';
import { MensajeErrorComponent } from './mensaje-error.component';

/** Prueba de componente (nivel UI de la pirámide): renderiza y emite, sin lógica de negocio. */
describe('MensajeErrorComponent', () => {
  it('render_conMensaje_loMuestraComoAlerta', async () => {
    const fixture = TestBed.createComponent(MensajeErrorComponent);
    fixture.componentRef.setInput('mensaje', 'No hay conexión con el servidor.');
    await fixture.whenStable();

    const alerta = (fixture.nativeElement as HTMLElement).querySelector('[role="alert"]');
    expect(alerta?.textContent).toContain('No hay conexión con el servidor.');
  });

  it('reintentar_alPulsarElBoton_emiteElEvento', async () => {
    const fixture = TestBed.createComponent(MensajeErrorComponent);
    fixture.componentRef.setInput('mensaje', 'Error');
    let reintentos = 0;
    fixture.componentInstance.reintentar.subscribe(() => reintentos++);
    await fixture.whenStable();

    (fixture.nativeElement as HTMLElement).querySelector('ion-button')?.dispatchEvent(new Event('click'));

    expect(reintentos).toBe(1);
  });
});
