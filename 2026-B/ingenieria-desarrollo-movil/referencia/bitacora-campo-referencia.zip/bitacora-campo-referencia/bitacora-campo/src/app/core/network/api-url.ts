import { InjectionToken } from '@angular/core';
import { Capacitor } from '@capacitor/core';
import { environment } from '../../../environments/environment';

/**
 * URL base de la API. En producción la fija `environment.prod.ts` (HTTPS).
 * En desarrollo: en el emulador de Android, 10.0.2.2 es el «localhost» del computador.
 */
export const API_URL = new InjectionToken<string>('API_URL', {
  providedIn: 'root',
  factory: () =>
    environment.apiUrl ??
    (Capacitor.getPlatform() === 'android' ? 'http://10.0.2.2:3000' : 'http://localhost:3000'),
});
