import { ErrorValidacion } from '../../../core/errores/errores-dominio';
import { AuthRepositoryFalso } from '../../../../testing/auth-repository.falso';
import { IniciarSesion } from './iniciar-sesion';

describe('IniciarSesion', () => {
  async function errorDe(p: Promise<unknown>): Promise<unknown> {
    try {
      await p;
    } catch (e) {
      return e;
    }
    return null;
  }

  it('iniciar_conCredencialesBienFormadas_recortaElUsuarioYDelega', async () => {
    const repo = new AuthRepositoryFalso();

    const sesion = await new IniciarSesion(repo).ejecutar('  tecnico ', 'campo123');

    expect(repo.intentos).toEqual([{ usuario: 'tecnico', clave: 'campo123' }]);
    expect(sesion.nombre).toBe('Técnica de campo');
  });

  it('iniciar_conUsuarioVacio_lanzaErrorValidacionSinIrALaRed', async () => {
    const repo = new AuthRepositoryFalso();

    expect((await errorDe(new IniciarSesion(repo).ejecutar('   ', 'campo123'))) instanceof ErrorValidacion).toBe(true);
    expect(repo.intentos.length).toBe(0);
  });

  it('iniciar_conClaveCorta_lanzaErrorValidacion', async () => {
    const repo = new AuthRepositoryFalso();

    expect((await errorDe(new IniciarSesion(repo).ejecutar('tecnico', '123'))) instanceof ErrorValidacion).toBe(true);
    expect(repo.intentos.length).toBe(0);
  });
});
