import { ErrorValidacion } from '../../../core/errores/errores-dominio';
import { DatosVisita, ESTADOS_VISITA, EstadoVisita, Visita } from './visita';

export const LIMITES_VISITA = {
  clienteMin: 3,
  clienteMax: 120,
  direccionMax: 200,
  observacionesMax: 500,
} as const;

export const MENSAJE_REALIZADA_SIN_FOTO = 'Para marcar la visita como realizada, captura la foto de evidencia.';
export const MENSAJE_REALIZADA_NO_SE_ELIMINA = 'Las visitas realizadas no se eliminan: son el registro del trabajo de campo.';

/**
 * Reglas de negocio de una visita. Devuelve una copia normalizada (espacios recortados) o lanza
 * ErrorValidacion. La UI valida lo mismo para dar retroalimentación inmediata, pero la regla
 * que manda es esta.
 */
export function validarDatosVisita(datos: DatosVisita): DatosVisita {
  const cliente = datos.cliente.trim();
  const direccion = datos.direccion.trim();
  const observaciones = datos.observaciones.trim();
  if (cliente.length < LIMITES_VISITA.clienteMin) {
    throw new ErrorValidacion(`El cliente debe tener mínimo ${LIMITES_VISITA.clienteMin} caracteres.`);
  }
  if (cliente.length > LIMITES_VISITA.clienteMax) {
    throw new ErrorValidacion(`El cliente admite máximo ${LIMITES_VISITA.clienteMax} caracteres.`);
  }
  if (direccion.length > LIMITES_VISITA.direccionMax) {
    throw new ErrorValidacion(`La dirección admite máximo ${LIMITES_VISITA.direccionMax} caracteres.`);
  }
  if (observaciones.length > LIMITES_VISITA.observacionesMax) {
    throw new ErrorValidacion(`Las observaciones admiten máximo ${LIMITES_VISITA.observacionesMax} caracteres.`);
  }
  if (!ESTADOS_VISITA.includes(datos.estado)) throw new ErrorValidacion('Estado de visita desconocido.');
  if (datos.estado === 'realizada' && !datos.foto) throw new ErrorValidacion(MENSAJE_REALIZADA_SIN_FOTO);
  return { ...datos, cliente, direccion, observaciones };
}

/** Orden de la jornada: primero las pendientes; dentro de cada grupo, las más recientes arriba. */
export function ordenarParaJornada(visitas: readonly Visita[]): Visita[] {
  return [...visitas].sort((a, b) => {
    const prioridad = Number(b.estado === 'pendiente') - Number(a.estado === 'pendiente');
    return prioridad !== 0 ? prioridad : b.creadaEn.getTime() - a.creadaEn.getTime();
  });
}

export type ResumenVisitas = Readonly<Record<EstadoVisita, number> & { total: number }>;

export function resumirVisitas(visitas: readonly Visita[]): ResumenVisitas {
  const r = { pendiente: 0, realizada: 0, cancelada: 0, total: visitas.length };
  for (const v of visitas) r[v.estado]++;
  return r;
}
