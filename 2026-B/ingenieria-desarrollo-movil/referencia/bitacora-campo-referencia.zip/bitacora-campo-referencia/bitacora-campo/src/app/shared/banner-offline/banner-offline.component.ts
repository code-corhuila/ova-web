import { DatePipe } from '@angular/common';
import { ChangeDetectionStrategy, Component, input } from '@angular/core';
import { IonIcon } from '@ionic/angular';
import { addIcons } from 'ionicons';
import { cloudOfflineOutline } from 'ionicons/icons';

/** Aviso de datos desactualizados (offline): ícono + texto, no solo color. */
@Component({
  selector: 'app-banner-offline',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [IonIcon, DatePipe],
  template: `
    <div class="banner" role="status">
      <ion-icon name="cloud-offline-outline" aria-hidden="true"></ion-icon>
      <span>Sin conexión. Datos guardados el {{ sincronizadoEn() | date: 'd MMM, h:mm a' }}.</span>
    </div>
  `,
  styles: `
    .banner { display: flex; align-items: center; gap: var(--bc-espacio-sm); padding: var(--bc-espacio-sm) var(--bc-espacio-lg);
      background: var(--bc-color-aviso-fondo); color: var(--bc-color-aviso-texto); font-size: var(--bc-texto-nota); }
    ion-icon { font-size: 20px; flex-shrink: 0; }
  `,
})
export class BannerOfflineComponent {
  readonly sincronizadoEn = input.required<Date>();

  constructor() {
    addIcons({ cloudOfflineOutline });
  }
}
