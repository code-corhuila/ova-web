import { InjectionToken } from '@angular/core';
import { CacheLocal } from './cache-local.port';
import { PreferencesCacheLocal } from './preferences-cache-local';
import { SecureTokenStore } from './secure-token-store';
import { TokenStore } from './token-store.port';

/** Puerto TokenStore → adaptador seguro por defecto. Las pruebas lo sobrescriben con un doble. */
export const TOKEN_STORE = new InjectionToken<TokenStore>('TOKEN_STORE', {
  providedIn: 'root',
  factory: () => new SecureTokenStore(),
});

/** Puerto CacheLocal → adaptador sobre Preferences. */
export const CACHE_LOCAL = new InjectionToken<CacheLocal>('CACHE_LOCAL', {
  providedIn: 'root',
  factory: () => new PreferencesCacheLocal(),
});
