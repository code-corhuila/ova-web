import { HttpContextToken, HttpInterceptorFn } from '@angular/common/http';
import { timeout } from 'rxjs';

/** Tiempo límite por petición. Se cambia por llamada con `new HttpContext().set(TIEMPO_LIMITE_MS, n)`. */
export const TIEMPO_LIMITE_MS = new HttpContextToken<number>(() => 10_000);

/**
 * Ninguna petición queda sin límite. `timeout(n)` mide el tiempo entre eventos: desde el envío
 * hasta la respuesta. Va al final de la cadena: cada intento (también el reintento tras el
 * refresh) tiene su propio límite. El TimeoutError lo traduce `erroresInterceptor`.
 */
export const timeoutInterceptor: HttpInterceptorFn = (req, next) =>
  next(req).pipe(timeout(req.context.get(TIEMPO_LIMITE_MS)));
