import { HttpErrorResponse, HttpInterceptorFn, HttpRequest } from '@angular/common/http';
import { inject } from '@angular/core';
import { catchError, from, switchMap, throwError } from 'rxjs';
import { SesionService } from '../sesion/sesion.service';

/** Endpoints de autenticación: no llevan Bearer ni disparan refresh (evita ciclos). */
export function esRutaDeAutenticacion(url: string): boolean {
  return /\/auth\/(login|refresh|logout)(\?|$)/.test(url);
}

function conBearer(req: HttpRequest<unknown>, token: string): HttpRequest<unknown> {
  return req.clone({ setHeaders: { Authorization: `Bearer ${token}` } });
}

/**
 * Único lugar donde se adjunta el token (03-api-y-datos/autenticacion.md):
 * 1. agrega `Authorization: Bearer <accessToken>`;
 * 2. ante un 401, pide UN access token nuevo (SesionService serializa los refresh simultáneos);
 * 3. reintenta la petición original UNA sola vez: el error del reintento ya no pasa por este
 *    catchError, así que no hay bucles;
 * 4. si el refresh es rechazado, SesionService cierra la sesión y el error sube como
 *    ErrorSesionExpirada.
 */
export const authInterceptor: HttpInterceptorFn = (req, next) => {
  if (esRutaDeAutenticacion(req.url)) return next(req);
  const sesion = inject(SesionService);
  const tokenUsado = sesion.accessToken;
  if (!tokenUsado) return next(req);

  return next(conBearer(req, tokenUsado)).pipe(
    catchError((error: unknown) => {
      if (!(error instanceof HttpErrorResponse) || error.status !== 401) return throwError(() => error);
      return from(sesion.refrescar(tokenUsado)).pipe(switchMap((nuevo) => next(conBearer(req, nuevo))));
    }),
  );
};
