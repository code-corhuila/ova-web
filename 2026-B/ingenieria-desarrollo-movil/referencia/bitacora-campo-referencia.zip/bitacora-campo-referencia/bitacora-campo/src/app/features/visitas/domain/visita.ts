import type { Coordenadas } from '../../../core/nativo/ubicacion.port';

export type EstadoVisita = 'pendiente' | 'realizada' | 'cancelada';

export const ESTADOS_VISITA: readonly EstadoVisita[] = ['pendiente', 'realizada', 'cancelada'];

/** Entidad del dominio. Inmutable; usa tipos del negocio (Date, Coordenadas), no los del JSON. */
export interface Visita {
  readonly id: string;
  readonly cliente: string;
  readonly direccion: string;
  readonly estado: EstadoVisita;
  readonly observaciones: string;
  /** Foto de evidencia como data URL, o null si aún no se tomó. */
  readonly foto: string | null;
  readonly ubicacion: Coordenadas | null;
  readonly creadaEn: Date;
  readonly actualizadaEn: Date;
}

/** Lo que la persona técnica escribe o captura: la visita sin identidad ni fechas. */
export type DatosVisita = Omit<Visita, 'id' | 'creadaEn' | 'actualizadaEn'>;

/** Resultado de listar: además de las visitas, dice si vienen de la caché (offline). */
export interface ListaVisitas {
  readonly visitas: readonly Visita[];
  /** true si la red falló y estas son las últimas visitas guardadas en el dispositivo. */
  readonly desactualizado: boolean;
  /** Cuándo se obtuvieron del servidor. */
  readonly sincronizadoEn: Date;
}

export type { Coordenadas };
