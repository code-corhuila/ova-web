import { ordenarParaJornada } from '../reglas-visita';
import { ListaVisitas } from '../visita';
import { VisitasRepository } from '../visitas.repository';

/** Caso de uso: listar las visitas de la jornada, ordenadas (pendientes primero). */
export class ListarVisitas {
  constructor(private readonly repositorio: VisitasRepository) {}

  async ejecutar(): Promise<ListaVisitas> {
    const lista = await this.repositorio.listar();
    return { ...lista, visitas: ordenarParaJornada(lista.visitas) };
  }
}
