import { ErrorDominio } from '../../../core/errores/errores-dominio';

/** Error propio de la feature: un 401 en /auth/login NO es «sesión expirada». */
export class CredencialesInvalidasError extends ErrorDominio {
  readonly codigo = 'CREDENCIALES_INVALIDAS';
  constructor() {
    super('Usuario o clave incorrectos.');
  }
}
