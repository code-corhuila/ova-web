import { DatosVisita, ListaVisitas, Visita } from './visita';

/**
 * Puerto del dominio de visitas. El dominio declara QUÉ necesita; data/ decide CÓMO
 * (HTTP + caché de lectura en visitas-http.repository.ts). Los errores que lanza son de dominio.
 */
export interface VisitasRepository {
  /** Lee en línea; si no hay red devuelve la caché marcada como desactualizada. */
  listar(): Promise<ListaVisitas>;
  obtener(id: string): Promise<Visita>;
  crear(datos: DatosVisita): Promise<Visita>;
  actualizar(id: string, datos: DatosVisita): Promise<Visita>;
  eliminar(id: string): Promise<void>;
}
