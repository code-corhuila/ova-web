import { HttpClient } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { firstValueFrom } from 'rxjs';
import { esErrorDeConectividad } from '../../../core/errores/errores-dominio';
import { API_URL } from '../../../core/network/api-url';
import { CACHE_LOCAL } from '../../../core/storage/storage.tokens';
import { DatosVisita, ListaVisitas, Visita } from '../domain/visita';
import { VisitasRepository } from '../domain/visitas.repository';
import { VisitaDto } from './visita.dto';
import { aVisita, aVisitaEntradaDto, aVisitas } from './visita.mapper';

/** Clave versionada de la caché: si cambia la forma del DTO se sube a v2 (ver entidad-visita-cache.md). */
export const CLAVE_CACHE_VISITAS = 'visitas.lista.v1';

/**
 * Implementación del puerto VisitasRepository: HTTP + CACHÉ DE LECTURA (ADR-002, offline.md).
 *
 * - Lectura: en línea guarda la respuesta; sin red (ErrorSinConexion / ErrorTiempoAgotado) devuelve
 *   lo último guardado marcado `desactualizado: true`. Sin red y sin caché, el error sube.
 * - Escritura: SOLO en línea (POST/PUT/DELETE no se reintentan ni se encolan). Si tiene éxito,
 *   la caché se actualiza para que la próxima lectura offline ya incluya el cambio.
 * - La caché guarda DTOs (modelo persistido ≠ entidad de dominio) y se mapea al leer.
 */
@Injectable({ providedIn: 'root' })
export class VisitasHttpRepository implements VisitasRepository {
  private readonly http = inject(HttpClient);
  private readonly api = inject(API_URL);
  private readonly cache = inject(CACHE_LOCAL);

  async listar(): Promise<ListaVisitas> {
    try {
      const respuesta = await firstValueFrom(this.http.get<unknown>(`${this.api}/visitas`));
      const visitas = aVisitas(respuesta); // valida el contrato ANTES de guardar en caché
      await this.cache.guardar(CLAVE_CACHE_VISITAS, respuesta as VisitaDto[]);
      return { visitas, desactualizado: false, sincronizadoEn: new Date() };
    } catch (e) {
      if (!esErrorDeConectividad(e)) throw e;
      const guardado = await this.cache.leer<VisitaDto[]>(CLAVE_CACHE_VISITAS);
      if (!guardado) throw e;
      return { visitas: aVisitas(guardado.valor), desactualizado: true, sincronizadoEn: new Date(guardado.guardadoEn) };
    }
  }

  async obtener(id: string): Promise<Visita> {
    try {
      return aVisita(await firstValueFrom(this.http.get<unknown>(`${this.api}/visitas/${encodeURIComponent(id)}`)));
    } catch (e) {
      if (!esErrorDeConectividad(e)) throw e;
      const enCache = (await this.cache.leer<VisitaDto[]>(CLAVE_CACHE_VISITAS))?.valor.find((v) => v.id === id);
      if (!enCache) throw e;
      return aVisita(enCache);
    }
  }

  async crear(datos: DatosVisita): Promise<Visita> {
    const dto = await firstValueFrom(this.http.post<unknown>(`${this.api}/visitas`, aVisitaEntradaDto(datos)));
    const visita = aVisita(dto);
    await this.actualizarCache((lista) => [...lista, dto as VisitaDto]);
    return visita;
  }

  async actualizar(id: string, datos: DatosVisita): Promise<Visita> {
    const dto = await firstValueFrom(
      this.http.put<unknown>(`${this.api}/visitas/${encodeURIComponent(id)}`, aVisitaEntradaDto(datos)),
    );
    const visita = aVisita(dto);
    await this.actualizarCache((lista) => lista.map((v) => (v.id === id ? (dto as VisitaDto) : v)));
    return visita;
  }

  async eliminar(id: string): Promise<void> {
    await firstValueFrom(this.http.delete(`${this.api}/visitas/${encodeURIComponent(id)}`));
    await this.actualizarCache((lista) => lista.filter((v) => v.id !== id));
  }

  private async actualizarCache(cambio: (lista: VisitaDto[]) => VisitaDto[]): Promise<void> {
    const guardado = await this.cache.leer<VisitaDto[]>(CLAVE_CACHE_VISITAS);
    if (guardado) await this.cache.guardar(CLAVE_CACHE_VISITAS, cambio(guardado.valor));
  }
}
