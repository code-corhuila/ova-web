import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { Router, UrlTree, provideRouter } from '@angular/router';
import { CacheLocalFalsa, TokenStoreFalso } from '../../../testing/almacenamiento.falso';
import { API_URL } from '../network/api-url';
import { CACHE_LOCAL, TOKEN_STORE } from '../storage/storage.tokens';
import { authGuard } from './auth.guard';
import { SesionService } from './sesion.service';

describe('SesionService', () => {
  let sesion: SesionService;
  let tokens: TokenStoreFalso;
  let cache: CacheLocalFalsa;
  let backend: HttpTestingController;

  beforeEach(() => {
    tokens = new TokenStoreFalso();
    cache = new CacheLocalFalsa();
    TestBed.configureTestingModule({
      providers: [
        provideHttpClient(),
        provideHttpClientTesting(),
        provideRouter([]),
        { provide: API_URL, useValue: 'http://api' },
        { provide: TOKEN_STORE, useValue: tokens },
        { provide: CACHE_LOCAL, useValue: cache },
      ],
    });
    sesion = TestBed.inject(SesionService);
    backend = TestBed.inject(HttpTestingController);
  });
  afterEach(() => backend.verify());

  it('restaurar_conTokensGuardados_quedaAutenticado', async () => {
    tokens.tokens = { accessToken: 'a', refreshToken: 'r' };

    await sesion.restaurar();

    expect(sesion.autenticado()).toBe(true);
    expect(sesion.accessToken).toBe('a');
  });

  it('restaurar_sinTokens_quedaSinSesion', async () => {
    await sesion.restaurar();
    expect(sesion.autenticado()).toBe(false);
    expect(sesion.accessToken).toBeNull();
  });

  it('cerrar_revocaElRefreshTokenYBorraTokensYCache', async () => {
    await sesion.iniciar({ accessToken: 'a', refreshToken: 'r' });
    await cache.guardar('visitas.lista.v1', []);

    const p = sesion.cerrar();
    const req = backend.expectOne('http://api/auth/logout');
    expect(req.request.body).toEqual({ refreshToken: 'r' });
    req.flush(null, { status: 204, statusText: 'No Content' });
    await p;

    expect(sesion.autenticado()).toBe(false);
    expect(tokens.tokens).toBeNull();
    expect(cache.limpiezas).toBe(1);
  });

  it('cerrar_sinRed_igualBorraTodoLocalmente', async () => {
    await sesion.iniciar({ accessToken: 'a', refreshToken: 'r' });

    const p = sesion.cerrar();
    backend.expectOne('http://api/auth/logout').error(new ProgressEvent('error'));
    await p;

    expect(tokens.borrados).toBe(1);
    expect(sesion.autenticado()).toBe(false);
  });

  it('refrescar_conTokenYaRenovadoPorOtraPeticion_reutilizaElActualSinLlamarALaApi', async () => {
    await sesion.iniciar({ accessToken: 'actual', refreshToken: 'r' });

    expect(await sesion.refrescar('viejo')).toBe('actual');
    backend.expectNone('http://api/auth/refresh');
  });

  it('authGuard_sinSesion_redirigeALogin', () => {
    const r = TestBed.runInInjectionContext(() => authGuard({} as never, {} as never));
    expect(r instanceof UrlTree).toBe(true);
    expect(TestBed.inject(Router).serializeUrl(r as UrlTree)).toBe('/login');
  });

  it('authGuard_conSesion_dejaPasar', async () => {
    await sesion.iniciar({ accessToken: 'a', refreshToken: 'r' });
    expect(TestBed.runInInjectionContext(() => authGuard({} as never, {} as never))).toBe(true);
  });
});
