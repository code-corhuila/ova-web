import { AbstractControl, ValidationErrors, ValidatorFn } from '@angular/forms';

/**
 * Validador propio: rechaza un texto que solo tiene espacios («   » pasaría `required` y `minLength`).
 * El texto vacío lo valida `Validators.required`, no este.
 */
export const sinSoloEspacios: ValidatorFn = (control: AbstractControl): ValidationErrors | null =>
  typeof control.value === 'string' && control.value.length > 0 && control.value.trim().length === 0
    ? { soloEspacios: true }
    : null;
