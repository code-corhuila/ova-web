import { ErrorDatosInvalidos } from '../../../core/errores/errores-dominio';
import { DatosVisita, ESTADOS_VISITA, EstadoVisita, Visita } from '../domain/visita';
import { VisitaDto, VisitaEntradaDto } from './visita.dto';

/**
 * DTO → dominio. Valida el contrato y transforma:
 *   estado string → EstadoVisita · creada/actualizada ISO → Date · lat/lng sueltos → ubicacion | null.
 * Si el payload no cumple el contrato lanza ErrorDatosInvalidos (fallar fuerte, no adivinar).
 */
export function aVisita(dto: unknown): Visita {
  if (!esVisitaDto(dto)) throw new ErrorDatosInvalidos('Visita con campos faltantes o de tipo incorrecto');
  if (!esEstado(dto.estado)) throw new ErrorDatosInvalidos(`Estado desconocido: ${dto.estado}`);
  const creadaEn = aFecha(dto.creada, 'creada');
  return {
    id: dto.id,
    cliente: dto.cliente,
    direccion: dto.direccion,
    estado: dto.estado,
    observaciones: dto.observaciones,
    foto: dto.foto,
    ubicacion: dto.lat !== null && dto.lng !== null ? { lat: dto.lat, lng: dto.lng } : null,
    creadaEn,
    actualizadaEn: dto.actualizada ? aFecha(dto.actualizada, 'actualizada') : creadaEn,
  };
}

export function aVisitas(dtos: unknown): Visita[] {
  if (!Array.isArray(dtos)) throw new ErrorDatosInvalidos('Se esperaba una lista de visitas');
  return dtos.map(aVisita);
}

/** Dominio → DTO de entrada para POST/PUT. */
export function aVisitaEntradaDto(datos: DatosVisita): VisitaEntradaDto {
  return {
    cliente: datos.cliente,
    direccion: datos.direccion,
    estado: datos.estado,
    observaciones: datos.observaciones,
    foto: datos.foto,
    lat: datos.ubicacion?.lat ?? null,
    lng: datos.ubicacion?.lng ?? null,
  };
}

function esEstado(v: string): v is EstadoVisita {
  return (ESTADOS_VISITA as readonly string[]).includes(v);
}

function aFecha(iso: string, campo: string): Date {
  const fecha = new Date(iso);
  if (Number.isNaN(fecha.getTime())) throw new ErrorDatosInvalidos(`Fecha inválida en ${campo}: ${iso}`);
  return fecha;
}

function esVisitaDto(v: unknown): v is VisitaDto {
  if (typeof v !== 'object' || v === null) return false;
  const d = v as Record<string, unknown>;
  const textoONulo = (x: unknown) => x === null || typeof x === 'string';
  const numeroONulo = (x: unknown) => x === null || typeof x === 'number';
  return (
    typeof d['id'] === 'string' &&
    typeof d['cliente'] === 'string' &&
    typeof d['direccion'] === 'string' &&
    typeof d['estado'] === 'string' &&
    typeof d['observaciones'] === 'string' &&
    textoONulo(d['foto']) &&
    numeroONulo(d['lat']) &&
    numeroONulo(d['lng']) &&
    typeof d['creada'] === 'string' &&
    (d['actualizada'] === undefined || typeof d['actualizada'] === 'string')
  );
}
