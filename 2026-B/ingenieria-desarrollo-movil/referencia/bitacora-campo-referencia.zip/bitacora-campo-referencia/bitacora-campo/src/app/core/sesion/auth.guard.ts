import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { SesionService } from './sesion.service';

/** Rutas protegidas: sin sesión, redirige a /login. Se declara en app.routes.ts, no en las pantallas. */
export const authGuard: CanActivateFn = () =>
  inject(SesionService).autenticado() ? true : inject(Router).createUrlTree(['/login']);

/** /login solo para quien no tiene sesión: con sesión, va directo a /visitas. */
export const invitadoGuard: CanActivateFn = () =>
  inject(SesionService).autenticado() ? inject(Router).createUrlTree(['/visitas']) : true;
