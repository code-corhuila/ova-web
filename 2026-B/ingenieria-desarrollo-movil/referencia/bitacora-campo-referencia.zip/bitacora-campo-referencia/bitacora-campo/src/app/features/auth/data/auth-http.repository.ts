import { HttpClient } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { firstValueFrom } from 'rxjs';
import { ErrorSesionExpirada } from '../../../core/errores/errores-dominio';
import { API_URL } from '../../../core/network/api-url';
import { SesionService } from '../../../core/sesion/sesion.service';
import { AuthRepository } from '../domain/auth.repository';
import { CredencialesInvalidasError } from '../domain/credenciales-invalidas.error';
import { Sesion } from '../domain/sesion';
import { LoginSolicitudDto } from './login.dto';
import { aSesionIniciada } from './sesion.mapper';

/** Implementación HTTP del puerto AuthRepository. */
@Injectable({ providedIn: 'root' })
export class AuthHttpRepository implements AuthRepository {
  private readonly http = inject(HttpClient);
  private readonly api = inject(API_URL);
  private readonly sesion = inject(SesionService);

  async iniciarSesion(usuario: string, clave: string): Promise<Sesion> {
    const cuerpo: LoginSolicitudDto = { usuario, clave };
    try {
      const dto = await firstValueFrom(this.http.post<unknown>(`${this.api}/auth/login`, cuerpo));
      const { sesion, tokens } = aSesionIniciada(dto);
      await this.sesion.iniciar(tokens);
      return sesion;
    } catch (e) {
      // El interceptor traduce todo 401 a ErrorSesionExpirada; en el login significa otra cosa.
      if (e instanceof ErrorSesionExpirada) throw new CredencialesInvalidasError();
      throw e;
    }
  }

  cerrarSesion(): Promise<void> {
    return this.sesion.cerrar();
  }
}
