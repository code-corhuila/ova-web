import { DestroyRef, Injectable, inject } from '@angular/core';
import { toSignal } from '@angular/core/rxjs-interop';
import { BehaviorSubject } from 'rxjs';
import { mensajeDeError } from '../../../../core/errores/errores-dominio';
import { ActualizarVisita } from '../../domain/casos-de-uso/actualizar-visita';
import { CapturarEvidencia } from '../../domain/casos-de-uso/capturar-evidencia';
import { ObtenerVisita } from '../../domain/casos-de-uso/obtener-visita';
import { RegistrarVisita } from '../../domain/casos-de-uso/registrar-visita';
import { Coordenadas, DatosVisita, EstadoVisita } from '../../domain/visita';

export type FaseFormulario = 'cargando' | 'editando' | 'guardando' | 'guardado' | 'error';

/** Campos que la persona escribe en el formulario reactivo (la evidencia la aporta el ViewModel). */
export interface CamposVisita {
  cliente: string;
  direccion: string;
  estado: EstadoVisita;
  observaciones: string;
}

/** Estado inmutable del formulario de visita. */
export interface EstadoFormulario {
  readonly fase: FaseFormulario;
  readonly modo: 'nueva' | 'edicion';
  readonly foto: string | null;
  readonly ubicacion: Coordenadas | null;
  readonly capturando: boolean;
  /** Error al cargar (fase error) o al guardar (fase editando): bloquea hasta corregir. */
  readonly error: string | null;
  /** Aviso no bloqueante (p. ej. evidencia sin ubicación). */
  readonly aviso: string | null;
}

export const ESTADO_FORMULARIO_INICIAL: EstadoFormulario = {
  fase: 'editando',
  modo: 'nueva',
  foto: null,
  ubicacion: null,
  capturando: false,
  error: null,
  aviso: null,
};

/** ViewModel de /visitas/nueva y /visitas/:id (mismo patrón que la lista; ADR-001). */
@Injectable()
export class VisitaFormViewModel {
  private readonly obtenerVisita = inject(ObtenerVisita);
  private readonly registrarVisita = inject(RegistrarVisita);
  private readonly actualizarVisita = inject(ActualizarVisita);
  private readonly capturarEvidencia = inject(CapturarEvidencia);
  private readonly estado$ = new BehaviorSubject<EstadoFormulario>(ESTADO_FORMULARIO_INICIAL);
  private id: string | null = null;
  private activo = true;

  readonly estado = toSignal(this.estado$, { requireSync: true });

  constructor() {
    inject(DestroyRef).onDestroy(() => (this.activo = false));
  }

  /**
   * Prepara el formulario. Con id, trae la visita (la ruta pasa el id, no el objeto).
   * @returns los campos para precargar el formulario, o null si es una visita nueva o falló.
   */
  async iniciar(id: string | null): Promise<CamposVisita | null> {
    this.id = id;
    if (!id) {
      this.emitir(ESTADO_FORMULARIO_INICIAL);
      return null;
    }
    this.emitir({ ...ESTADO_FORMULARIO_INICIAL, modo: 'edicion', fase: 'cargando' });
    try {
      const v = await this.obtenerVisita.ejecutar(id);
      this.emitir({ ...this.estado$.value, fase: 'editando', foto: v.foto, ubicacion: v.ubicacion });
      return { cliente: v.cliente, direccion: v.direccion, estado: v.estado, observaciones: v.observaciones };
    } catch (e) {
      this.emitir({ ...this.estado$.value, fase: 'error', error: mensajeDeError(e) });
      return null;
    }
  }

  async tomarEvidencia(): Promise<void> {
    this.emitir({ ...this.estado$.value, capturando: true, error: null, aviso: null });
    try {
      const evidencia = await this.capturarEvidencia.ejecutar();
      this.emitir({
        ...this.estado$.value,
        capturando: false,
        foto: evidencia.foto,
        ubicacion: evidencia.ubicacion,
        aviso: evidencia.aviso,
      });
    } catch (e) {
      this.emitir({ ...this.estado$.value, capturando: false, error: mensajeDeError(e) });
    }
  }

  /** @returns true si se guardó (la pantalla vuelve a la lista). */
  async guardar(campos: CamposVisita): Promise<boolean> {
    const previo = this.estado$.value;
    if (previo.fase === 'guardando' || previo.capturando) return false;
    this.emitir({ ...previo, fase: 'guardando', error: null });
    const datos: DatosVisita = { ...campos, foto: previo.foto, ubicacion: previo.ubicacion };
    try {
      if (this.id) await this.actualizarVisita.ejecutar(this.id, datos);
      else await this.registrarVisita.ejecutar(datos);
      this.emitir({ ...this.estado$.value, fase: 'guardado' });
      return true;
    } catch (e) {
      this.emitir({ ...this.estado$.value, fase: 'editando', error: mensajeDeError(e) });
      return false;
    }
  }

  private emitir(estado: EstadoFormulario): void {
    if (this.activo) this.estado$.next(estado);
  }
}
