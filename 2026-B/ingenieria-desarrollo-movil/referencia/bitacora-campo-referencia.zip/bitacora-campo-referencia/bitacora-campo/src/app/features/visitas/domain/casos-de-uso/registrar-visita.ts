import { validarDatosVisita } from '../reglas-visita';
import { DatosVisita, Visita } from '../visita';
import { VisitasRepository } from '../visitas.repository';

/** Caso de uso: registrar una visita nueva. Valida las reglas antes de ir a la red. */
export class RegistrarVisita {
  constructor(private readonly repositorio: VisitasRepository) {}

  async ejecutar(datos: DatosVisita): Promise<Visita> {
    return this.repositorio.crear(validarDatosVisita(datos));
  }
}
