import { ErrorDatosInvalidos } from '../../../core/errores/errores-dominio';
import { TokensSesion } from '../../../core/storage/token-store.port';
import { Sesion } from '../domain/sesion';
import { LoginRespuestaDto } from './login.dto';

/** DTO de login → (entidad Sesion, tokens). Falla fuerte si el contrato no se cumple. */
export function aSesionIniciada(dto: unknown): { sesion: Sesion; tokens: TokensSesion } {
  if (!esLoginRespuesta(dto)) throw new ErrorDatosInvalidos('POST /auth/login: faltan accessToken, refreshToken o nombre');
  return {
    sesion: { nombre: dto.nombre },
    tokens: { accessToken: dto.accessToken, refreshToken: dto.refreshToken },
  };
}

function esLoginRespuesta(v: unknown): v is LoginRespuestaDto {
  if (typeof v !== 'object' || v === null) return false;
  const d = v as Record<string, unknown>;
  return typeof d['accessToken'] === 'string' && typeof d['refreshToken'] === 'string' && typeof d['nombre'] === 'string';
}
