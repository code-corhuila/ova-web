import { provideHttpClient, withInterceptors } from '@angular/common/http';
import { EnvironmentProviders, inject, makeEnvironmentProviders, provideAppInitializer } from '@angular/core';
import { authInterceptor } from '../network/auth.interceptor';
import { correlationIdInterceptor } from '../network/correlation-id.interceptor';
import { erroresInterceptor } from '../network/errores.interceptor';
import { timeoutInterceptor } from '../network/timeout.interceptor';
import { SesionService } from '../sesion/sesion.service';

/**
 * Raíz de composición de core/: EL cliente HTTP de la app y el arranque de la sesión.
 *
 * Orden de los interceptores (la petición baja en este orden; la respuesta sube al revés):
 *   correlation-id → errores → auth (token + refresh) → timeout → red
 * - errores va antes de auth: traduce el error FINAL (después del reintento).
 * - timeout va al final: cada intento tiene su propio límite.
 *
 * Los adaptadores de los puertos (TokenStore, CacheLocal, Camara, Ubicacion) no se registran
 * aquí: cada InjectionToken trae su factory (ver storage.tokens.ts y nativo.tokens.ts).
 */
export function provideCore(): EnvironmentProviders {
  return makeEnvironmentProviders([
    provideHttpClient(withInterceptors([correlationIdInterceptor, erroresInterceptor, authInterceptor, timeoutInterceptor])),
    provideAppInitializer(() => inject(SesionService).restaurar()),
  ]);
}
