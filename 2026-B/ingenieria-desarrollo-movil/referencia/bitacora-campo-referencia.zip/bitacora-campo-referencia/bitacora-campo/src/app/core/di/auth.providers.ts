import { InjectionToken, Provider, inject } from '@angular/core';
import { AuthHttpRepository } from '../../features/auth/data/auth-http.repository';
import { AuthRepository } from '../../features/auth/domain/auth.repository';
import { CerrarSesion } from '../../features/auth/domain/cerrar-sesion';
import { IniciarSesion } from '../../features/auth/domain/iniciar-sesion';

/**
 * Raíz de composición (core/di/) para la feature auth: aquí, y solo aquí, se une su dominio con data/.
 * Se registra en app.config.ts porque la sesión es transversal (el menú usa CerrarSesion).
 */
export const AUTH_REPOSITORY = new InjectionToken<AuthRepository>('AUTH_REPOSITORY', {
  providedIn: 'root',
  factory: () => inject(AuthHttpRepository),
});

export function provideAuth(): Provider[] {
  return [
    { provide: IniciarSesion, useFactory: () => new IniciarSesion(inject(AUTH_REPOSITORY)) },
    { provide: CerrarSesion, useFactory: () => new CerrarSesion(inject(AUTH_REPOSITORY)) },
  ];
}
