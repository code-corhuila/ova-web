import { Component, inject } from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { RouterLink } from '@angular/router';
import {
  IonApp,
  IonContent,
  IonHeader,
  IonIcon,
  IonItem,
  IonLabel,
  IonList,
  IonMenu,
  IonMenuToggle,
  IonRouterOutlet,
  IonTitle,
  IonToolbar,
  MenuController,
  NavController,
  ToastController,
} from '@ionic/angular';
import { addIcons } from 'ionicons';
import { clipboardOutline, logOutOutline } from 'ionicons/icons';
import { SesionService } from './core/sesion/sesion.service';
import { CerrarSesion } from './features/auth/domain/cerrar-sesion';

/**
 * Shell de la app: menú lateral + router outlet. Es el único que reacciona a la expiración de
 * la sesión (navega al login): la capa de red avisa, pero no conoce rutas.
 */
@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  imports: [RouterLink, IonApp, IonRouterOutlet, IonMenu, IonMenuToggle, IonHeader, IonToolbar, IonTitle, IonContent, IonList, IonItem, IonIcon, IonLabel],
})
export class AppComponent {
  private readonly sesion = inject(SesionService);
  private readonly cerrarSesion = inject(CerrarSesion);
  private readonly nav = inject(NavController);
  private readonly menu = inject(MenuController);
  private readonly toasts = inject(ToastController);
  protected readonly autenticado = this.sesion.autenticado;

  constructor() {
    addIcons({ clipboardOutline, logOutOutline });
    this.sesion.expirada$.pipe(takeUntilDestroyed()).subscribe(() => void this.alExpirar());
  }

  async salir(): Promise<void> {
    await this.menu.close();
    await this.cerrarSesion.ejecutar();
    await this.nav.navigateRoot('/login');
  }

  private async alExpirar(): Promise<void> {
    await this.nav.navigateRoot('/login');
    const toast = await this.toasts.create({ message: 'Tu sesión expiró. Ingresa de nuevo.', duration: 3000 });
    await toast.present();
  }
}
