import { Component, inject } from '@angular/core';
import { NonNullableFormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import {
  IonButton,
  IonContent,
  IonHeader,
  IonInput,
  IonItem,
  IonList,
  IonNote,
  IonSpinner,
  IonText,
  IonTitle,
  IonToolbar,
  NavController,
  ToastController,
} from '@ionic/angular';
import { LONGITUD_MINIMA_CLAVE } from '../../domain/iniciar-sesion';
import { LoginViewModel } from './login.view-model';

/** Pantalla /login. Sin lógica de negocio: delega en LoginViewModel. */
@Component({
  selector: 'app-login',
  templateUrl: './login.page.html',
  styleUrl: './login.page.scss',
  providers: [LoginViewModel],
  imports: [ReactiveFormsModule, IonHeader, IonToolbar, IonTitle, IonContent, IonList, IonItem, IonInput, IonButton, IonNote, IonSpinner, IonText],
})
export class LoginPage {
  private readonly fb = inject(NonNullableFormBuilder);
  private readonly nav = inject(NavController);
  private readonly toasts = inject(ToastController);
  protected readonly vm = inject(LoginViewModel);
  protected readonly estado = this.vm.estado;
  protected readonly longitudMinimaClave = LONGITUD_MINIMA_CLAVE;

  protected readonly form = this.fb.group({
    usuario: ['', Validators.required],
    clave: ['', [Validators.required, Validators.minLength(LONGITUD_MINIMA_CLAVE)]],
  });

  async ingresar(): Promise<void> {
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }
    const { usuario, clave } = this.form.getRawValue();
    if (!(await this.vm.ingresar(usuario, clave))) return;
    this.form.reset();
    await this.nav.navigateRoot('/visitas');
    const toast = await this.toasts.create({ message: `Hola, ${this.estado().nombre}.`, duration: 2000, position: 'bottom' });
    await toast.present();
  }
}
