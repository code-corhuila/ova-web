import { HttpClient, provideHttpClient, withInterceptors } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { firstValueFrom } from 'rxjs';
import { CacheLocalFalsa, TokenStoreFalso } from '../../../testing/almacenamiento.falso';
import { vaciarTareas } from '../../../testing/visitas.ejemplo';
import { ErrorSesionExpirada, ErrorSinConexion } from '../errores/errores-dominio';
import { SesionService } from '../sesion/sesion.service';
import { CACHE_LOCAL, TOKEN_STORE } from '../storage/storage.tokens';
import { API_URL } from './api-url';
import { authInterceptor } from './auth.interceptor';
import { ENCABEZADO_CORRELACION, correlationIdInterceptor } from './correlation-id.interceptor';
import { erroresInterceptor } from './errores.interceptor';
import { timeoutInterceptor } from './timeout.interceptor';

/**
 * La cadena de interceptores REAL (mismo orden que core.providers.ts) contra un backend de prueba.
 * Doble propio para el almacenamiento; nada de spies del runner.
 */
describe('cadena de interceptores', () => {
  let http: HttpClient;
  let backend: HttpTestingController;
  let tokens: TokenStoreFalso;
  let sesion: SesionService;
  let expiraciones: number;

  beforeEach(async () => {
    tokens = new TokenStoreFalso();
    tokens.tokens = { accessToken: 'viejo', refreshToken: 'r1' };
    TestBed.configureTestingModule({
      providers: [
        provideHttpClient(withInterceptors([correlationIdInterceptor, erroresInterceptor, authInterceptor, timeoutInterceptor])),
        provideHttpClientTesting(),
        { provide: API_URL, useValue: 'http://api' },
        { provide: TOKEN_STORE, useValue: tokens },
        { provide: CACHE_LOCAL, useValue: new CacheLocalFalsa() },
      ],
    });
    sesion = TestBed.inject(SesionService);
    await sesion.restaurar();
    expiraciones = 0;
    sesion.expirada$.subscribe(() => expiraciones++);
    http = TestBed.inject(HttpClient);
    backend = TestBed.inject(HttpTestingController);
  });
  afterEach(() => backend.verify());

  async function resultado(p: Promise<unknown>): Promise<unknown> {
    try {
      return await p;
    } catch (e) {
      return e;
    }
  }

  it('token_conSesion_agregaBearerYCorrelationId', async () => {
    const p = firstValueFrom(http.get('http://api/visitas'));
    const req = backend.expectOne('http://api/visitas');

    expect(req.request.headers.get('Authorization')).toBe('Bearer viejo');
    expect((req.request.headers.get(ENCABEZADO_CORRELACION) ?? '').length > 0).toBe(true);
    req.flush([]);
    await p;
  });

  it('correlationId_dosPeticiones_usanIdsDistintos', async () => {
    const p1 = firstValueFrom(http.get('http://api/a'));
    const p2 = firstValueFrom(http.get('http://api/b'));
    const a = backend.expectOne('http://api/a');
    const b = backend.expectOne('http://api/b');

    expect(a.request.headers.get(ENCABEZADO_CORRELACION)).not.toBe(b.request.headers.get(ENCABEZADO_CORRELACION));
    a.flush({});
    b.flush({});
    await Promise.all([p1, p2]);
  });

  it('refresh_tras401_renuevaUnaVezYReintentaConElTokenNuevo', async () => {
    const p = firstValueFrom(http.get<string[]>('http://api/visitas'));
    backend.expectOne('http://api/visitas').flush({}, { status: 401, statusText: 'Unauthorized' });
    await vaciarTareas();

    const refresh = backend.expectOne('http://api/auth/refresh');
    expect(refresh.request.body).toEqual({ refreshToken: 'r1' });
    expect(refresh.request.headers.has('Authorization')).toBe(false);
    refresh.flush({ accessToken: 'nuevo' });
    await vaciarTareas();

    const reintento = backend.expectOne('http://api/visitas');
    expect(reintento.request.headers.get('Authorization')).toBe('Bearer nuevo');
    reintento.flush(['ok']);

    expect(await p).toEqual(['ok']);
    expect(tokens.tokens?.accessToken).toBe('nuevo');
  });

  it('refresh_dosPeticionesCon401ALaVez_hacenUnSoloRefresh', async () => {
    const p1 = firstValueFrom(http.get('http://api/a'));
    const p2 = firstValueFrom(http.get('http://api/b'));
    backend.expectOne('http://api/a').flush({}, { status: 401, statusText: 'Unauthorized' });
    backend.expectOne('http://api/b').flush({}, { status: 401, statusText: 'Unauthorized' });
    await vaciarTareas();

    backend.expectOne('http://api/auth/refresh').flush({ accessToken: 'nuevo' }); // falla si hubo dos
    await vaciarTareas();

    backend.expectOne('http://api/a').flush('A');
    backend.expectOne('http://api/b').flush('B');
    expect(await Promise.all([p1, p2])).toEqual(['A', 'B']);
  });

  it('refresh_reintentoTambienCon401_noVuelveARefrescarYTerminaEnErrorSesionExpirada', async () => {
    const p = resultado(firstValueFrom(http.get('http://api/visitas')));
    backend.expectOne('http://api/visitas').flush({}, { status: 401, statusText: 'Unauthorized' });
    await vaciarTareas();
    backend.expectOne('http://api/auth/refresh').flush({ accessToken: 'nuevo' });
    await vaciarTareas();
    backend.expectOne('http://api/visitas').flush({}, { status: 401, statusText: 'Unauthorized' });

    expect((await p) instanceof ErrorSesionExpirada).toBe(true);
    backend.expectNone('http://api/auth/refresh');
  });

  it('refresh_rechazado_cierraLaSesionBorraTokensYAvisa', async () => {
    const p = resultado(firstValueFrom(http.get('http://api/visitas')));
    backend.expectOne('http://api/visitas').flush({}, { status: 401, statusText: 'Unauthorized' });
    await vaciarTareas();
    backend.expectOne('http://api/auth/refresh').flush({ error: 'vencido' }, { status: 401, statusText: 'Unauthorized' });

    expect((await p) instanceof ErrorSesionExpirada).toBe(true);
    expect(tokens.borrados).toBe(1);
    expect(sesion.autenticado()).toBe(false);
    expect(expiraciones).toBe(1);
  });

  it('refresh_sinRed_noCierraLaSesionYPropagaErrorSinConexion', async () => {
    const p = resultado(firstValueFrom(http.get('http://api/visitas')));
    backend.expectOne('http://api/visitas').flush({}, { status: 401, statusText: 'Unauthorized' });
    await vaciarTareas();
    backend.expectOne('http://api/auth/refresh').error(new ProgressEvent('error'));

    expect((await p) instanceof ErrorSinConexion).toBe(true);
    expect(sesion.autenticado()).toBe(true);
    expect(expiraciones).toBe(0);
  });

  it('login_conClaveMala_noIntentaRefresh', async () => {
    const p = resultado(firstValueFrom(http.post('http://api/auth/login', { usuario: 'x', clave: 'y' })));
    const req = backend.expectOne('http://api/auth/login');
    expect(req.request.headers.has('Authorization')).toBe(false);
    req.flush({}, { status: 401, statusText: 'Unauthorized' });

    expect((await p) instanceof ErrorSesionExpirada).toBe(true);
    backend.expectNone('http://api/auth/refresh');
  });
});
