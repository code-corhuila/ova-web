import { ErrorDatosInvalidos } from '../../../core/errores/errores-dominio';
import { unDto, unaVisita } from '../../../../testing/visitas.ejemplo';
import { aVisita, aVisitaEntradaDto, aVisitas } from './visita.mapper';

describe('visita.mapper', () => {
  it('aVisita_dtoCompleto_convierteFechasYAgrupaCoordenadas', () => {
    const v = aVisita(unDto({ lat: 2.93, lng: -75.28, actualizada: '2026-10-06T08:30:00.000Z' }));

    expect(v.creadaEn).toEqual(new Date('2026-10-05T14:00:00.000Z'));
    expect(v.actualizadaEn).toEqual(new Date('2026-10-06T08:30:00.000Z'));
    expect(v.ubicacion).toEqual({ lat: 2.93, lng: -75.28 });
  });

  it('aVisita_sinCoordenadasNiActualizada_dejaUbicacionNulaYUsaLaFechaDeCreacion', () => {
    const v = aVisita(unDto({ lat: null, lng: null, actualizada: undefined }));

    expect(v.ubicacion).toBeNull();
    expect(v.actualizadaEn).toEqual(v.creadaEn);
  });

  it('aVisita_estadoDesconocido_lanzaErrorDatosInvalidos', () => {
    let error: unknown = null;
    try {
      aVisita(unDto({ estado: 'archivada' }));
    } catch (e) {
      error = e;
    }
    expect(error instanceof ErrorDatosInvalidos).toBe(true);
  });

  it('aVisitas_payloadQueNoEsLista_lanzaErrorDatosInvalidos', () => {
    let error: unknown = null;
    try {
      aVisitas({ visitas: [] });
    } catch (e) {
      error = e;
    }
    expect(error instanceof ErrorDatosInvalidos).toBe(true);
  });

  it('aVisitaEntradaDto_conUbicacion_laDescomponeEnLatYLng', () => {
    const dto = aVisitaEntradaDto(unaVisita({ ubicacion: { lat: 1.5, lng: -76 }, foto: 'data:image/png;base64,B' }));

    expect(dto).toEqual({
      cliente: 'Cooperativa Cafetera del Sur',
      direccion: 'Vereda El Tablón, Pitalito',
      estado: 'pendiente',
      observaciones: '',
      foto: 'data:image/png;base64,B',
      lat: 1.5,
      lng: -76,
    });
  });
});
