export interface Coordenadas {
  readonly lat: number;
  readonly lng: number;
}

/** Puerto: posición actual del dispositivo. TypeScript puro. */
export interface Ubicacion {
  /**
   * @throws PermisoDenegadoError si la persona niega el permiso.
   * @throws Error si el GPS está apagado o no responde a tiempo.
   */
  obtenerActual(): Promise<Coordenadas>;
}
