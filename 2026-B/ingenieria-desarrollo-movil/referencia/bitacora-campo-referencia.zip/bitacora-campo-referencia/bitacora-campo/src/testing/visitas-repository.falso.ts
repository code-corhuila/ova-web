import { DatosVisita, ListaVisitas, Visita } from '../app/features/visitas/domain/visita';
import { VisitasRepository } from '../app/features/visitas/domain/visitas.repository';
import { unaVisita } from './visitas.ejemplo';

/**
 * Doble de prueba del puerto VisitasRepository: respuestas configurables y registro de llamadas.
 * Escrito a mano (sin jasmine.createSpyObj ni vi.fn) para que las pruebas corran en Karma o Vitest.
 */
export class VisitasRepositoryFalso implements VisitasRepository {
  lista: ListaVisitas = { visitas: [], desactualizado: false, sincronizadoEn: new Date('2026-10-05T15:00:00.000Z') };
  errorAlListar: unknown = null;
  errorAlEscribir: unknown = null;
  visitaPorId: Visita | null = unaVisita();
  /** Si se asigna, listar() espera esta promesa antes de responder (para probar el orden de cargas). */
  pausa: Promise<void> | null = null;

  readonly creadas: DatosVisita[] = [];
  readonly actualizadas: { id: string; datos: DatosVisita }[] = [];
  readonly eliminadas: string[] = [];
  llamadasListar = 0;

  async listar(): Promise<ListaVisitas> {
    this.llamadasListar++;
    if (this.pausa) await this.pausa;
    if (this.errorAlListar) throw this.errorAlListar;
    return this.lista;
  }

  async obtener(id: string): Promise<Visita> {
    if (this.errorAlListar) throw this.errorAlListar;
    if (!this.visitaPorId) throw new Error(`no existe ${id}`);
    return { ...this.visitaPorId, id };
  }

  async crear(datos: DatosVisita): Promise<Visita> {
    if (this.errorAlEscribir) throw this.errorAlEscribir;
    this.creadas.push(datos);
    return unaVisita({ ...datos, id: 'nueva' });
  }

  async actualizar(id: string, datos: DatosVisita): Promise<Visita> {
    if (this.errorAlEscribir) throw this.errorAlEscribir;
    this.actualizadas.push({ id, datos });
    return unaVisita({ ...datos, id });
  }

  async eliminar(id: string): Promise<void> {
    if (this.errorAlEscribir) throw this.errorAlEscribir;
    this.eliminadas.push(id);
  }
}
