import { CacheLocal, EntradaCache } from '../app/core/storage/cache-local.port';
import { TokenStore, TokensSesion } from '../app/core/storage/token-store.port';

/** Doble del puerto TokenStore: memoria + contador de borrados. */
export class TokenStoreFalso implements TokenStore {
  tokens: TokensSesion | null = null;
  borrados = 0;
  async leer() {
    return this.tokens;
  }
  async guardar(t: TokensSesion) {
    this.tokens = t;
  }
  async borrar() {
    this.tokens = null;
    this.borrados++;
  }
}

/** Doble del puerto CacheLocal con reloj fijo. */
export class CacheLocalFalsa implements CacheLocal {
  readonly datos = new Map<string, EntradaCache<unknown>>();
  limpiezas = 0;
  constructor(private readonly ahora = '2026-10-05T12:00:00.000Z') {}
  async leer<T>(clave: string) {
    return (this.datos.get(clave) as EntradaCache<T> | undefined) ?? null;
  }
  async guardar<T>(clave: string, valor: T) {
    this.datos.set(clave, { valor, guardadoEn: this.ahora });
  }
  async limpiar() {
    this.datos.clear();
    this.limpiezas++;
  }
}
