import { Camara } from '../app/core/nativo/camara.port';
import { Coordenadas, Ubicacion } from '../app/core/nativo/ubicacion.port';

/** Cámara falsa: devuelve la foto configurada o lanza el error configurado. */
export class CamaraFalsa implements Camara {
  constructor(private readonly resultado: string | Error) {}
  async tomarFoto(): Promise<string> {
    if (this.resultado instanceof Error) throw this.resultado;
    return this.resultado;
  }
}

export class UbicacionFalsa implements Ubicacion {
  constructor(private readonly resultado: Coordenadas | Error) {}
  async obtenerActual(): Promise<Coordenadas> {
    if (this.resultado instanceof Error) throw this.resultado;
    return this.resultado;
  }
}
