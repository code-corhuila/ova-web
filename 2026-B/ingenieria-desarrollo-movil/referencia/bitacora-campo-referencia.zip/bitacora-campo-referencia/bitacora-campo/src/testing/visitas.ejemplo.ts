import { Visita } from '../app/features/visitas/domain/visita';
import { VisitaDto } from '../app/features/visitas/data/visita.dto';

/** Fábrica de visitas de prueba: valores fijos + lo que cada prueba quiera cambiar. */
export function unaVisita(cambios: Partial<Visita> = {}): Visita {
  return {
    id: 'v1',
    cliente: 'Cooperativa Cafetera del Sur',
    direccion: 'Vereda El Tablón, Pitalito',
    estado: 'pendiente',
    observaciones: '',
    foto: null,
    ubicacion: null,
    creadaEn: new Date('2026-10-05T14:00:00.000Z'),
    actualizadaEn: new Date('2026-10-05T14:00:00.000Z'),
    ...cambios,
  };
}

export function unDto(cambios: Partial<VisitaDto> = {}): VisitaDto {
  return {
    id: 'v1',
    cliente: 'Cooperativa Cafetera del Sur',
    direccion: 'Vereda El Tablón, Pitalito',
    estado: 'pendiente',
    observaciones: '',
    foto: null,
    lat: null,
    lng: null,
    creada: '2026-10-05T14:00:00.000Z',
    actualizada: '2026-10-05T14:00:00.000Z',
    ...cambios,
  };
}

/** Espera a que se resuelvan las promesas pendientes (sin relojes reales ni sleeps largos). */
export const vaciarTareas = () => new Promise<void>((r) => setTimeout(r, 0));
