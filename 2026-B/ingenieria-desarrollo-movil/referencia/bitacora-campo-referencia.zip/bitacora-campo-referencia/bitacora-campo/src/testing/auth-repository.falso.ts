import { AuthRepository } from '../app/features/auth/domain/auth.repository';
import { Sesion } from '../app/features/auth/domain/sesion';

export class AuthRepositoryFalso implements AuthRepository {
  error: unknown = null;
  readonly intentos: { usuario: string; clave: string }[] = [];
  cierres = 0;
  async iniciarSesion(usuario: string, clave: string): Promise<Sesion> {
    this.intentos.push({ usuario, clave });
    if (this.error) throw this.error;
    return { nombre: 'Técnica de campo' };
  }
  async cerrarSesion(): Promise<void> {
    this.cierres++;
  }
}
