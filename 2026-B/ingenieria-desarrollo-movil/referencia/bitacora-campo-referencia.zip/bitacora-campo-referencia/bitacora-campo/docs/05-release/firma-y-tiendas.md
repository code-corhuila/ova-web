# Firma y distribución — Bitácora de Campo

## Identidad de firma (Android)

| Elemento | Valor |
|---|---|
| Keystore | `android/app/bitacora-release.jks` (PKCS12, RSA 4096, validez 10 000 días) |
| Alias | `bitacora` |
| Sujeto del certificado | `CN=Bitacora de Campo, OU=Posgrado Ingenieria para el Desarrollo Movil, O=CORHUILA, L=Neiva, ST=Huila, C=CO` |
| Credenciales | `android/keystore.properties` (ruta, contraseñas y alias) |
| Quién lo crea | `py -3.11 scripts/crear_keystore.py` |
| Versionado | **Nunca**: `*.jks`, `*.keystore` y `keystore.properties` están en `android/.gitignore` |

Reglas:

- La contraseña la genera `secrets.token_urlsafe(24)`, se le pasa a `keytool` por variable de
  entorno (`-storepass:env`) y solo queda escrita en `keystore.properties`. Nunca se imprime.
- El script **se niega** a regenerar un keystore existente: perder o cambiar la llave impide
  publicar actualizaciones de la misma app.
- Respaldo: el `.jks` y la contraseña van a un gestor de secretos del equipo. En CI, el `.jks` se
  guarda en base64 como secreto del repositorio y `keystore.properties` se escribe en el job.
- Con Google Play App Signing, esta llave es la **llave de subida**; Google custodia la de la app.

`android/app/build.gradle` lee el archivo solo si existe (sin él, el release sale sin firmar y la
verificación lo detecta):

```groovy
def keystoreProps = new Properties()
def keystorePropsFile = rootProject.file('keystore.properties')
if (keystorePropsFile.exists()) { keystorePropsFile.withInputStream { keystoreProps.load(it) } }

android {
    signingConfigs {
        release {
            if (keystorePropsFile.exists()) {
                storeFile file(keystoreProps['storeFile'])
                storePassword keystoreProps['storePassword']
                keyAlias keystoreProps['keyAlias']
                keyPassword keystoreProps['keyPassword']
            }
        }
    }
    buildTypes { release { if (keystorePropsFile.exists()) { signingConfig signingConfigs.release } } }
}
```

## Procedimiento de release (Git Bash, desde `bitacora-campo/`)

```bash
npm ci
npm run lint && npm run test:ci
npm run build                                   # configuración production → apiUrl HTTPS
BITACORA_RELEASE=1 npx cap sync android         # allowMixedContent: false
export ANDROID_HOME="$LOCALAPPDATA/Android/Sdk"
cd android && ./gradlew bundleRelease assembleRelease
```

PowerShell: `$env:BITACORA_RELEASE = '1'; npx cap sync android`.

Salidas:

- `android/app/build/outputs/bundle/release/app-release.aab` → Google Play
- `android/app/build/outputs/apk/release/app-release.apk` → instalación directa / pruebas internas

### Verificación de la firma

`jarsigner` y `keytool` vienen con el JDK; si no están en el PATH (en Windows es común que solo
esté `java`), se lanzan como módulos de Java:

```bash
# AAB (firmado con esquema JAR)
java -m jdk.jartool/sun.security.tools.jarsigner.Main -verify android/app/build/outputs/bundle/release/app-release.aab
# APK (esquemas v2/v3) y certificado
java -jar "$ANDROID_HOME/build-tools/36.1.0/lib/apksigner.jar" verify --print-certs android/app/build/outputs/apk/release/app-release.apk
```

Esperado: `jar verified.` y `Signer #1 certificate DN: CN=Bitacora de Campo, OU=Posgrado …`.

## Versionado

- `versionName "1.0.0"` y `versionCode 1` en `android/app/build.gradle`; `"version": "1.0.0"` en `package.json`.
- Cada subida a la tienda incrementa `versionCode` (monótono, nunca se reutiliza).
- Etiqueta `v1.0.0` sobre `main`.

## Distribución en tienda

- Pista **pruebas internas** de Google Play para el curso; producción solo con backend HTTPS real.
- Lanzamiento escalonado: 5 % → 20 % → 50 % → 100 %, con **alto** ante caída de sesiones sin
  fallos por debajo de 99.5 % o un error que impida cerrar visitas.
- Metadatos versionados con el release: capturas (lista, formulario con evidencia, modo offline),
  ficha de seguridad de datos (ubicación y fotos se envían al servidor del cliente, no a terceros).

## Actualización forzada y reversión

- v1.0.0 no tiene bandera remota de versión mínima; se propone para v1.1 (consultar
  `GET /config` al arrancar y bloquear si `versionCode < minimo`).
- Reversión: la versión anterior queda disponible en la consola; detener el lanzamiento
  escalonado y publicar la anterior con `versionCode` mayor. Decide: el líder técnico.
