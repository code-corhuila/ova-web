# Checklist de release — v1.0.0 (build 1)

- **Versión:** v1.0.0 (`versionCode 1`)
- **Fecha:** 2026-10-05
- **Responsable del release:** Jesús Ariel González Bonilla (app de referencia)
- **Distribución prevista:** pista de **pruebas internas** (material del curso). No se publica en producción.

---

## Go / No-Go

### Código y pruebas
- [x] Historias HU-AUTH-01/02 y HU-VIS-01…05 cumplen la [Definición de hecho](../00-gobierno/definicion-de-hecho.md).
- [x] `npm run test:ci`: 18 archivos, **81 pruebas, 0 fallas**. API simulada: `npm test`, **10/10**.
- [x] `npm run lint`: sin errores (incluye la regla de capas).
- [x] Sin defectos críticos abiertos.
- [ ] Pruebas manuales TC-01…TC-06 en emulador ([estrategia de pruebas](../04-calidad/estrategia-de-pruebas.md#pruebas-manuales-en-dispositivo)) — **pendiente de ejecutar y anotar**.

### Compuertas de calidad
- [x] Bundle inicial 1.21 MB < presupuesto de 2 MB ([presupuestos](../04-calidad/presupuestos-de-rendimiento.md)).
- [x] Tamaño registrado: AAB ≈ 6.7 MB, APK ≈ 7.6 MB (primer release: línea base).
- [ ] Arranque en frío ≤ 2 s — **pendiente de medir** (`adb shell am start -W …`).
- [x] [Checklist de seguridad móvil](../04-calidad/seguridad-movil.md) revisado (ver brechas abajo).

### Build y firma
- [ ] Construido desde CI sobre `main` en la etiqueta `v1.0.0` — **no**: build local (el curso no tiene pipeline); procedimiento reproducible en [firma-y-tiendas.md](./firma-y-tiendas.md).
- [x] Firmado con la identidad de release: `jarsigner -verify` → `jar verified.`; `apksigner verify --print-certs` → `CN=Bitacora de Campo, OU=Posgrado Ingenieria para el Desarrollo Movil, O=CORHUILA, L=Neiva, ST=Huila, C=CO`.
- [x] Versión y build: `versionName 1.0.0`, `versionCode 1`, `package.json` 1.0.0.
- [x] Release sin cleartext (`usesCleartextTraffic="false"`, `allowMixedContent: false`) y `allowBackup="false"` (verificado en el manifest fusionado de release).

### Tienda
- [ ] Metadatos (capturas, novedades, ficha de seguridad de datos) — pendiente; textos propuestos en [firma-y-tiendas.md](./firma-y-tiendas.md).
- [x] Lanzamiento escalonado definido: 5 % → 20 % → 50 % → 100 %.
- [x] Versión mínima soportada: no aplica en v1.0.0 (primer release).

### Observabilidad
- [ ] Reporte de fallos integrado (Crashlytics/Sentry) — **no**: fuera del alcance del módulo.
- [x] Sin banderas de funcionalidad nuevas.
- [x] Disparador de reversión y responsable: el líder técnico, ante un error que impida cerrar visitas.

---

## Brechas conocidas (aceptadas para pruebas internas, bloqueantes para producción)

| Brecha | Riesgo | Plan |
|---|---|---|
| R8 desactivado (`minifyEnabled false`) | Código nativo sin ofuscar ni reducir | v1.1: activar `minifyEnabled true` + `shrinkResources true` y probar cámara, GPS y secure storage en dispositivo (Capacitor trae reglas ProGuard propias) |
| `apiUrl` de producción es un dominio `.example` | El release no tiene backend real | Configurar el backend HTTPS antes de cualquier pista abierta |
| Sin *certificate pinning* | Ataque de intermediario con CA comprometida | Obligatorio con backend real (`/auth/*`) |
| Caché de visitas sin cifrar | Datos de clientes legibles con el equipo comprometido | Aceptado con bloqueo de pantalla; revisar con ADR si se manejan datos sensibles |
| `@angular/router` 22.1.7 con aviso GHSA-ff3f-86qr-9cv3 (`npm audit`) | Afecta solo a **SSR**; esta app no usa SSR | Subir Angular a 22.2.x en el próximo sprint (regla: parchear en un sprint) |
| `ACCESS_NETWORK_STATE` en el manifest fusionado | Permiso normal (no peligroso) que agrega una dependencia transitiva de los plugins | Aceptado; no se declara en el manifest propio |

---

## Decisión

- **Go / No-Go:** **Go para pruebas internas del curso** · **No-Go para producción** hasta cerrar R8, backend HTTPS y pinning.
- **Aprobado por:** Jesús Ariel González Bonilla.
- **Notas para el próximo release:** ejecutar TC-01…TC-06 y medir el arranque en frío antes de firmar; subir `versionCode` a 2.
