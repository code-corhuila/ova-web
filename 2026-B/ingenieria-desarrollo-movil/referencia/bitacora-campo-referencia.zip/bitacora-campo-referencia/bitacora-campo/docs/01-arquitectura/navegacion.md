# Navegación — Bitácora de Campo

## Modelo

- **Una sola tabla de rutas**: `src/app/app.routes.ts`. Esta página la refleja; si cambia una,
  cambia la otra en el mismo PR.
- Navegación **por ruta** (`routerLink`, `NavController.navigateRoot/Back`); ninguna pantalla
  instancia a otra.
- Las rutas pasan **identificadores**, nunca objetos: `/visitas/:id` recibe el id como `input()`
  (`withComponentInputBinding`) y el formulario vuelve a pedir la visita con `ObtenerVisita`.
- La protección se declara **en la tabla** (`canActivate`), no dentro de las pantallas
  ([ADR-003](./decisiones/ADR-003-navegacion-y-guard.md)).
- Cada pantalla se carga perezosamente (`loadComponent`); `PreloadAllModules` la precarga después
  del arranque.
- Atrás respeta la plataforma: `ion-back-button` con `defaultHref="/visitas"` y el botón físico de
  Android (Ionic `IonicRouteStrategy` mantiene la pila).

## Registro de rutas (copia fiel de `app.routes.ts`)

| Ruta | Pantalla (componente) | Argumentos | Guard | Providers de la ruta |
|---|---|---|---|---|
| `''` | → redirige a `/visitas` | — | — | — |
| `/login` | `LoginPage` | — | `invitadoGuard` (con sesión → `/visitas`) | — |
| `/visitas` | `VisitasListaPage` | — | `authGuard` (sin sesión → `/login`) | `provideVisitas()` |
| `/visitas/nueva` | `VisitaFormPage` (modo nueva) | — | `authGuard` (heredado del grupo) | `provideVisitas()` |
| `/visitas/:id` | `VisitaFormPage` (modo edición) | `id: string` | `authGuard` (heredado del grupo) | `provideVisitas()` |
| `**` | → redirige a `/visitas` | — | — | — |

```ts
// src/app/app.routes.ts (extracto)
{
  path: 'visitas',
  canActivate: [authGuard],
  providers: [provideVisitas()],   // los casos de uso de visitas solo existen bajo /visitas
  children: [
    { path: '', loadComponent: () => import('./features/visitas/presentation/lista/visitas-lista.page').then((m) => m.VisitasListaPage) },
    { path: 'nueva', loadComponent: () => import('./features/visitas/presentation/form/visita-form.page').then((m) => m.VisitaFormPage) },
    { path: ':id', loadComponent: () => import('./features/visitas/presentation/form/visita-form.page').then((m) => m.VisitaFormPage) },
  ],
},
```

`nueva` va **antes** de `:id`: si no, «nueva» se interpretaría como un id.

## Guards (`src/app/core/sesion/auth.guard.ts`)

```ts
export const authGuard: CanActivateFn = () =>
  inject(SesionService).autenticado() ? true : inject(Router).createUrlTree(['/login']);
```

- La sesión se restaura del almacenamiento seguro **antes** de la primera navegación
  (`provideAppInitializer` en `core/di/core.providers.ts`), así el guard decide con el dato real.
- Si la sesión expira a mitad de uso (el refresh token ya no sirve), `SesionService` emite
  `expirada$` y el **shell** (`app.component.ts`) navega a `/login` con un aviso. La capa de red
  no conoce rutas.

## Flujos

```
Arranque ─▶ restaurar sesión ─▶ '' ─▶ /visitas ─(sin sesión)─▶ /login ─(éxito)─▶ /visitas (raíz)
/visitas ─(+)─▶ /visitas/nueva ─(guardar)─▶ atrás a /visitas (recarga en ionViewWillEnter)
/visitas ─(tocar fila)─▶ /visitas/:id ─(guardar)─▶ atrás a /visitas
Menú ─▶ «Cerrar sesión» ─▶ CerrarSesion ─▶ /login (raíz, sin historial)
```

## Enlaces profundos

No hay *deep links* en v1.0.0. Si se agregan (p. ej. `co.edu.corhuila.bitacora://visitas/s07`),
deben resolverse con esta misma tabla, sin lógica por pantalla.
