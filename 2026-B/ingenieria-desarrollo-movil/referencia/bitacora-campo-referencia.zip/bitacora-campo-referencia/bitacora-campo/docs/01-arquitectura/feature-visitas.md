# Feature — Visitas

- **Responsable:** equipo de Bitácora de Campo (app de referencia; Jesús Ariel González Bonilla)
- **Estado:** Entregada (v1.0.0)
- **Historias:** HU-VIS-01 … HU-VIS-05 (ver [`docs/README.md`](../README.md))

## Propósito

Que la persona técnica vea las visitas de su jornada, las registre y las cierre con evidencia
(foto obligatoria, ubicación cuando se pueda), incluso consultándolas sin señal.

## Pantallas

| Pantalla | Ruta | Propósito |
|---|---|---|
| Lista de visitas | `/visitas` | Ver, actualizar (refresher), eliminar (deslizar) y abrir ayuda (sheet modal) |
| Formulario | `/visitas/nueva`, `/visitas/:id` | Registrar o editar; capturar foto + ubicación |

### Lista (`presentation/lista/`)

| Región | Componente | Notas |
|---|---|---|
| Encabezado | `ion-toolbar` + `ion-menu-button` + botón Ayuda | Ayuda abre un **sheet modal** (`ion-modal` con `breakpoints [0, 0.5, 0.9]`) |
| Cuerpo | `cdk-virtual-scroll-viewport` (`ion-content-scroll-host`) con `ion-item-sliding` | Virtual scroll: solo las filas visibles existen en el DOM; alto fijo 72 px |
| Acción principal | `ion-fab` → `/visitas/nueva` | `aria-label="Registrar nueva visita"` |

### Formulario (`presentation/form/`)

| Región | Componente | Notas |
|---|---|---|
| Campos | Formulario reactivo: cliente, dirección, estado, observaciones | Validadores: `required`, `minLength(3)`, `maxLength`, **`sinSoloEspacios`** (propio) |
| Evidencia | Botón «Tomar foto y ubicación» + `<img>` + coordenadas | Permisos *just-in-time* |
| Guardar | `ion-button type="submit"` | Deshabilitado mientras guarda o captura |

## Estado

- **Patrón:** MVVM con estado inmutable ([ADR-001](./decisiones/ADR-001-patron-de-estado.md)).
- **Objetos de estado:** `EstadoLista` (`visitas-lista.view-model.ts`), `EstadoFormulario` (`visita-form.view-model.ts`).

| Pantalla | Fase | Disparador | UI |
|---|---|---|---|
| Lista | `cargando` | Primera carga, sin datos en pantalla | Spinner |
| Lista | `cargado` | Respuesta en línea con visitas | Resumen + lista virtual |
| Lista | `vacio` | Respuesta en línea sin visitas | `app-estado-vacio` |
| Lista | `error` | Falla sin datos previos ni caché | `app-mensaje-error` + Reintentar |
| Lista | `offline` | Sin red, con caché | `app-banner-offline` (fecha de la caché) + lista |
| Formulario | `cargando` → `editando` | Abrir `/visitas/:id` | Spinner → formulario precargado |
| Formulario | `guardando` → `guardado` | Guardar | Spinner en el botón → vuelve a la lista |
| Formulario | `error` | No se pudo traer la visita | Mensaje + Reintentar |

Avisos transitorios (`aviso`): «Visita eliminada.», regla de negocio violada, fallo al refrescar con
datos en pantalla, evidencia sin ubicación.

## Datos

- **Casos de uso:** `ListarVisitas`, `ObtenerVisita`, `RegistrarVisita`, `ActualizarVisita`, `EliminarVisita`, `CapturarEvidencia`.
- **Puertos:** `VisitasRepository` (dominio), `Camara`, `Ubicacion` (`core/nativo`).
- **Implementaciones:** `VisitasHttpRepository`; `CamaraCapacitor`, `UbicacionCapacitor`.
- **Endpoints:** `GET/POST /visitas`, `GET/PUT/DELETE /visitas/:id` — [endpoint-visitas.md](../03-api-y-datos/endpoint-visitas.md).
- **Persistencia local:** caché de lectura `visitas.lista.v1` — [entidad-visita-cache.md](../03-api-y-datos/entidad-visita-cache.md).

## Reglas de negocio (dominio)

1. Cliente: 3 a 120 caracteres, sin contar espacios de los extremos.
2. Una visita **realizada** debe tener foto.
3. Una visita **realizada** no se elimina (es registro del trabajo).
4. La lista se ordena: pendientes primero, luego por fecha de creación descendente.
5. La ubicación es «mejor esfuerzo»: si falla, se guarda la visita sin coordenadas y se avisa.

## Bordes y estados

- [x] Cargando · [x] Vacío · [x] Error con reintento · [x] Offline (caché de lectura)
- [x] Permiso de cámara negado → mensaje con la ruta en Ajustes; no cambia la foto
- [x] Permiso de ubicación negado o GPS apagado → foto conservada + aviso
- [x] Sesión expirada → el shell lleva a `/login`

## Decisiones

[ADR-001](./decisiones/ADR-001-patron-de-estado.md) · [ADR-002](./decisiones/ADR-002-persistencia-local.md) ·
[ADR-003](./decisiones/ADR-003-navegacion-y-guard.md) · [ADR-004](./decisiones/ADR-004-almacenamiento-seguro-de-tokens.md) ·
[ADR-005](./decisiones/ADR-005-framework-angular.md)

## Pruebas

- **Unitarias:** los 6 casos de uso, `reglas-visita`, `visita.mapper`, `visitas-http.repository`
  (caché offline), `VisitasListaViewModel` (10 transiciones), `VisitaFormViewModel` (8), `sinSoloEspacios`.
- **Componente:** `MensajeErrorComponent` (render + evento).
- **Manual en dispositivo:** [estrategia-de-pruebas.md](../04-calidad/estrategia-de-pruebas.md#pruebas-manuales-en-dispositivo).
