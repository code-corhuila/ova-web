# ADR-001 — Patrón de estado: MVVM con estado inmutable

- **ID:** ADR-001
- **Fecha:** 2026-10-05
- **Estado:** Aceptado
- **Autores:** equipo de Bitácora de Campo (app de referencia; Jesús Ariel González Bonilla)

---

## Contexto

Cada pantalla de Bitácora de Campo tiene varios estados que se excluyen entre sí (cargando,
cargado, vacío, error, offline) y acciones asíncronas (red, cámara, GPS). Sin un patrón único,
cada pantalla inventaría el suyo: banderas sueltas (`cargando`, `error`, `hayDatos`) que pueden
quedar en combinaciones imposibles, lógica en la plantilla y pantallas que no se pueden probar
sin renderizar.

**Restricciones conocidas:**
- El estado debe probarse **sin renderizar** (pruebas unitarias rápidas, con dobles propios).
- Angular 22 es *zoneless*: la vista debe enterarse de los cambios por **signals**.
- Equipo pequeño y rotativo (parejas del curso): el patrón se aprende en una clase.
- Tres pantallas hoy; el patrón tiene que escalar a las features que agreguen los equipos.

---

## Decisión

**Decidimos:** un **ViewModel por pantalla** (MVVM) que guarda **un único objeto de estado
inmutable** en un `BehaviorSubject` privado y lo expone a la vista como **signal de solo
lectura** con `toSignal(…, { requireSync: true })`.

**Justificación:**
- Un solo objeto con un campo `fase` hace imposibles las combinaciones inválidas y la plantilla
  lo recorre con `@switch`.
- `BehaviorSubject` da el valor actual de forma síncrona (`.value`) para construir la transición
  siguiente (`{ ...previo, cambio }`) y es RxJS estándar, sin librerías extra.
- `toSignal` conecta con la detección de cambios *zoneless* sin `async` pipes ni suscripciones
  manuales.
- El ViewModel es una clase `@Injectable()` que se prueba con `TestBed.inject` y casos de uso
  construidos sobre un repositorio falso. Desempate: **cero dependencias nuevas**.

Forma obligatoria (ver `features/visitas/presentation/lista/visitas-lista.view-model.ts`):

```ts
@Injectable()                          // provisto en el componente: vive lo que vive la pantalla
export class XxxViewModel {
  private readonly estado$ = new BehaviorSubject<EstadoXxx>(ESTADO_INICIAL);   // privado
  readonly estado = toSignal(this.estado$, { requireSync: true });            // solo lectura
  async intencion(): Promise<void> { this.estado$.next({ ...this.estado$.value, fase: '…' }); }
}
```

---

## Alternativas evaluadas

| Alternativa | Pros | Contras | Razón del descarte |
|---|---|---|---|
| **MVVM + BehaviorSubject → signal (elegida)** | Simple, sin dependencias, probable sin UI, funciona *zoneless* | Algo de código repetido por pantalla | — (elegida) |
| ViewModel solo con `signal()` | Aún más corto | Mezcla dos APIs al combinar con RxJS de `HttpClient`; menos material de clase sobre RxJS | El curso trabaja RxJS en la U2; el BehaviorSubject lo hace visible |
| NgRx Store (Redux) | Muy explícito, *devtools*, escala a apps grandes | Mucha ceremonia (acciones, reducers, efectos) para 3 pantallas; dependencia grande | Sobredimensionado para el alcance |
| NgRx SignalStore | Moderno, menos ceremonia que Store | Dependencia y API nuevas que aprender en 5 semanas | Costo de aprendizaje sin beneficio claro aquí |
| Estado mutable en el componente | Rápido de escribir | No se prueba sin renderizar; estados imposibles; lógica en la vista | Rechazada: viola las capas |

---

## Consecuencias

**Positivas:**
- Todas las pantallas se leen igual: estado → `@switch (estado().fase)` → intenciones.
- 21 pruebas de ViewModel corren en milisegundos sin dispositivo.

**Negativas / costos:**
- Cada pantalla repite la estructura (estado, inicial, `emitir`).
- Hay que disciplinarse a no mutar: TypeScript `readonly` ayuda, pero no lo impide en tiempo de ejecución.

**Impacto:**
- Pantallas: `LoginPage`, `VisitasListaPage`, `VisitaFormPage` y toda pantalla futura.
- Documentos: [`capas-y-estado.md`](../capas-y-estado.md), [`feature-visitas.md`](../feature-visitas.md).

---

## Referencias

- Marco de gobierno móvil del curso, sección 01 Arquitectura: capas y estado («un solo patrón unidireccional»).
- Relacionado con: [ADR-005](./ADR-005-framework-angular.md) (signals e `inject()` vienen con Angular).
