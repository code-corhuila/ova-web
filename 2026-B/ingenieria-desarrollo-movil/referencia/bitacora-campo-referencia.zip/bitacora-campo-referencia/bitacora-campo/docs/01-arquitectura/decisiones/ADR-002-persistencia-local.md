# ADR-002 — Persistencia local: caché de lectura sobre Capacitor Preferences

- **ID:** ADR-002
- **Fecha:** 2026-10-05
- **Estado:** Aceptado
- **Autores:** equipo de Bitácora de Campo (app de referencia; Jesús Ariel González Bonilla)

---

## Contexto

Las visitas se hacen en veredas con mala señal. La persona técnica necesita **consultar** su
lista sin conexión (a quién visita, dónde, qué quedó pendiente). Escribir sin conexión
(registrar o editar y sincronizar después) exige cola de mutaciones, ids generados en el
cliente y una política de conflictos: es valioso, pero no cabe en las cinco semanas del módulo.

**Restricciones conocidas:**
- Una sola entidad que leer offline (la lista de visitas, ~30–200 registros por técnico).
- Debe probarse sin dispositivo (la caché va detrás de un puerto que se reemplaza por un doble).
- Los tokens NO van aquí (ver [ADR-004](./ADR-004-almacenamiento-seguro-de-tokens.md)).

---

## Decisión

**Decidimos:** estrategia **«caché de lectura»** (*read-through cache*): leer offline, escribir
solo en línea. La caché es un puerto `CacheLocal` (`core/storage/cache-local.port.ts`)
implementado sobre **`@capacitor/preferences`** (`PreferencesCacheLocal`), que guarda la última
respuesta de `GET /visitas` como DTO con su fecha (`guardadoEn`).

**Justificación:** cubre la necesidad real (consultar sin señal) con el mecanismo más simple que
existe en Capacitor, sin esquema ni migraciones; el puerto deja abierta la puerta a SQLite sin
tocar dominio ni pantallas. Desempate: es la única opción que se puede explicar, implementar y
probar en una sola sesión.

---

## Alternativas evaluadas

| Alternativa | Pros | Contras | Razón del descarte |
|---|---|---|---|
| **Caché de lectura en Preferences (elegida)** | Cero esquema; API de 3 métodos; funciona en web y nativo | Guarda la lista entera como un JSON; no sirve para miles de registros ni para consultas | — (elegida) |
| SQLite (`@capacitor-community/sqlite`) | Consultas, índices, transacciones, volumen grande | Esquema y migraciones versionadas; configuración nativa adicional | Sobredimensionado para una lista de lectura |
| Offline-first con cola de sincronización | La app funciona igual con o sin red | Cola, idempotencia, conflictos (last-write-wins/merge), pruebas de reconexión | No cabe en el módulo; se deja como evolución (ver offline.md) |
| Sin persistencia (solo en línea) | Lo más simple | Sin señal, la app no sirve en campo | Rechazada: contradice el caso de uso principal |

---

## Consecuencias

**Positivas:**
- Sin señal, la lista se muestra con un aviso «Sin conexión. Datos guardados el …».
- Cambiar a SQLite es reemplazar un adaptador y la factory de `CACHE_LOCAL`.

**Negativas / costos:**
- Crear, editar y eliminar fallan sin red (mensaje claro + reintento); no hay cola.
- Las fotos (data URL) viajan dentro del JSON de la caché: con muchas visitas fotografiadas la
  entrada crece. Umbral de revisión: si `visitas.lista.v1` supera ~2 MB, migrar fotos a archivos
  (`@capacitor/filesystem`) o a SQLite con un ADR nuevo.
- La caché contiene datos de clientes: se borra al cerrar sesión y `allowBackup="false"`.

**Impacto:**
- `features/visitas/data/visitas-http.repository.ts`, `core/storage/*`.
- Documentos: [`offline.md`](../../03-api-y-datos/offline.md), [`entidad-visita-cache.md`](../../03-api-y-datos/entidad-visita-cache.md).

---

## Referencias

- Marco de gobierno móvil del curso, sección 03 API y datos: offline y sincronización; persistencia.
- `node_modules/@capacitor/preferences/README.md` (solo admite strings → JSON).
