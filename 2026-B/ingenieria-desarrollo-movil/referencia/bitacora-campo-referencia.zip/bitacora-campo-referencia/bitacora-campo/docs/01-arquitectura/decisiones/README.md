# ADR — Registro de decisiones de arquitectura

Cada archivo es **una** decisión con su contexto, las alternativas evaluadas (con la razón del
descarte) y sus consecuencias. Un ADR aceptado no se borra: si la decisión cambia se marca
«Reemplazado por ADR-NNN» y se escribe uno nuevo.

Estados posibles: `Propuesto` · `Aceptado` · `Rechazado` · `Reemplazado por ADR-NNN`.

| # | Título | Estado | Fecha |
|---|--------|--------|-------|
| [ADR-001](./ADR-001-patron-de-estado.md) | Patrón de estado: MVVM con estado inmutable (BehaviorSubject → signal) | Aceptado | 2026-10-05 |
| [ADR-002](./ADR-002-persistencia-local.md) | Persistencia local: caché de lectura sobre Capacitor Preferences | Aceptado | 2026-10-05 |
| [ADR-003](./ADR-003-navegacion-y-guard.md) | Navegación: tabla de rutas central con guard funcional | Aceptado | 2026-10-05 |
| [ADR-004](./ADR-004-almacenamiento-seguro-de-tokens.md) | Tokens en almacenamiento seguro (Keychain / Keystore) | Aceptado | 2026-10-05 |
| [ADR-005](./ADR-005-framework-angular.md) | Angular como framework de la app | Aceptado | 2026-10-09 |
