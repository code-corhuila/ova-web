# Estructura del proyecto — Bitácora de Campo

Organización **por feature**, no por tipo técnico. Cada feature es dueña de sus tres capas.
El árbol es el real del repositorio (`src/app/`):

```
src/app/
├── app.component.ts|html      Shell: menú lateral + ion-router-outlet; navega a /login si la sesión expira
├── app.config.ts              Composición de la app: Ionic, router, provideCore(), provideAuth(), locale es-CO
├── app.routes.ts              TABLA DE RUTAS CENTRAL + guards (ver navegacion.md)
├── core/                      Compartido por todas las features
│   ├── di/                    RAÍZ DE COMPOSICIÓN: único lugar que une dominio con implementaciones
│   │   ├── core.providers.ts      EL cliente HTTP con sus 4 interceptores + restaurar sesión al arrancar
│   │   ├── auth.providers.ts      AUTH_REPOSITORY → AuthHttpRepository; IniciarSesion, CerrarSesion
│   │   └── visitas.providers.ts   VISITAS_REPOSITORY → VisitasHttpRepository; 6 casos de uso
│   ├── errores/               Errores de dominio (TypeScript puro)
│   ├── network/               api-url, interceptores (correlation-id, errores, auth+refresh, timeout), mapear-error-http
│   ├── sesion/                SesionService (dueño de los tokens, refresh serializado) + authGuard
│   ├── storage/               Puertos TokenStore y CacheLocal + adaptadores (secure storage, Preferences) + tokens DI
│   ├── nativo/                Puertos Camara y Ubicacion + adaptadores Capacitor + PermisoDenegadoError + tokens DI
│   └── theme/                 tokens.scss: variables CSS del sistema de diseño
├── features/
│   ├── auth/
│   │   ├── domain/            Sesion, AuthRepository (puerto), IniciarSesion, CerrarSesion, CredencialesInvalidasError
│   │   ├── data/              login.dto.ts, sesion.mapper.ts, auth-http.repository.ts
│   │   └── presentation/login/  login.page.* + login.view-model.ts
│   └── visitas/
│       ├── domain/            visita.ts (entidad), visitas.repository.ts (puerto), reglas-visita.ts,
│       │   └── casos-de-uso/  listar-, obtener-, registrar-, actualizar-, eliminar-visita, capturar-evidencia
│       ├── data/              visita.dto.ts, visita.mapper.ts, visitas-http.repository.ts (caché de lectura)
│       └── presentation/
│           ├── estado-visita.presentacion.ts   etiqueta y color de cada estado
│           ├── lista/         visitas-lista.page.* + visitas-lista.view-model.ts
│           └── form/          visita-form.page.* + visita-form.view-model.ts + validadores.ts
└── shared/                    UI reutilizable SIN negocio: estado-vacio, mensaje-error, banner-offline
src/testing/                   Dobles de prueba escritos a mano (repositorio, almacenamiento, cámara, GPS)
```

Fuera de `src/`: `android/` (proyecto nativo generado por Capacitor y versionado), `assets/`
(fuentes de ícono y splash), `scripts/` (`generar_assets.py`, `crear_keystore.py`), `docs/`.

## Reglas

| Regla | Cómo se verifica |
|---|---|
| Una feature = una carpeta en `features/`; sin imports entre features | Revisión de PR. Las features se comunican por **rutas** (el menú del shell lleva a `/visitas`; nadie importa `features/auth` desde `features/visitas`). |
| `domain/` es TypeScript puro | `npm run lint` (regla `no-restricted-imports` en `eslint.config.js`). |
| `presentation/` no usa HTTP, `data/` ni plugins | `npm run lint`. |
| `shared/` sin negocio: recibe `input()`, emite `output()` | `npm run lint` (no puede importar `core/` ni `features/`). |
| Solo `core/di/` conoce las implementaciones concretas | Las páginas inyectan **casos de uso**; los casos de uso reciben **puertos** por constructor. |
| Un archivo = un tipo principal; el nombre del archivo lo refleja | Revisión de PR. |

## Nombres

| Cosa | Convención | Ejemplo |
|---|---|---|
| Carpeta de feature | `kebab-case` | `features/visitas/` |
| Tipo | `PascalCase`, en español | `VisitasRepository`, `CapturarEvidencia` |
| Archivo | `kebab-case` + sufijo de rol | `visitas-http.repository.ts`, `visita.mapper.ts`, `visitas-lista.view-model.ts` |
| Puerto | `*.port.ts` en `core/`; `*.repository.ts` en `domain/` | `camara.port.ts`, `visitas.repository.ts` |
| Adaptador | nombre de la tecnología | `camara-capacitor.ts`, `secure-token-store.ts` |
| Prueba | junto al archivo, `*.spec.ts` | `eliminar-visita.spec.ts` |
