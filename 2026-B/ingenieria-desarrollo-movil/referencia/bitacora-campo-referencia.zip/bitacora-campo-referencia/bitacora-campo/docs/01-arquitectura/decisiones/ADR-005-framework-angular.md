# ADR-005 — Angular como framework de la app

- **ID:** ADR-005
- **Fecha:** 2026-10-09
- **Estado:** Aceptado
- **Autores:** pareja del proyecto Bitácora de Campo (app de referencia; Jesús Ariel González Bonilla)

---

## Contexto

Ionic permite construir la interfaz con Angular, React o Vue, y cambiar esa elección después
equivale a reescribir toda la capa de presentación: hay que decidir **antes** de crear el
proyecto. Bitácora de Campo tiene tres features (sesión, lista, formulario con evidencia),
formularios con reglas de negocio, foto, ubicación y modo offline. Debe probarse sin dispositivo
y mantenerse por personas que rotan (parejas del curso).

**Restricciones conocidas:**
- La pareja tiene experiencia en TypeScript.
- Cinco semanas de módulo.
- Los contratos del dominio (repositorios, cámara, GPS) deben poder sustituirse por dobles en las
  pruebas sin librerías extra.

---

## Decisión

**Decidimos:** **Angular 22 standalone** (signals, `inject()`, control flow `@if/@for/@switch`)
con **@ionic/angular 9** y **Capacitor 8**.

**Justificación:** desempata la **DI nativa**: los contratos del dominio se resuelven en una
raíz de composición (`core/di/`) y se cambian por dobles en las pruebas
(`{ provide: TOKEN_STORE, useValue: new TokenStoreFalso() }`) sin librerías extra. Router con
guards, formularios reactivos y `HttpClient` con interceptores vienen incluidos.

Matriz de decisión (puntaje 1 a 5 × peso):

| Criterio | Peso | Angular | React | Vue |
|---|---|---|---|---|
| Estructura incluida (rutas, DI, formularios, HTTP) | 3 | 5 → 15 | 2 → 6 | 4 → 12 |
| DI nativa para sustituir contratos por dobles | 3 | 5 → 15 | 2 → 6 | 3 → 9 |
| Experiencia de la pareja | 2 | 4 → 8 | 3 → 6 | 2 → 4 |
| Madurez de la integración con Ionic | 2 | 5 → 10 | 4 → 8 | 4 → 8 |
| Curva de aprendizaje y tamaño del bundle | 2 | 3 → 6 | 4 → 8 | 5 → 10 |
| **Total (máximo 60)** | | **54** | **34** | **43** |

---

## Alternativas evaluadas

| Alternativa | Pros | Contras | Razón del descarte |
|---|---|---|---|
| **Angular + @ionic/angular (elegida)** | Framework completo y opinado; DI, router con guards, Reactive Forms y `HttpClient` incluidos | Curva y ceremonia más altas | — (elegida, 54/60) |
| React + @ionic/react | Ecosistema enorme; muy usado en la industria; control fino del estado | Estado, rutas, formularios y DI se arman con librerías a elegir | Más ADR y más riesgo de inconsistencia entre features (34/60) |
| Vue + @ionic/vue | Curva amable; bundle liviano | `provide`/`inject` más limitado para sustituir contratos en pruebas; ecosistema empresarial más pequeño | Desempate perdido en DI (43/60) |

---

## Consecuencias

**Positivas:**
- Una sola forma de hacer DI, rutas, formularios y HTTP en todo el proyecto.
- Casos de uso y ViewModels probables con dobles inyectados (81 pruebas unitarias en verde).

**Negativas / costos:**
- Curva más alta (DI, RxJS, signals) para quien llegue al equipo.
- Una versión mayor de Angular cada seis meses: las actualizaciones se planean en 05 Release.
- Angular CLI 22 exige Node ≥ 24.15 (o ≥ 22.22.3): queda fijado en `package.json` → `engines`.

**Impacto:**
- Toda la capa de presentación y la raíz de composición (`core/di/`).
- Documentos: [`estructura-del-proyecto.md`](../estructura-del-proyecto.md), [`capas-y-estado.md`](../capas-y-estado.md).

**Verificación:** `package.json` fija `@angular/core` 22.x y `@ionic/angular` 9.x y no contiene
`react` ni `vue`.

---

## Referencias

- OVA de la Unidad 1, sección 7 («La matriz de decisión y el ADR»).
- Relacionado con: [ADR-001](./ADR-001-patron-de-estado.md) (signals y RxJS vienen con Angular).
