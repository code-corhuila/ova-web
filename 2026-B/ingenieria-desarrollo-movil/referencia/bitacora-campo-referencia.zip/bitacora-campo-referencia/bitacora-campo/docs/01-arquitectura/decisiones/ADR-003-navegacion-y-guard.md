# ADR-003 — Navegación: tabla de rutas central con guard funcional

- **ID:** ADR-003
- **Fecha:** 2026-10-05
- **Estado:** Aceptado
- **Autores:** equipo de Bitácora de Campo (app de referencia; Jesús Ariel González Bonilla)

---

## Contexto

La app tiene rutas públicas (`/login`) y protegidas (`/visitas/**`). Si cada pantalla revisa la
sesión por su cuenta, tarde o temprano alguna lo olvida, y el «qué pantallas existen» se dispersa
por el código. Además, la sesión se restaura de forma asíncrona desde el almacenamiento seguro:
la decisión de dejar pasar debe tomarse **después** de esa lectura.

**Restricciones conocidas:**
- Ionic necesita `ion-router-outlet` + `IonicRouteStrategy` para la pila nativa y el botón atrás.
- Las features no se importan entre sí: la única forma de ir de una a otra es una ruta.

---

## Decisión

**Decidimos:** **una sola tabla de rutas** en `src/app/app.routes.ts` con carga perezosa
(`loadComponent`), guards **funcionales** (`CanActivateFn`) declarados en la tabla
(`authGuard` en el grupo `/visitas`, `invitadoGuard` en `/login`), rutas que pasan **ids**
(`/visitas/:id` → `input()` por `withComponentInputBinding`) y providers de la feature en la ruta
(`providers: [provideVisitas()]`). La sesión se restaura con `provideAppInitializer` antes de la
primera navegación.

**Justificación:** un solo lugar para auditar qué está protegido; los guards funcionales son
funciones puras de 1 línea sobre `SesionService.autenticado()` y se prueban con
`TestBed.runInInjectionContext`. Desempate: el guard en el **grupo** protege automáticamente
cualquier pantalla nueva que se agregue bajo `/visitas`.

---

## Alternativas evaluadas

| Alternativa | Pros | Contras | Razón del descarte |
|---|---|---|---|
| **Tabla central + guard funcional en el grupo (elegida)** | Una fuente de verdad; protección por defecto | El orden de las rutas importa (`nueva` antes de `:id`) | — (elegida) |
| Revisar la sesión en `ngOnInit` de cada pantalla | Nada que configurar | Se olvida; la pantalla alcanza a pintarse; lógica duplicada | Rechazada: viola «guard centralizado» del marco |
| Rutas por feature con `loadChildren` | Cada feature dueña de sus rutas | La tabla queda partida en varios archivos | Para 4 rutas, la tabla única se lee mejor; se reconsidera con >3 features |
| Guards de clase (`CanActivate` con `@Injectable`) | Familiar en tutoriales viejos | API en desuso en Angular moderno; más código | Obsoleto |

---

## Consecuencias

**Positivas:**
- [`navegacion.md`](../navegacion.md) es copia fiel de la tabla y se revisa en el mismo PR.
- Los casos de uso de visitas solo se construyen bajo `/visitas` (providers de ruta).

**Negativas / costos:**
- Entrar en caliente a `/visitas/:id` sin la lista cargada obliga a pedir la visita por id
  (`ObtenerVisita`) — es intencional, pero cuesta una petición.
- La expiración de sesión a mitad de uso no la ve el guard (ya pasó): la maneja el shell
  escuchando `SesionService.expirada$`.

**Impacto:** `app.routes.ts`, `core/sesion/auth.guard.ts`, `app.component.ts`.

---

## Referencias

- Marco de gobierno móvil del curso, sección 01 Arquitectura: navegación.
- Relacionado con: [ADR-004](./ADR-004-almacenamiento-seguro-de-tokens.md) (de dónde sale la sesión).
