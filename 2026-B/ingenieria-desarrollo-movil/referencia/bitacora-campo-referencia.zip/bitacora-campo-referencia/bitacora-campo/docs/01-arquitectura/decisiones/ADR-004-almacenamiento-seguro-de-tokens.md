# ADR-004 — Tokens en almacenamiento seguro (Keychain / Keystore)

- **ID:** ADR-004
- **Fecha:** 2026-10-05
- **Estado:** Aceptado
- **Autores:** equipo de Bitácora de Campo (app de referencia; Jesús Ariel González Bonilla)

---

## Contexto

La API entrega un **access token** de vida corta (15 min) y un **refresh token** de vida larga
(7 días). Quien obtenga el refresh token puede actuar como la persona técnica durante una
semana. En un teléfono perdido, rooteado o con respaldos en la nube, `localStorage` y
`Preferences` son archivos legibles en texto plano.

**Restricciones conocidas:**
- Regla del marco: tokens **solo** en almacenamiento seguro de la plataforma.
- Debe funcionar en Android 7+ (minSdk 24 de Capacitor 8) y en iOS.
- Las pruebas no pueden depender del dispositivo.

---

## Decisión

**Decidimos:** guardar los tokens detrás del puerto **`TokenStore`**
(`core/storage/token-store.port.ts`), implementado por **`SecureTokenStore`** sobre
**`@aparajita/capacitor-secure-storage` 8.x**: Keychain en iOS; en Android, cifrado AES-GCM con
una llave del Android Keystore. `SesionService` es el único que lee o escribe el puerto y
mantiene el access token en memoria para el interceptor.

**Justificación:** es el plugin mantenido para Capacitor 8 con API mínima (`get/set/remove`) y
cifrado respaldado por hardware. Desempate: guarda objetos JSON, así el par de tokens es una
sola entrada atómica.

---

## Alternativas evaluadas

| Alternativa | Pros | Contras | Razón del descarte |
|---|---|---|---|
| **`@aparajita/capacitor-secure-storage` (elegida)** | Keychain/Keystore; mantenido para Capacitor 8; guarda JSON | En web usa `localStorage` sin cifrar (solo depuración) | — (elegida) |
| `@capacitor/preferences` o `localStorage` | Ya instalado; trivial | Texto plano; se copia en respaldos | Rechazada: viola la regla de seguridad |
| Solo en memoria (pedir login en cada arranque) | Nada persiste | Mala experiencia en campo (sin señal no se puede volver a entrar) | No apto para el caso de uso |
| `@capacitor-community/secure-storage` / Ionic Identity Vault | Alternativas conocidas | La primera sin soporte claro para Capacitor 8; la segunda es de pago | Mantenimiento / costo |

---

## Consecuencias

**Positivas:**
- Cambiar de plugin es cambiar un adaptador y la factory de `TOKEN_STORE`
  (`core/storage/storage.tokens.ts`); `SesionService` y las pruebas no cambian (usan `TokenStoreFalso`).
- Al cerrar sesión se borran tokens **y** caché.

**Negativas / costos:**
- En el navegador (`ionic serve`) los tokens quedan en `localStorage` sin cifrar: solo para
  desarrollo, documentado en [`seguridad-movil.md`](../../04-calidad/seguridad-movil.md).
- Si Android invalida la llave del Keystore (cambio de bloqueo de pantalla, restauración en otro
  equipo), la lectura falla: `SesionService.restaurar()` lo trata como «sin sesión» y pide login.

**Impacto:** `core/storage/*`, `core/sesion/sesion.service.ts`, `features/auth/data/auth-http.repository.ts`.

---

## Referencias

- `node_modules/@aparajita/capacitor-secure-storage/README.md` (secciones iOS, Android, Web).
- Marco de gobierno móvil del curso, sección 03 API y datos: autenticación; y 00 Gobierno: reglas de seguridad.
