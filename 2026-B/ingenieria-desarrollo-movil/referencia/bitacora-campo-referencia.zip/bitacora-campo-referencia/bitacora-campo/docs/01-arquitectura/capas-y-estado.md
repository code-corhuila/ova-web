# Capas y estado — Bitácora de Campo

## Capas

| Capa | Responsabilidad | Puede depender de | En el código |
|---|---|---|---|
| Presentation | Pintar el estado, recoger intenciones, validar el formulario | Domain (casos de uso, entidades), `shared/`, `core/errores` | `features/*/presentation/` |
| Domain | Entidades, reglas, casos de uso, puertos (interfaces) | Nada de frameworks; de `core/` solo `errores/` y `*.port.ts` | `features/*/domain/` |
| Data | Implementar los puertos: HTTP, DTO, mappers, caché | Domain, `core/network`, `core/storage` | `features/*/data/` |

```
Presentation  ─▶  Domain  ◀─  Data            core/di/ (raíz de composición) conoce a las tres
```

- El dominio **no importa** `@angular/*`, `@ionic/*`, `@capacitor/*` ni RxJS: los casos de uso
  son clases que reciben sus puertos por constructor y se prueban con `new`, sin TestBed.
- Presentation **nunca** importa `data/`: pide `ListarVisitas`, no `VisitasHttpRepository`.
- Data implementa los puertos del dominio y traduce DTO ↔ entidad; ningún DTO sube a la UI.
- `core/di/` construye los casos de uso con sus dependencias. Ejemplo real
  (`src/app/core/di/visitas.providers.ts`):

```ts
export const VISITAS_REPOSITORY = new InjectionToken<VisitasRepository>('VISITAS_REPOSITORY', {
  providedIn: 'root',
  factory: () => inject(VisitasHttpRepository),
});

export function provideVisitas(): Provider[] {
  return [
    { provide: ListarVisitas, useFactory: () => new ListarVisitas(inject(VISITAS_REPOSITORY)) },
    // ...
    { provide: CapturarEvidencia, useFactory: () => new CapturarEvidencia(inject(CAMARA), inject(UBICACION)) },
  ];
}
```

> Por qué `InjectionToken` y no la interfaz: las interfaces de TypeScript desaparecen al
> compilar y la DI de Angular necesita un valor en tiempo de ejecución. El puerto sigue siendo
> una interfaz pura en `domain/`; el token vive en `core/di/` o en `core/*/…tokens.ts`.

La regla se hace cumplir con ESLint (`eslint.config.js`, `no-restricted-imports`): un import de
`@angular/common/http` o de `../data/` dentro de `domain/` hace fallar `npm run lint`.

## Estado: un solo patrón (ADR-001)

**MVVM con estado inmutable**, igual en todas las pantallas
([ADR-001](./decisiones/ADR-001-patron-de-estado.md)):

1. Cada pantalla tiene **un ViewModel** `@Injectable()` provisto en el componente
   (`providers: [VisitasListaViewModel]`): nace y muere con la pantalla.
2. El estado es **un objeto inmutable** (`EstadoLista`, `EstadoFormulario`, `EstadoLogin`) guardado
   en un `BehaviorSubject` **privado**.
3. La vista lo lee como **signal de solo lectura**: `readonly estado = toSignal(this.estado$, { requireSync: true })`.
4. Cada transición crea un objeto nuevo (`{ ...previo, fase: 'cargado', visitas }`); nada se muta.
5. La vista llama métodos con intención (`cargar()`, `eliminar(v)`, `guardar(campos)`); no hay
   lógica de negocio en la plantilla ni en el componente.

```ts
// features/visitas/presentation/lista/visitas-lista.view-model.ts (extracto)
export type FaseLista = 'cargando' | 'cargado' | 'vacio' | 'error' | 'offline';

@Injectable()
export class VisitasListaViewModel {
  private readonly listarVisitas = inject(ListarVisitas);
  private readonly estado$ = new BehaviorSubject<EstadoLista>(ESTADO_LISTA_INICIAL);
  readonly estado = toSignal(this.estado$, { requireSync: true });

  async cargar(): Promise<void> {
    // ... emite 'cargando' y luego estadoDesde(lista): 'cargado' | 'vacio' | 'offline', o 'error'
  }
}
```

Reglas del patrón:

- **Una sola fase a la vez** (`fase`), y la plantilla la recorre con `@switch`.
- Errores **bloqueantes** en `error` (pantalla de error con «Reintentar»); avisos **transitorios**
  en `aviso` (toast), que la vista descarta con `descartarAviso()`.
- Si llegan dos cargas, gana la más reciente; tras destruirse la pantalla, las respuestas tardías
  se ignoran (`DestroyRef`).
- El formulario reactivo (`FormGroup`) es estado de la **vista** y vive en la página; las
  **reglas** viven en el dominio (`validarDatosVisita`). La UI valida lo mismo para responder
  rápido, pero quien decide es el caso de uso.

## Casos de uso

| Caso de uso | Archivo | Regla que encapsula |
|---|---|---|
| `ListarVisitas` | `domain/casos-de-uso/listar-visitas.ts` | Pendientes primero; luego las más recientes |
| `ObtenerVisita` | `obtener-visita.ts` | Se pide por id (las rutas pasan ids) |
| `RegistrarVisita` | `registrar-visita.ts` | Normaliza y valida; «realizada» exige foto |
| `ActualizarVisita` | `actualizar-visita.ts` | Mismas reglas que el registro |
| `EliminarVisita` | `eliminar-visita.ts` | Las realizadas no se eliminan |
| `CapturarEvidencia` | `capturar-evidencia.ts` | Foto obligatoria; ubicación «mejor esfuerzo» con aviso |
| `IniciarSesion` / `CerrarSesion` | `features/auth/domain/` | Usuario no vacío, clave ≥ 6 |
