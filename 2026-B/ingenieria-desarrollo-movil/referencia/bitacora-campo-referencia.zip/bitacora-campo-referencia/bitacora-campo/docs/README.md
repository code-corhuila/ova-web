# Bitácora de Campo — documentación de gobierno (ejemplo trabajado)

> Marco de gobierno móvil (6 secciones, método SDD) **diligenciado** para la app de referencia
> del módulo *Ingeniería para el Desarrollo Móvil [G1-2026B]* (CORHUILA, posgrado).
> Docente: Jesús Ariel González Bonilla. Las plantillas vacías están en
> «Plantillas del proyecto» del curso (https://code-corhuila.github.io/ova-web/2026-B/ingenieria-desarrollo-movil/abp/plantillas/); aquí se ve cómo quedan llenas.
> **Bitácora de Campo no es elegible como proyecto ABP.**

**Producto:** una técnica o un técnico de campo registra las visitas de su jornada (cliente,
dirección, estado, observaciones) con evidencia: foto obligatoria para cerrar la visita y
ubicación GPS cuando se puede. La lista se puede consultar sin señal.

| # | Sección | Documentos |
|---|---------|------------|
| 00 | [Gobierno](./00-gobierno/) | [Definición de listo](./00-gobierno/definicion-de-listo.md) · [Definición de hecho](./00-gobierno/definicion-de-hecho.md) · [Convenciones git](./00-gobierno/convenciones-git.md) · [Reglas de seguridad](./00-gobierno/reglas-de-seguridad.md) |
| 01 | [Arquitectura](./01-arquitectura/) | [Estructura](./01-arquitectura/estructura-del-proyecto.md) · [Capas y estado](./01-arquitectura/capas-y-estado.md) · [Navegación](./01-arquitectura/navegacion.md) · [Feature visitas](./01-arquitectura/feature-visitas.md) · [ADR](./01-arquitectura/decisiones/README.md) |
| 02 | [Código y UI](./02-codigo-y-ui/) | [Estándares](./02-codigo-y-ui/estandares.md) · [Sistema de diseño](./02-codigo-y-ui/sistema-de-diseno.md) |
| 03 | [API y datos](./03-api-y-datos/) | [Endpoint visitas](./03-api-y-datos/endpoint-visitas.md) · [Autenticación](./03-api-y-datos/autenticacion.md) · [Entidad caché](./03-api-y-datos/entidad-visita-cache.md) · [Offline](./03-api-y-datos/offline.md) |
| 04 | [Calidad](./04-calidad/) | [Estrategia de pruebas](./04-calidad/estrategia-de-pruebas.md) · [Presupuestos de rendimiento](./04-calidad/presupuestos-de-rendimiento.md) · [Seguridad móvil](./04-calidad/seguridad-movil.md) |
| 05 | [Release](./05-release/) | [Firma y tiendas](./05-release/firma-y-tiendas.md) · [Checklist v1.0.0](./05-release/checklist-release-v1.0.0.md) |

## Trazabilidad SDD (historia → criterio → prueba)

| Historia | Criterio verificable | Prueba automatizada |
|---|---|---|
| HU-AUTH-01 Ingresar con usuario y clave | Clave mala → «Usuario o clave incorrectos.» | `login.view-model.spec.ts` › `ingresar_credencialesInvalidas_terminaEnErrorConMensajeClaro` |
| HU-AUTH-02 No perder la sesión por un token vencido | Un 401 renueva el token una vez y reintenta | `interceptores.spec.ts` › `refresh_tras401_renuevaUnaVezYReintentaConElTokenNuevo` |
| HU-VIS-01 Ver mis visitas de la jornada | Pendientes primero, más recientes arriba | `listar-visitas.spec.ts` › `listar_conVariosEstados_...` |
| HU-VIS-02 Consultar visitas sin señal | Sin red se muestran las guardadas con aviso | `visitas-http.repository.spec.ts` › `listar_sinConexionConCache_...` y `visitas-lista.view-model.spec.ts` › `cargar_desdeCache_terminaEnOffline...` |
| HU-VIS-03 Registrar una visita | Cliente de solo espacios se rechaza | `registrar-visita.spec.ts` › `registrar_conClienteDeSoloEspacios_...` |
| HU-VIS-04 Cerrar una visita con evidencia | «Realizada» exige foto; la ubicación es mejor esfuerzo | `registrar-visita.spec.ts` › `registrar_realizadaSinFoto_...` y `capturar-evidencia.spec.ts` |
| HU-VIS-05 Eliminar una visita equivocada | Las realizadas no se eliminan | `eliminar-visita.spec.ts` › `eliminar_visitaRealizada_...` |
