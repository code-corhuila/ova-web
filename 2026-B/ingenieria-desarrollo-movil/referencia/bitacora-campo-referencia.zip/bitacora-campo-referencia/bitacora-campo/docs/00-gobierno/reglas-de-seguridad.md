# Reglas de seguridad — Bitácora de Campo

Reglas no negociables de código. La verificación previa a cada release está en
[`04-calidad/seguridad-movil.md`](../04-calidad/seguridad-movil.md).

## Secretos y credenciales

| Regla | Cómo se cumple aquí |
|---|---|
| Ningún secreto en el repositorio ni en el bundle | La app no tiene llaves de API. `keystore.properties` y `*.jks` están en `.gitignore`. |
| Tokens solo en almacenamiento seguro | `SecureTokenStore` (`src/app/core/storage/secure-token-store.ts`): Keychain en iOS, AES-GCM con llave del Android Keystore. Nunca en `Preferences` ni `localStorage` ([ADR-004](../01-arquitectura/decisiones/ADR-004-almacenamiento-seguro-de-tokens.md)). |
| La contraseña del keystore no se imprime | `scripts/crear_keystore.py` la genera con `secrets` y se la pasa a keytool por variable de entorno; solo queda en `android/keystore.properties`. |
| Nunca registrar tokens ni credenciales en logs | No hay `console.log` de peticiones; los errores que llegan a la UI son de dominio, sin encabezados. |

## Transporte

- Release: **solo HTTPS**. `android:usesCleartextTraffic="false"` en el manifest principal,
  `allowMixedContent: false` cuando se sincroniza con `BITACORA_RELEASE=1`, y `apiUrl` HTTPS en
  `environment.prod.ts`.
- Desarrollo: HTTP hacia la API simulada **solo en builds debug** (`android/app/src/debug/AndroidManifest.xml`).
- *Certificate pinning*: no aplica a la API simulada; en un backend real se exigiría para `/auth/*`.

## Datos en reposo

- La caché de lectura (`Preferences`) guarda visitas (nombres y direcciones de clientes, fotos):
  se **borra al cerrar sesión** (`SesionService.cerrar()` → `CacheLocal.limpiar()`).
- `android:allowBackup="false"`: los datos de la app no se copian a respaldos en la nube.

## Permisos

- Mínimos y *just-in-time*: ubicación (`ACCESS_COARSE_LOCATION` y `ACCESS_FINE_LOCATION`) se
  pide al pulsar «Tomar foto y ubicación», nunca al abrir la app. La cámara no declara permiso
  en Android (el plugin usa el intent del sistema).
- Si se niega un permiso, la app explica cómo activarlo y sigue funcionando (la ubicación es
  opcional; la foto solo es obligatoria para cerrar la visita).

## Endurecimiento del build

- Build de producción de Angular (`npm run build`): minificado, sin *source maps*.
- R8 (ofuscación de Android) **pendiente**: ver la brecha registrada en el
  [checklist v1.0.0](../05-release/checklist-release-v1.0.0.md).

## Vulnerabilidades

- Reportar en privado al docente (líder técnico), nunca en un issue público.
- `npm audit` antes de cada release; dependencias con vulnerabilidad conocida se actualizan en
  el mismo sprint.
