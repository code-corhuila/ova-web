# Definición de listo (DoR) — Bitácora de Campo

Una historia entra al sprint **solo si** cumple todo esto. Si falta una casilla, se queda en
refinamiento.

- [ ] Valor escrito en formato *Como / Quiero / Para*.
- [ ] Criterios de aceptación verificables en *Dado / Cuando / Entonces*, cada uno con el nombre
      de la prueba que lo va a cubrir (`unidad_condicion_resultado`).
- [ ] Boceto de la pantalla enlazado si toca la UI (un dibujo a mano fotografiado sirve).
- [ ] Contrato de la API disponible en [`03-api-y-datos/endpoint-visitas.md`](../03-api-y-datos/endpoint-visitas.md)
      o simulado en `api-simulada/` si la historia llama al backend.
- [ ] Estados **cargando / vacío / error / offline** descritos (y *permiso denegado* si usa cámara o GPS).
- [ ] Capa afectada identificada: ¿cambia `domain/` (regla de negocio), `data/` (contrato) o solo `presentation/`?
- [ ] Dependencias con otras historias identificadas.
- [ ] Estimada por el equipo (Fibonacci) y cabe en un sprint (≤ 8 puntos).

## Ejemplo: HU-VIS-04 — Cerrar una visita con evidencia (estado: lista)

> **Como** técnica de campo **quiero** marcar una visita como realizada adjuntando foto y
> ubicación **para** demostrar que el trabajo se hizo en el sitio.

| # | Dado | Cuando | Entonces | Prueba |
|---|------|--------|----------|--------|
| 1 | una visita sin foto | la marco «Realizada» y guardo | veo «Para marcar la visita como realizada, captura la foto de evidencia.» y no se envía nada | `registrar_realizadaSinFoto_lanzaErrorValidacion` |
| 2 | permiso de cámara concedido y GPS encendido | pulso «Tomar foto y ubicación» | veo la foto y las coordenadas | `capturar_conCamaraYUbicacion_devuelveFotoYCoordenadasSinAviso` |
| 3 | GPS apagado | capturo la evidencia | conservo la foto y veo el aviso de «sin coordenadas» | `capturar_conGpsFallando_conservaLaFotoYAvisa` |
| 4 | permiso de cámara negado | capturo la evidencia | veo cómo activarlo en Ajustes | `tomarEvidencia_sinPermisoDeCamara_muestraElErrorYNoCambiaLaFoto` |

- **Estados:** cargando (spinner al capturar), error (mensaje en rojo), permiso denegado (mensaje con ruta a Ajustes).
- **Capas:** `domain/` (regla «realizada exige foto» + caso de uso `CapturarEvidencia`), `core/nativo/` (adaptadores), `presentation/form/`.
- **Estimación:** 5 puntos.
