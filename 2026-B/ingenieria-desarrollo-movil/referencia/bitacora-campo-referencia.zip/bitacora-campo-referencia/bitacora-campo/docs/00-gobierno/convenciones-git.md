# Convenciones git — Bitácora de Campo

## Ramas

- Desarrollo basado en tronco: ramas cortas desde `main` que viven pocos días.
- Nombre: `<tipo>/<alcance>-<resumen>`, en minúsculas y con guiones.

| Ejemplo real | Para qué |
|---|---|
| `feat/visitas-evidencia-gps` | HU-VIS-04: captura de foto y ubicación |
| `fix/auth-refresh-concurrente` | Dos 401 simultáneos disparaban dos refresh |
| `docs/adr-004-tokens` | Registrar la decisión de almacenamiento seguro |
| `chore/android-firma` | signingConfig y script del keystore |

## Commits (Conventional Commits, en español, modo imperativo, ≤ 72 caracteres)

```
feat(visitas): exigir foto para marcar una visita como realizada
fix(network): serializar el refresh cuando llegan dos 401 a la vez
test(visitas): cubrir la caché de lectura sin conexión
docs(arquitectura): agregar ADR-002 de persistencia local
build(android): firmar el AAB de release con keystore.properties
```

Tipos: `feat`, `fix`, `refactor`, `test`, `docs`, `chore`, `perf`, `build`, `ci`.
Alcances: `auth`, `visitas`, `network`, `storage`, `nativo`, `theme`, `android`, `arquitectura`.

## Pull requests

- Un PR = una historia o un arreglo, idealmente < 400 líneas.
- La descripción enlaza la historia y lista **qué probar en el dispositivo** (por ejemplo: negar
  el permiso de cámara, apagar el Wi-Fi y abrir la lista).
- Antes de pedir revisión: `npm run lint`, `npm run test:ci` y `npm run build` en verde.
- Al menos una aprobación. Integración por **squash**.

## Versiones

- SemVer en `android/app/build.gradle` (`versionName "1.0.0"`) y `package.json`.
- `versionCode` entero creciente: se incrementa en **cada** subida a la tienda y nunca se reutiliza.
- Etiqueta `vX.Y.Z` sobre `main` por cada release (v1.0.0 es la primera).

## Lo que nunca entra al repositorio

`android/keystore.properties`, `*.jks`, `*.keystore`, `node_modules/`, `www/`, `android/app/build/`,
`api-simulada/db.json` (datos vivos). Lo controlan los `.gitignore`; revise `git status` antes de
cada commit.
