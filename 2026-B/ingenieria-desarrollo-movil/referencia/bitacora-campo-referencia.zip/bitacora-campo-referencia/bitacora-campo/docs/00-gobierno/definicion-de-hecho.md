# Definición de hecho (DoD) — Bitácora de Campo

Una historia está **hecha solo si** todo esto es cierto. Lo que no cumple, sigue abierto.

- [ ] Criterios de aceptación cumplidos y verificados en un emulador Android (y en navegador con `ionic serve`).
- [ ] Integrada a `main` por PR revisado y aprobado (squash).
- [ ] Pruebas unitarias nuevas en verde: cada caso de uso y cada ViewModel tocado tiene prueba
      (`npm run test:ci`), con dobles escritos a mano en `src/testing/`.
- [ ] `npm run lint` sin errores: incluye la **regla de capas** (domain/ sin Angular ni data/,
      presentation/ sin HTTP ni plugins, shared/ sin negocio).
- [ ] `npm run build` sin errores ni advertencias de presupuesto.
- [ ] Estados cargando, vacío, error y offline resueltos en la pantalla (ver
      [`feature-visitas.md`](../01-arquitectura/feature-visitas.md)).
- [ ] Textos de cara a la persona usuaria en español claro, con acción de recuperación
      (Reintentar, ir a Ajustes); nunca un error técnico crudo.
- [ ] Accesibilidad básica: etiquetas `aria-label` en botones de solo ícono, objetivos táctiles
      ≥ 48 dp (`--bc-alto-minimo-toque`), estado comunicado con texto y no solo con color.
- [ ] Documentación al día: feature, endpoint o entidad afectados; ADR nuevo si hubo una decisión
      de arquitectura.

## Desviaciones aceptadas en la app de referencia

| Regla del marco | Situación en v1.0.0 | Por qué |
|---|---|---|
| Correr en **ambas** plataformas | Solo Android | El curso no exige Mac/Xcode; las claves de `Info.plist` para iOS quedan documentadas en [`seguridad-movil.md`](../04-calidad/seguridad-movil.md). |
| Textos localizados (i18n) | Español fijo en plantillas y mensajes de dominio | App de un solo idioma; las fechas sí usan `LOCALE_ID = es-CO`. Ver [`estandares.md`](../02-codigo-y-ui/estandares.md). |
| Analítica / reporte de fallos | No integrados | Fuera del alcance del módulo; señalado en el [checklist de release](../05-release/checklist-release-v1.0.0.md). |
