# Estándares de código — Bitácora de Campo

## Principios aplicados

| Principio | En el código |
|---|---|
| Inmutabilidad primero | Entidades y estados con `readonly`; transiciones con `{ ...previo, cambio }`; `ordenarParaJornada` copia antes de ordenar. |
| Unidades pequeñas | Un caso de uso por archivo con un método `ejecutar`; un tipo principal por archivo. |
| Sin valores mágicos | Límites en `LIMITES_VISITA`, mensajes de reglas en constantes (`MENSAJE_REALIZADA_SIN_FOTO`), tiempos en `TIEMPO_LIMITE_MS`, estilos en `tokens.scss`. |
| Fallar rápido | Validación en el borde: el caso de uso valida antes de ir a la red; el mapper rechaza payloads que no cumplen el contrato (`ErrorDatosInvalidos`). |

## Nombres

| Tipo | Convención | Ejemplo |
|---|---|---|
| Clases, interfaces, tipos | `PascalCase`, en español del dominio | `Visita`, `VisitasRepository`, `EstadoLista` |
| Miembros y variables | `camelCase` | `sincronizadoEn`, `tomarEvidencia()` |
| Constantes | `UPPER_SNAKE_CASE` | `CLAVE_CACHE_VISITAS`, `AVISO_SIN_UBICACION` |
| Booleanos | prefijo `es`/`hay`/`esta` (equivalente a `is/has`) | `esRelease`, `hayDatosEnPantalla`, `esErrorDeConectividad()` |
| Archivos | `kebab-case` + sufijo de rol | `visita-form.view-model.ts` |
| Pruebas | `unidad_condicion_resultado` | `eliminar_visitaRealizada_lanzaErrorValidacionYNoLlamaAlRepositorio` |

Identificadores en español; palabras propias de la tecnología se conservan (`ViewModel`,
`repository`, `mapper`, `dto`, `port`, `accessToken`).

## Manejo de errores

1. **Nadie fuera de `core/network` ve un `HttpErrorResponse`.** El `erroresInterceptor`
   traduce todo a errores de dominio (`core/errores/errores-dominio.ts`):

| Técnico | Dominio | Mensaje |
|---|---|---|
| status 0 | `ErrorSinConexion` | No hay conexión con el servidor. |
| `TimeoutError` | `ErrorTiempoAgotado` | El servidor tardó demasiado en responder. |
| 401 | `ErrorSesionExpirada` | Tu sesión expiró. Ingresa de nuevo. |
| 400 / 422 | `ErrorValidacion` | El texto `error` que envía la API |
| 404 | `ErrorNoEncontrado` | El registro ya no existe. |
| 5xx | `ErrorServidor` | El servidor tuvo un problema… |
| JSON fuera de contrato | `ErrorDatosInvalidos` | El servidor respondió con datos inesperados. |

2. Una feature puede especializar: en el login, un 401 significa **credenciales inválidas**, y
   `AuthHttpRepository` lo convierte en `CredencialesInvalidasError` (dominio de auth).
3. Los ViewModels convierten cualquier error en texto con `mensajeDeError(e)` y **siempre**
   ofrecen una salida: «Reintentar» (`app-mensaje-error`), corregir el campo, o ir a Ajustes.
4. No se tragan errores en silencio. Excepciones documentadas en el código: revocar el refresh
   token sin red al cerrar sesión, y una entrada de caché corrupta (se descarta).

## Asincronía

- Todo `await` tiene su rama de error (`try/catch` en el ViewModel).
- Los ViewModels se proveen en el componente; al destruirse, ignoran respuestas tardías y la
  carga más reciente gana sobre las anteriores.
- `HttpClient` siempre con tiempo límite (`timeoutInterceptor`, 10 s por intento).

## Lint

- `npm run lint` (ESLint + angular-eslint) incluye la **regla de capas** en `eslint.config.js`.
- No se desactiva una regla en línea sin un comentario que explique por qué.

## Internacionalización (desviación aceptada)

La app es de un solo idioma (español de Colombia). Las fechas usan `LOCALE_ID = 'es-CO'`
(`app.config.ts`) y el pipe `date`. Los textos están en plantillas y en los mensajes de los
errores de dominio, no en archivos de recursos: si el producto necesitara otro idioma, se
registraría un ADR para adoptar `@angular/localize` y mover los textos a claves por feature
(`visitas.lista.vacia`, `auth.error.credenciales`).
