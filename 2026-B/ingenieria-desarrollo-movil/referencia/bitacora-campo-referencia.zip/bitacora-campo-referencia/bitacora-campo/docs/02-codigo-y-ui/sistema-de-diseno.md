# Sistema de diseño — Bitácora de Campo

## Tokens (`src/app/core/theme/tokens.scss`)

Las pantallas usan **solo** variables `--bc-*` (o los colores de Ionic que se derivan de ellas).
El tema oscuro cambia valores bajo `prefers-color-scheme: dark`, no componentes.

| Grupo | Tokens | Valores (claro) |
|---|---|---|
| Color | `--bc-color-marca` | `#009540` (verde institucional: ícono, splash) |
| Color | `--bc-color-primario`, `-oscuro`, `-claro` | `#008338` (variante accesible del verde), `#007331`, `#1a8f4c` |
| Color | `--bc-color-superficie`, `--bc-color-texto`, `--bc-color-texto-suave` | `#ffffff`, `#1f2933`, `#52606d` |
| Color | `--bc-color-aviso-fondo`, `--bc-color-aviso-texto` | `#fff4d6`, `#6b4e00` (banner offline) |
| Espaciado | `--bc-espacio-xs … xl` | 4 / 8 / 12 / 16 / 24 px |
| Radio | `--bc-radio-sm`, `--bc-radio-md`, `--bc-radio-pill` | 4 px, 8 px, 999 px |
| Tipografía | `--bc-texto-titulo`, `--bc-texto-cuerpo`, `--bc-texto-nota` | 1.25 / 1 / 0.875 rem (escalan con el tamaño de letra del sistema) |
| Componentes | `--bc-alto-item-lista`, `--bc-alto-minimo-toque` | 72 px (= `itemSize` del virtual scroll), 48 px |

`--ion-color-primary*` se mapean a `--bc-color-primario*`: cualquier `color="primary"` de Ionic
usa la variante accesible del verde institucional (ver la regla de contraste al final).

Colores de estado de visita (`presentation/estado-visita.presentacion.ts`): pendiente →
`warning`, realizada → `success`, cancelada → `medium`. El badge **siempre** muestra el texto
(«Pendiente»), así el color nunca es el único indicador.

## Componentes compartidos (`src/app/shared/`)

Solo presentación: reciben `input()`, emiten `output()`, no inyectan casos de uso ni servicios
(lo impide `npm run lint`).

| Componente | Entradas / salidas | Uso | Accesibilidad |
|---|---|---|---|
| `app-estado-vacio` | `mensaje` (requerido), `accion?`; emite `accionar` | Fase `vacio` de la lista | `role="status"`; ícono `aria-hidden` |
| `app-mensaje-error` | `mensaje` (requerido); emite `reintentar` | Fase `error` de lista y formulario | `role="alert"`; botón «Reintentar» ≥ 48 px |
| `app-banner-offline` | `sincronizadoEn: Date` (requerido) | Fase `offline` de la lista | `role="status"`; ícono + texto (no solo color) |

Ejemplo:

```html
<app-mensaje-error [mensaje]="estado().error ?? ''" (reintentar)="vm.cargar()" />
```

## Componentes de Ionic usados y por qué

| Necesidad | Componente |
|---|---|
| Lista larga sin degradar el scroll | `cdk-virtual-scroll-viewport` + `ion-content-scroll-host` (el refresher sigue funcionando) |
| Eliminar con gesto | `ion-item-sliding` + `ion-item-option` (con `aria-label`) |
| Actualizar | `ion-refresher` |
| Ayuda contextual sin salir de la pantalla | `ion-modal` tipo *sheet* (`breakpoints [0, 0.5, 0.9]`, `handle`) |
| Acción principal | `ion-fab` |
| Mensajes transitorios | `ToastController` (2–3 s) |

## Reglas

- Sin colores, tamaños ni fuentes sueltos en las pantallas: `var(--bc-…)`.
- Objetivos táctiles ≥ `--bc-alto-minimo-toque` (48 dp Android / 44 pt iOS).
- Respetar la plataforma: Ionic aplica el modo `md` en Android e `ios` en iOS; no se fuerza uno.
- Contraste (decisión trabajada): blanco sobre el verde institucional `#009540` da ≈ 3.9:1, que
  cumple WCAG AA solo para texto grande; los botones de Ionic usan texto de 14 px. Por eso el
  primario de la UI es la variante `#008338` (≈ 4.9:1, AA para todo texto) y `#009540` queda como
  color de marca en ícono y splash. Texto de cuerpo sobre la superficie: `#1f2933` sobre blanco ≈ 15:1.
