# Offline — Bitácora de Campo

## Estrategia por feature

| Feature | Estrategia | Por qué |
|---|---|---|
| Sesión (login) | Solo en línea | Emitir tokens exige al servidor. Una sesión ya iniciada sobrevive sin red (los tokens están en el dispositivo) |
| Visitas — lectura | **Caché de lectura** | Consultar la jornada sin señal es el caso de uso principal |
| Visitas — escritura | Solo en línea | Sin cola de sincronización en v1.0.0 ([ADR-002](../01-arquitectura/decisiones/ADR-002-persistencia-local.md)) |
| Evidencia (foto + GPS) | Funciona sin red | La cámara y el GPS no necesitan internet; lo que necesita red es **guardar** |

## Cómo se aplica (código real)

`VisitasHttpRepository.listar()`:

```ts
try {
  const respuesta = await firstValueFrom(this.http.get<unknown>(`${this.api}/visitas`));
  const visitas = aVisitas(respuesta);                       // valida el contrato ANTES de guardar
  await this.cache.guardar(CLAVE_CACHE_VISITAS, respuesta as VisitaDto[]);
  return { visitas, desactualizado: false, sincronizadoEn: new Date() };
} catch (e) {
  if (!esErrorDeConectividad(e)) throw e;                    // un 500 NO se tapa con la caché
  const guardado = await this.cache.leer<VisitaDto[]>(CLAVE_CACHE_VISITAS);
  if (!guardado) throw e;                                    // sin red y sin caché → error visible
  return { visitas: aVisitas(guardado.valor), desactualizado: true, sincronizadoEn: new Date(guardado.guardadoEn) };
}
```

- Solo `ErrorSinConexion` y `ErrorTiempoAgotado` activan la caché. Un error del servidor (5xx),
  una sesión expirada o datos inválidos **no** se disfrazan de «offline».
- `obtener(id)` usa la misma lógica: sin red, busca la visita en la caché para poder abrirla.
- El dominio solo ve `ListaVisitas.desactualizado` y `sincronizadoEn`; no sabe de Preferences.

## Qué ve la persona usuaria

| Situación | Fase del ViewModel | UI |
|---|---|---|
| Sin red, con caché | `offline` | Banner amarillo «Sin conexión. Datos guardados el 9 oct, 6:05 p. m.» (ícono + texto) y la lista |
| Sin red, sin caché | `error` | «No hay conexión con el servidor.» + Reintentar |
| Con datos en pantalla, falla el refresco | se queda en `cargado` | Toast con el error; la lista no se borra |
| Guardar/eliminar sin red | formulario `editando` / aviso en lista | «No hay conexión con el servidor.»; los datos del formulario se conservan para reintentar |

## Conectividad

v1.0.0 no escucha el estado de la red como flujo (`@capacitor/network`): la caché se activa
cuando una petición falla, y la persona refresca a mano (refresher). Es una simplificación
consciente; el marco recomienda tratar la conectividad como un flujo, y la evolución natural es
volver a cargar automáticamente al recuperar la red.

## Evolución a offline-first (fuera del alcance)

1. Cola local de mutaciones con id generado en el cliente (UUID) → `POST` idempotente.
2. Política de conflictos por entidad (propuesta: *last-write-wins* por `actualizada`).
3. Sincronizar al recuperar la red, con reintentos con backoff y un botón «Reintentar ahora».
4. Estados de UI «pendiente de sincronizar» por visita.

## Checklist

- [x] Estrategia documentada por feature.
- [x] Política de conflictos: no aplica (sin escrituras offline).
- [x] Sincronización idempotente: no aplica en v1.0.0.
- [x] La UI muestra el estado offline / desactualizado (banner con fecha).
