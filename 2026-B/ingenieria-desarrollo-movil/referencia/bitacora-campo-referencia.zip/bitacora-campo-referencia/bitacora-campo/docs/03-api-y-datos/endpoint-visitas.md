# Integración de endpoint — Visitas

- **Feature:** visitas
- **Métodos y rutas:** `GET /visitas` · `GET /visitas/:id` · `POST /visitas` · `PUT /visitas/:id` · `DELETE /visitas/:id`
- **Autenticación:** sí — `Authorization: Bearer <accessToken>` (lo agrega `authInterceptor`; ningún repositorio lo toca)
- **Implementación:** `src/app/features/visitas/data/visitas-http.repository.ts`
- **Contrato del servidor:** `api-simulada/README.md`

---

## Solicitud

| Parámetro | Dónde | Tipo | Obligatorio | Notas |
|---|---|---|---|---|
| `id` | ruta | string | En `GET/PUT/DELETE /visitas/:id` | Se codifica con `encodeURIComponent` |
| `X-Correlation-Id` | encabezado | UUID | Sí (automático) | `correlationIdInterceptor`; la API lo devuelve |

**Cuerpo de `POST` y `PUT`** (`VisitaEntradaDto`, `data/visita.dto.ts`):

```json
{
  "cliente": "Lácteos del Huila",
  "direccion": "Zona industrial, Neiva",
  "estado": "realizada",
  "observaciones": "Medidor reemplazado",
  "foto": "data:image/jpeg;base64,/9j/4AAQ...",
  "lat": 2.9273,
  "lng": -75.2819
}
```

---

## Respuesta

**Éxito:** `200 Visita[]` (lista), `200 Visita` (uno / PUT), `201 Visita` (POST), `204` (DELETE).

```json
{
  "id": "s12", "cliente": "Lácteos del Huila", "direccion": "Zona industrial, Neiva",
  "estado": "realizada", "observaciones": "Medidor reemplazado",
  "foto": "data:image/jpeg;base64,/9j/4AAQ...", "lat": 2.9273, "lng": -75.2819,
  "creada": "2026-10-02T05:30:00.000Z", "actualizada": "2026-10-09T15:12:40.000Z"
}
```

**DTO → dominio** (`data/visita.mapper.ts`, función `aVisita`):

| Campo DTO | Campo dominio | Transformación |
|---|---|---|
| `estado` (string) | `estado: EstadoVisita` | Se valida contra `ESTADOS_VISITA`; desconocido → `ErrorDatosInvalidos` |
| `lat`, `lng` (number \| null) | `ubicacion: Coordenadas \| null` | Ambos presentes → `{lat, lng}`; si no → `null` |
| `creada` (ISO) | `creadaEn: Date` | `new Date(iso)`; fecha inválida → `ErrorDatosInvalidos` |
| `actualizada` (ISO, opcional) | `actualizadaEn: Date` | Si falta, igual a `creadaEn` |
| resto | igual nombre | Copia; tipos verificados por `esVisitaDto` |

**Dominio → DTO** (`aVisitaEntradaDto`): `ubicacion` se descompone en `lat`/`lng` (o `null`).

---

## Errores

| Status | Significado | Error de dominio | Comportamiento de la app |
|---|---|---|---|
| 0 / sin red | No hay conexión | `ErrorSinConexion` | Lectura: caché marcada desactualizada. Escritura: mensaje + reintento manual |
| timeout (10 s) | El servidor no respondió | `ErrorTiempoAgotado` | Igual que sin red |
| 400 | Validación del servidor | `ErrorValidacion` (texto de la API) | Mensaje en el formulario; no se reintenta |
| 401 | Token vencido / inválido | — | Refresh transparente y **un** reintento; si el refresh falla → `ErrorSesionExpirada` y login |
| 404 | La visita ya no existe | `ErrorNoEncontrado` | Formulario en fase `error`; la lista se refresca |
| 5xx | Falla del servidor | `ErrorServidor` | Mensaje + «Reintentar» |

> Reintentos automáticos: solo el del refresh de token. Nunca se reintenta en automático un
> `POST`/`PUT`/`DELETE` (no son idempotentes); `GET` tampoco se reintenta solo porque la caché
> cubre el caso offline y la persona puede tirar del refresher.

---

## Caché / offline

- **Estrategia:** caché de lectura ([ADR-002](../01-arquitectura/decisiones/ADR-002-persistencia-local.md), [offline.md](./offline.md)).
- **Entidad en caché:** `visitas.lista.v1` ([entidad-visita-cache.md](./entidad-visita-cache.md)).
- **Invalidación:** cada `GET /visitas` exitoso la reemplaza; cada escritura exitosa la ajusta; cerrar sesión la borra.
