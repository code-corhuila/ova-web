# Entidad local — Caché de visitas

- **Almacén:** clave/valor — `@capacitor/preferences` (SharedPreferences en Android, UserDefaults en iOS)
- **Clave:** `cache.visitas.lista.v1` (prefijo `cache.` del adaptador + `CLAVE_CACHE_VISITAS`)
- **Versión de esquema:** v1 (la versión va en la clave)
- **Código:** puerto `core/storage/cache-local.port.ts`, adaptador `core/storage/preferences-cache-local.ts`,
  uso en `features/visitas/data/visitas-http.repository.ts`

> Es una caché clave/valor, no una tabla: por eso el «esquema» es la forma del JSON guardado.
> Se guarda el **DTO** de la API, no la entidad de dominio (modelo persistido ≠ dominio); el
> mapper `aVisitas` lo convierte al leer, igual que una respuesta de red.

## Forma guardada

```json
{
  "valor": [ { "id": "s01", "cliente": "…", "direccion": "…", "estado": "pendiente",
               "observaciones": "", "foto": null, "lat": null, "lng": null,
               "creada": "2026-10-05T14:00:00.000Z", "actualizada": "2026-10-05T14:00:00.000Z" } ],
  "guardadoEn": "2026-10-09T23:05:12.000Z"
}
```

| Campo | Tipo | Nulo | Notas |
|---|---|---|---|
| `valor` | `VisitaDto[]` | No | Última lista válida recibida de `GET /visitas` |
| `valor[].id` | string | No | Clave primaria (la asigna el servidor) |
| `valor[].creada` / `actualizada` | ISO 8601 | No / opcional | Equivalen a `created_at` / `updated_at` |
| `valor[].foto` | data URL | Sí | Puede pesar decenas de KB por visita (ver límites) |
| `valor[].lat`, `lng` | number | Sí | Ambos o ninguno |
| `guardadoEn` | ISO 8601 | No | Lo pone el adaptador; se muestra en el banner offline |

## Índices

No aplica (clave/valor). Se lee la lista completa; el orden lo aplica `ListarVisitas`.

## Relaciones

Ninguna. Las fotos van embebidas en cada visita.

## Sincronización

- **¿Se sincroniza?** No: es solo lectura. La fuente de verdad es el servidor.
- **Política de conflictos:** no hay escrituras offline, así que no hay conflictos. Cada lectura en
  línea **reemplaza** la caché; cada escritura en línea exitosa la **ajusta** (agrega, reemplaza o
  quita esa visita).
- **Ciclo de vida:** se borra completa al cerrar sesión (`CacheLocal.limpiar()` borra todas las
  claves `cache.*`).

## Migraciones

- Cambio de forma del DTO → nueva clave `visitas.lista.v2`. La v1 se ignora y se borra en el
  siguiente cierre de sesión. No hay migración de datos: es una caché, se reconstruye con la
  próxima lectura en línea.
- Entrada corrupta (JSON inválido) → el adaptador la borra y responde «sin caché».

## Límites

- Volumen esperado: 30–200 visitas. Con fotos de ~60 KB, 200 visitas fotografiadas ≈ 12 MB:
  **por encima de ~2 MB se revisa** la decisión (fotos a archivos o SQLite) con un ADR nuevo
  ([ADR-002](../01-arquitectura/decisiones/ADR-002-persistencia-local.md)).
