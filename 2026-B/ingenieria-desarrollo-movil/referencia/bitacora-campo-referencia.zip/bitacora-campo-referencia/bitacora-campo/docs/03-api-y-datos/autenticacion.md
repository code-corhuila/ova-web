# Autenticación — Bitácora de Campo

## Tokens

| Token | Vida | Dónde vive | Para qué |
|---|---|---|---|
| `accessToken` | 15 min (`ACCESS_TTL_S`, por defecto 900) | Memoria de `SesionService` + almacenamiento seguro | `Authorization: Bearer …` en cada petición |
| `refreshToken` | 7 días (`REFRESH_TTL_S`) | Almacenamiento seguro | `POST /auth/refresh` para obtener un access token nuevo |

Almacenamiento: puerto `TokenStore` → `SecureTokenStore` (Keychain / Keystore). Nunca en
`Preferences`, `localStorage` ni en la caché ([ADR-004](../01-arquitectura/decisiones/ADR-004-almacenamiento-seguro-de-tokens.md)).

## Piezas y responsabilidades

| Pieza | Archivo | Hace |
|---|---|---|
| `IniciarSesion` | `features/auth/domain/iniciar-sesion.ts` | Valida usuario y clave; llama al puerto `AuthRepository` |
| `AuthHttpRepository` | `features/auth/data/auth-http.repository.ts` | `POST /auth/login`; mapea con `sesion.mapper.ts`; entrega los tokens a `SesionService`; 401 → `CredencialesInvalidasError` |
| `SesionService` | `core/sesion/sesion.service.ts` | **Dueño único de los tokens**: restaurar, iniciar, refrescar (serializado), cerrar |
| `authInterceptor` | `core/network/auth.interceptor.ts` | **Único** lugar que adjunta el token; 401 → refresh → un reintento |
| `authGuard` | `core/sesion/auth.guard.ts` | Bloquea `/visitas/**` sin sesión |
| Shell | `app.component.ts` | Escucha `expirada$` y lleva a `/login` |

## Flujo del refresh (un solo reintento, refresh serializado)

```
Pantalla ─▶ GET /visitas (Bearer A) ─▶ 401
             authInterceptor: ¿la petición llevaba token y no es /auth/*? sí
             └─▶ SesionService.refrescar(A)
                   ├─ si el token actual ya no es A (otra petición renovó) → usa el actual, sin llamar a la API
                   ├─ si ya hay un refresh en curso → espera ESA misma promesa (uno a la vez)
                   └─ POST /auth/refresh {refreshToken} por un HttpClient SIN interceptores
                        ├─ 200 {accessToken: B} → guarda B en TokenStore → devuelve B
                        ├─ 401/400 → borra tokens y caché, emite expirada$ → ErrorSesionExpirada
                        └─ sin red / timeout → NO cierra la sesión → ErrorSinConexion / ErrorTiempoAgotado
             └─▶ reintenta GET /visitas (Bearer B) UNA vez; si vuelve a dar 401 → ErrorSesionExpirada
```

Extracto real (`core/network/auth.interceptor.ts`):

```ts
return next(conBearer(req, tokenUsado)).pipe(
  catchError((error: unknown) => {
    if (!(error instanceof HttpErrorResponse) || error.status !== 401) return throwError(() => error);
    return from(sesion.refrescar(tokenUsado)).pipe(switchMap((nuevo) => next(conBearer(req, nuevo))));
  }),
);
```

El reintento está **después** del `catchError`: si falla, su error ya no vuelve a entrar ahí. Así
el «un solo reintento» queda garantizado por la forma del código, sin contadores.

Orden de la cadena (`core/di/core.providers.ts`):
`correlation-id → errores → auth → timeout → red`. `errores` va antes de `auth` para traducir el
error **final**; `timeout` va al final para que cada intento tenga su propio límite.

## Cierre de sesión

`CerrarSesion` → `SesionService.cerrar()`: intenta `POST /auth/logout` (revoca el refresh token;
si no hay red, sigue), borra tokens del almacenamiento seguro, limpia la caché de visitas y deja
`autenticado()` en `false`. El shell navega a `/login` como raíz (sin historial para volver).

## Pruebas que lo respaldan

`interceptores.spec.ts`: Bearer + correlation-id; refresh tras 401 y reintento con el token nuevo;
dos 401 simultáneos → **un** refresh; reintento con 401 → no vuelve a refrescar; refresh
rechazado → cierra sesión y emite; refresh sin red → no cierra sesión; login no dispara refresh.
`sesion.service.spec.ts`: restaurar, cerrar con y sin red, reutilizar token ya renovado, guard.

## Probarlo en vivo

```bash
ACCESS_TTL_S=20 npm start        # en api-simulada/: el access token vence a los 20 s
```

Ingrese, espere 20 s y tire del refresher: en la pestaña Red del navegador se ve
`GET /visitas 401` → `POST /auth/refresh 200` → `GET /visitas 200`, y la lista no se interrumpe.
