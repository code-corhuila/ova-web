# Estrategia de pruebas — Bitácora de Campo

## Pirámide (real, v1.0.0)

| Nivel | Alcance | Herramienta | Cantidad | Participación |
|---|---|---|---|---|
| Unitarias | Casos de uso, reglas, mappers, repositorio (con backend de prueba), interceptores, sesión, ViewModels, validador | Vitest 4 (runner del starter de Angular 22) | **79** | 97 % |
| Componente (UI) | Un componente compartido renderizado | Vitest + TestBed + jsdom | **2** | 3 % |
| Integración / E2E | Flujo completo en emulador | Manual (checklist abajo) | 6 casos | — |

`npm run test:ci` → **18 archivos, 81 pruebas, 0 fallas** (≈ 16 s). La API simulada tiene sus
propias **10 pruebas** con `node --test` (`api-simulada/test/api.test.mjs`).

> Desviación consciente frente al 70/20/10 del marco: casi todo es unitario porque la lógica vive
> en dominio y ViewModels (por diseño, ADR-001). Las pantallas no tienen pruebas de componente
> porque los componentes de Ionic en jsdom aportan poco; el flujo de pantallas se cubre con el
> checklist manual en emulador. Siguiente paso: E2E con Playwright contra `ionic serve`.

## Reglas

- **Portables:** dobles escritos a mano en `src/testing/` (`VisitasRepositoryFalso`,
  `TokenStoreFalso`, `CacheLocalFalsa`, `CamaraFalsa`, `UbicacionFalsa`, `AuthRepositoryFalso`).
  Nada de `jasmine.createSpyObj` ni `vi.fn`; solo `expect(...).toBe / toEqual / toBeNull /
  toContain`. Las mismas pruebas corren en Karma o en Vitest.
- Se falsea solo la dependencia **directa**: el ViewModel recibe casos de uso reales construidos
  sobre un repositorio falso; el repositorio recibe un backend HTTP de prueba
  (`HttpTestingController`) y una caché falsa.
- Deterministas: sin red real, sin relojes reales (la caché falsa tiene fecha fija; la API usa
  un reloj inyectado), sin esperas largas (`vaciarTareas()` = un `setTimeout(0)`).
- Arrange-Act-Assert, un comportamiento por prueba.
- Nombre: `unidad_condicion_resultado`.

## Inventario

| Archivo | # | Qué protege |
|---|---|---|
| `core/network/interceptores.spec.ts` | 8 | Cadena real de interceptores: Bearer + correlation-id; refresh tras 401 y **un** reintento; dos 401 → **un** refresh; reintento con 401 no refresca otra vez; refresh rechazado → cierra sesión; refresh sin red → no la cierra; login no dispara refresh |
| `core/network/mapear-error-http.spec.ts` | 8 | Tabla HTTP → error de dominio |
| `core/sesion/sesion.service.spec.ts` | 7 | Restaurar, cerrar (con y sin red), token ya renovado, `authGuard` |
| `features/auth/domain/iniciar-sesion.spec.ts` | 3 | Validación antes de ir a la red |
| `features/auth/presentation/login/login.view-model.spec.ts` | 3 | inicial → enviando → éxito / error |
| `features/visitas/domain/casos-de-uso/*.spec.ts` | 16 | Listar (orden), obtener, registrar (realizada exige foto), actualizar, eliminar (realizadas no), capturar evidencia (4 casos) |
| `features/visitas/domain/reglas-visita.spec.ts` | 2 | Resumen por estado |
| `features/visitas/data/visita.mapper.spec.ts` | 5 | DTO ↔ dominio; contrato roto → `ErrorDatosInvalidos` |
| `features/visitas/data/visitas-http.repository.spec.ts` | 6 | Caché de lectura: en línea guarda; sin red devuelve desactualizado; sin red ni caché falla; 500 no usa caché; escrituras ajustan la caché |
| `features/visitas/presentation/lista/visitas-lista.view-model.spec.ts` | 10 | cargando → cargado / vacío / offline / error; refresco fallido conserva la lista; la carga más reciente gana; eliminar |
| `features/visitas/presentation/form/visita-form.view-model.spec.ts` | 8 | Nueva / edición; regla de la foto; sin red y reintento; evidencia sin GPS; permiso de cámara negado |
| `features/visitas/presentation/form/validadores.spec.ts` | 3 | Validador propio `sinSoloEspacios` |
| `shared/mensaje-error/mensaje-error.component.spec.ts` | 2 | Render con `role="alert"` y evento `reintentar` |

Ejemplo (ViewModel con caso de uso real y repositorio falso):

```ts
it('cargar_desdeCache_terminaEnOfflineConLaFechaDeSincronizacion', async () => {
  repo.lista = { visitas: [unaVisita()], desactualizado: true, sincronizadoEn: new Date('2026-10-04T08:00:00Z') };

  await vm.cargar();

  expect(vm.estado().fase).toBe('offline');
  expect(vm.estado().sincronizadoEn).toEqual(new Date('2026-10-04T08:00:00Z'));
});
```

## Cobertura

Meta del marco: **80 %** en `domain/` y ViewModels. Todos los casos de uso y los tres ViewModels
tienen pruebas de cada transición. (El builder de pruebas admite `ng test --coverage`; no se fija
como compuerta en v1.0.0.)

## Comandos

```bash
npm run test:ci      # una corrida (CI); "ng test --watch=false"
npm test             # modo observación
npm run lint         # incluye la regla de capas
cd ../api-simulada && npm test
```

## Pruebas manuales en dispositivo

Emulador Android (API 34+) con la API simulada en el computador (`http://10.0.2.2:3000`), build debug.

| # | Caso | Pasos | Esperado |
|---|---|---|---|
| TC-01 | Login y sesión persistente | Ingresar con `tecnico`/`campo123`; cerrar la app; abrirla | Entra directo a /visitas |
| TC-02 | Refresh transparente | API con `ACCESS_TTL_S=20`; esperar 20 s; refrescar la lista | La lista carga sin pedir login |
| TC-03 | Offline | Cargar la lista; activar modo avión; refrescar | Banner «Sin conexión…» y la lista guardada |
| TC-04 | Evidencia con permisos | Nueva visita → Tomar foto y ubicación → conceder ambos | Foto y coordenadas visibles; guarda como «Realizada» |
| TC-05 | Permiso de ubicación negado | Repetir TC-04 negando ubicación | Se conserva la foto; aviso con la ruta a Ajustes |
| TC-06 | Reglas | Eliminar (deslizar) una visita realizada | Toast con la regla; la visita sigue en la lista |
