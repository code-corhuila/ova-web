# Presupuestos de rendimiento — Bitácora de Campo

Un presupuesto se mide y, si se rompe, bloquea el release como cualquier otro defecto.

## Presupuestos y medición de v1.0.0

| Métrica | Presupuesto | Cómo se mide | v1.0.0 |
|---|---|---|---|
| Bundle inicial (JS + CSS) | Aviso 1.5 MB · **error 2 MB** | `npm run build` (presupuesto `initial` en `angular.json`: el build **falla** si se excede) | **1.21 MB** (≈ 235 kB transferidos comprimidos) |
| Estilos por componente | Aviso 2 kB · error 4 kB | `npm run build` (`anyComponentStyle`) | Dentro del límite |
| Pantallas perezosas | Cada una < 50 kB | Tabla «Lazy chunk files» del build | Lista 36.8 kB · Formulario 9.1 kB · Login 4.3 kB |
| Tamaño instalable | Registrado; todo aumento > 10 % se justifica | Tamaño del AAB/APK de release | AAB ≈ 6.7 MB · APK ≈ 7.6 MB |
| Arranque en frío hasta el primer cuadro | ≤ 2 s en un equipo de gama media | `adb shell am start -W co.edu.corhuila.bitacora/.MainActivity` (campo `TotalTime`) | **Pendiente**: medición manual en emulador/dispositivo (checklist) |
| Desplazamiento de la lista | 60 fps, sin saltos | Perfilador de Chrome sobre el WebView (`chrome://inspect`) con 200+ visitas | Diseño: virtual scroll (solo filas visibles en el DOM) |
| Carga útil de la lista | Primera respuesta pequeña | Tamaño de `GET /visitas` | 30 visitas sin foto ≈ 8 kB; **sin paginación** (ver riesgo) |
| Memoria | Estable al navegar | Perfilador de memoria de Android Studio, 20 idas y vueltas lista ↔ formulario | Diseño: ViewModels por pantalla, destruidos con ella |

## Decisiones que sostienen los números

- **Carga perezosa por pantalla** (`loadComponent` en `app.routes.ts`): el login no descarga el
  código del formulario.
- **Virtual scroll** (`@angular/cdk/scrolling`, `itemSize` 72 px = `--bc-alto-item-lista`): con
  1 000 visitas el DOM tiene ~15 filas, no 1 000.
- **Estado inmutable + signals** (ADR-001): la vista se actualiza por referencia, sin recorrer
  árboles grandes; `trackBy: porId` evita recrear filas.
- **Fotos reducidas en el origen**: `targetWidth/targetHeight 1024`, `quality 60`, y en nativo se
  usa la miniatura que entrega el plugin.

## Riesgos registrados

| Riesgo | Umbral | Acción |
|---|---|---|
| `GET /visitas` sin paginar y con fotos embebidas | > 200 visitas o > 1 MB por respuesta | Paginación en la API (`?desde=&limite=`) y fotos por URL aparte |
| Caché con fotos en Preferences | > 2 MB en `visitas.lista.v1` | ADR nuevo: fotos a archivos o SQLite (ADR-002) |

## En CI / release

1. `npm run build` aplica los presupuestos de bundle (falla el job si se exceden).
2. El job de release registra el tamaño del AAB y lo compara con el release anterior.
3. El arranque en frío se mide a mano antes de cada release y se anota en el checklist.
