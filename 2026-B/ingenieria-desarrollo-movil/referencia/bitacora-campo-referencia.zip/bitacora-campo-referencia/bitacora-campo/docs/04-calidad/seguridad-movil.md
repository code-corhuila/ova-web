# Seguridad móvil — checklist de ejecución (v1.0.0)

Complementa [`00-gobierno/reglas-de-seguridad.md`](../00-gobierno/reglas-de-seguridad.md). Se
revisa antes de cada release; el resultado de v1.0.0 queda marcado.

## Almacenamiento

- [x] Tokens solo en almacenamiento seguro: `SecureTokenStore` (Keychain / Android Keystore).
- [x] Datos sensibles borrados al cerrar sesión: tokens + caché (`SesionService.cerrar()`).
- [x] Sin respaldo en la nube de los datos de la app: `android:allowBackup="false"`.
- [ ] Caché de visitas **sin cifrar** en Preferences (nombres, direcciones, fotos). Riesgo aceptado
      en v1.0.0 (dispositivo corporativo con bloqueo de pantalla); mitigación propuesta en
      [ADR-002](../01-arquitectura/decisiones/ADR-002-persistencia-local.md).
- [x] En web (`ionic serve`) el plugin de secure storage usa `localStorage` sin cifrar: **solo
      desarrollo**; la app se distribuye como Android.

## Transporte

- [x] Release sin texto plano: `android:usesCleartextTraffic="false"` en `src/main/AndroidManifest.xml`.
- [x] Cleartext **solo en debug**: `android/app/src/debug/AndroidManifest.xml` (Gradle lo mezcla
      únicamente en `assembleDebug`). Verificable en
      `android/app/build/outputs/logs/manifest-merger-release-report.txt`.
- [x] `allowMixedContent` solo en desarrollo: `capacitor.config.ts` lo apaga con `BITACORA_RELEASE=1`.
- [x] `apiUrl` de producción HTTPS (`src/environments/environment.prod.ts`).
- [ ] *Certificate pinning* para `/auth/*`: no aplica a la API simulada; obligatorio con backend real.

## Permisos

- [x] Mínimos: `INTERNET`, `ACCESS_COARSE_LOCATION`, `ACCESS_FINE_LOCATION` (exigidos por el README
      de `@capacitor/geolocation`). Sin `CAMERA` (el README de `@capacitor/camera` no lo requiere
      sin `saveToGallery`) y sin almacenamiento externo.
- [x] *Just-in-time*: se piden al pulsar «Tomar foto y ubicación» (`core/nativo/*-capacitor.ts`).
- [x] Negación manejada: mensaje con la ruta a Ajustes; la app sigue funcionando.
- [x] GPS no obligatorio para instalar: `uses-feature … gps android:required="false"`.

iOS (si se agrega la plataforma), claves de `ios/App/App/Info.plist` según los README de los plugins:

| Clave | Texto propuesto |
|---|---|
| `NSCameraUsageDescription` | «Bitácora de Campo usa la cámara para la foto de evidencia de cada visita.» |
| `NSPhotoLibraryUsageDescription` / `NSPhotoLibraryAddUsageDescription` | Exigidas por `@capacitor/camera` aunque no se use la galería |
| `NSLocationWhenInUseUsageDescription` | «Bitácora de Campo registra dónde se hizo la visita.» |
| `NSLocationAlwaysAndWhenInUseUsageDescription` | Mismo texto (lo exige `@capacitor/geolocation`; la app no usa ubicación en segundo plano) |

## Build

- [x] Bundle web de producción minificado, sin *source maps* (`npm run build`).
- [ ] R8 / ofuscación nativa (`minifyEnabled true`): **pendiente** (ver checklist de release).
- [x] Sin llaves de API ni credenciales en el bundle ni en el repositorio; keystore fuera de git.
- [x] Sin `console.log` de peticiones, tokens ni datos personales.

## Dependencias

- [x] `npm audit --omit=dev` revisado antes del release: 1 aviso alto en `@angular/router` 22.1.x
      (GHSA-ff3f-86qr-9cv3, denegación de servicio en **SSR**). La app no usa SSR, así que no es
      explotable aquí; la actualización a Angular 22.2.x queda para el próximo sprint (brecha en el
      [checklist v1.0.0](../05-release/checklist-release-v1.0.0.md)).
- [x] Plugins no usados retirados: se quitó `@capacitor/haptics` del starter porque agregaba el
      permiso `VIBRATE` sin necesidad.
- [x] SDK de terceros revisados: solo plugins oficiales de Capacitor + `@aparajita/capacitor-secure-storage`;
      ninguno envía datos a terceros.
