package co.edu.corhuila.bitacora;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
