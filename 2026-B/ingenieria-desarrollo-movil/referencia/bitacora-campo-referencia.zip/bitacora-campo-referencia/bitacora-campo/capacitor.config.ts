import type { CapacitorConfig } from '@capacitor/cli';

// Build de release: `BITACORA_RELEASE=1 npx cap sync android` (ver docs/05-release/firma-y-tiendas.md).
const esRelease = process.env['BITACORA_RELEASE'] === '1';

const config: CapacitorConfig = {
  appId: 'co.edu.corhuila.bitacora',
  appName: 'Bitácora de Campo',
  webDir: 'www',
  android: {
    // SOLO DESARROLLO: la app se sirve desde https://localhost y la API local es http://10.0.2.2:3000.
    // Sin esto el WebView bloquea la mezcla https→http. En release va en false y la API es HTTPS.
    // El permiso de texto plano (cleartext) está en android/app/src/debug/AndroidManifest.xml,
    // que Gradle solo mezcla en los builds debug.
    allowMixedContent: !esRelease,
  },
};

export default config;
