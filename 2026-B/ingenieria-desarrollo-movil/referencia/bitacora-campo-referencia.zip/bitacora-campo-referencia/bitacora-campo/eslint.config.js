// @ts-check
const tseslint = require("typescript-eslint");
const angular = require("angular-eslint");

// Regla de dependencias entre capas (docs/01-arquitectura/capas-y-estado.md):
//   presentation → domain ← data      y      core/di es la única raíz de composición.
// ESLint la hace cumplir: `npm run lint` falla si alguien la rompe.
const FRAMEWORKS = ["@angular/*", "@ionic/*", "@capacitor/*", "@aparajita/*", "rxjs", "rxjs/*"];

module.exports = tseslint.config(
  {
    files: ["**/*.ts"],
    ignores: ["projects/**/*"],
    extends: [...angular.configs.tsRecommended],
    processor: angular.processInlineTemplates,
    rules: {
      "@angular-eslint/component-class-suffix": [
        "error",
        { suffixes: ["Page", "Component"] },
      ],
      "@angular-eslint/component-selector": [
        "error",
        { type: "element", prefix: "app", style: "kebab-case" },
      ],
      "@angular-eslint/directive-selector": [
        "error",
        { type: "attribute", prefix: "app", style: "camelCase" },
      ],
    },
  },
  {
    // domain/: TypeScript puro. De core/ solo puede usar errores y puertos (archivos sin framework).
    files: ["src/app/features/*/domain/**/*.ts"],
    ignores: ["**/*.spec.ts"],
    rules: {
      "no-restricted-imports": ["error", {
        patterns: [
          { group: FRAMEWORKS, message: "domain/ es TypeScript puro: sin Angular, Ionic, Capacitor ni RxJS." },
          { group: ["**/data/*", "**/presentation/*"], message: "domain/ no depende de data/ ni de presentation/." },
          {
            group: ["**/core/network/*", "**/core/storage/*", "**/core/sesion/*", "**/core/di/*", "**/core/theme/*",
              "**/core/nativo/*-capacitor", "**/core/nativo/nativo.tokens"],
            message: "domain/ solo usa de core/ los errores (core/errores) y los puertos (*.port, *.error).",
          },
        ],
      }],
    },
  },
  {
    // presentation/: habla con casos de uso; nunca con data/ ni con adaptadores concretos.
    files: ["src/app/features/*/presentation/**/*.ts"],
    rules: {
      "no-restricted-imports": ["error", {
        patterns: [
          { group: ["**/data/*", "@angular/common/http"], message: "presentation/ no usa HTTP ni data/: inyecta casos de uso." },
          { group: ["@capacitor/*", "@aparajita/*", "**/core/storage/*", "**/core/nativo/*-capacitor"],
            message: "presentation/ no toca plugins ni almacenamiento: van detrás de un puerto." },
        ],
      }],
    },
  },
  {
    // shared/: UI sin negocio.
    files: ["src/app/shared/**/*.ts"],
    rules: {
      "no-restricted-imports": ["error", {
        patterns: [
          { regex: "^(\\.\\./)+(features|core)/", message: "shared/ es UI sin lógica de negocio: no importa features/ ni core/." },
          { group: ["@angular/common/http"], message: "shared/ no hace peticiones." },
        ],
      }],
    },
  },
  {
    files: ["**/*.html"],
    extends: [...angular.configs.templateRecommended],
    rules: {},
  }
);
