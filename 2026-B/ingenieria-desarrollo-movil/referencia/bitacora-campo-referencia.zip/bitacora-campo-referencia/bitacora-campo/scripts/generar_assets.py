"""Genera las imágenes fuente que pide @capacitor/assets (ícono 1024 px y splash 2732 px).

Uso (desde la raíz del repo de la app):
    py -3.11 scripts/generar_assets.py
    npx -y @capacitor/assets@3 generate --android --iconBackgroundColor "#009540" --splashBackgroundColor "#009540"
"""
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont

VERDE = (0, 149, 64)  # #009540, verde institucional = --bc-color-primario
BLANCO = (255, 255, 255)
SALIDA = Path(__file__).resolve().parents[1] / "assets"


def fuente(tamano: int) -> ImageFont.FreeTypeFont | ImageFont.ImageFont:
    for nombre in ("arialbd.ttf", "DejaVuSans-Bold.ttf"):
        try:
            return ImageFont.truetype(nombre, tamano)
        except OSError:
            continue
    return ImageFont.load_default(size=tamano)


def dibujar(lado: int, destino: Path, escala_texto: float, fondo: tuple[int, int, int] | None) -> None:
    """Las iniciales «BC» centradas. Con fondo=None queda transparente (capa frontal del ícono adaptativo)."""
    img = Image.new("RGBA", (lado, lado), (*fondo, 255) if fondo else (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    d.text((lado / 2, lado / 2), "BC", fill=BLANCO, font=fuente(int(lado * escala_texto)), anchor="mm")
    img.save(destino)


def main() -> None:
    SALIDA.mkdir(exist_ok=True)
    dibujar(1024, SALIDA / "icon-only.png", 0.40, VERDE)
    # Ícono adaptativo de Android: capa frontal en la zona segura (66 %) + fondo liso.
    dibujar(1024, SALIDA / "icon-foreground.png", 0.30, None)
    Image.new("RGBA", (1024, 1024), (*VERDE, 255)).save(SALIDA / "icon-background.png")
    dibujar(2732, SALIDA / "splash.png", 0.12, VERDE)
    dibujar(2732, SALIDA / "splash-dark.png", 0.12, VERDE)
    print("assets en", SALIDA)


if __name__ == "__main__":
    main()
