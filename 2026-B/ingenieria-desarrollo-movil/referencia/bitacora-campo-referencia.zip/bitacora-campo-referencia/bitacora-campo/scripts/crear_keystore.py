"""Crea el keystore de firma de release y android/keystore.properties.

Uso (desde la raíz del repo de la app):
    py -3.11 scripts/crear_keystore.py

Reglas (docs/00-gobierno/reglas-de-seguridad.md y docs/05-release/firma-y-tiendas.md):
- La contraseña se genera con `secrets` y NUNCA se imprime ni se pasa por la consola:
  keytool la lee de variables de entorno (-storepass:env / -keypass:env), así no queda en el
  historial de la terminal ni en la lista de procesos.
- Solo queda escrita en android/keystore.properties, que está en .gitignore.
- Si el keystore ya existe NO se regenera: una llave nueva cambiaría la identidad de la app y la
  tienda rechazaría las actualizaciones.
"""
import os
import secrets
import shutil
import subprocess
from pathlib import Path

ANDROID = Path(__file__).resolve().parents[1] / "android"
KEYSTORE = ANDROID / "app" / "bitacora-release.jks"
PROPIEDADES = ANDROID / "keystore.properties"
ALIAS = "bitacora"
DNAME = "CN=Bitacora de Campo, OU=Posgrado Ingenieria para el Desarrollo Movil, O=CORHUILA, L=Neiva, ST=Huila, C=CO"


def comando_keytool() -> list[str]:
    """keytool del PATH; si no está (Windows suele traer solo `java` en el PATH), el mismo
    keytool del JDK lanzado como módulo de Java."""
    if shutil.which("keytool"):
        return ["keytool"]
    return ["java", "-m", "java.base/sun.security.tools.keytool.Main"]


def main() -> None:
    if KEYSTORE.exists():
        raise SystemExit(f"Ya existe {KEYSTORE.name}: no se regenera (cambiaría la firma de la app).")
    clave = secrets.token_urlsafe(24)
    entorno = {**os.environ, "BITACORA_KS_PASS": clave}
    subprocess.run(
        [
            *comando_keytool(), "-genkeypair", "-v",
            "-keystore", str(KEYSTORE), "-storetype", "PKCS12",
            "-alias", ALIAS, "-keyalg", "RSA", "-keysize", "4096", "-validity", "10000",
            "-storepass:env", "BITACORA_KS_PASS", "-keypass:env", "BITACORA_KS_PASS",
            "-dname", DNAME,
        ],
        check=True,
        capture_output=True,  # la salida de keytool no se muestra
        env=entorno,
    )
    PROPIEDADES.write_text(
        f"storeFile=bitacora-release.jks\nstorePassword={clave}\nkeyAlias={ALIAS}\nkeyPassword={clave}\n",
        encoding="utf-8",
    )
    print("keystore creado:", KEYSTORE)
    print("propiedades:", PROPIEDADES, "(NO se versiona; respáldelo en un gestor de secretos)")


if __name__ == "__main__":
    main()
