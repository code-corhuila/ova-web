# Bitácora de Campo — app de referencia

App de referencia del módulo **Ingeniería para el Desarrollo Móvil [G1-2026B]** (posgrado,
CORHUILA). Docente: **Jesús Ariel González Bonilla**. Registra las visitas técnicas de una
jornada con evidencia (foto obligatoria, ubicación «mejor esfuerzo») y permite consultarlas sin
señal. Es **material de apoyo**: su arquitectura y su documentación (`docs/`) son el ejemplo
trabajado del marco de gobierno móvil. **No es elegible como proyecto ABP.**

| Pieza | Versión |
|---|---|
| Ionic (`@ionic/angular`) | 9.0.6 |
| Angular (`@angular/core`) | 22.1.7 (standalone, *zoneless*, signals) |
| Capacitor (`@capacitor/core` / `android`) | 8.5.2 |
| Plugins | `@capacitor/camera` 8.2.5 · `@capacitor/geolocation` 8.2.3 · `@capacitor/preferences` 8.0.1 · `@aparajita/capacitor-secure-storage` 8.0.1 · `@angular/cdk` 22.1 |
| Pruebas | Vitest 4.0.18 (builder `@angular/build:unit-test`, jsdom) |
| Node | **≥ 24.15** (lo exige Angular CLI 22) |
| Android | JDK 21, SDK 36 (`compileSdk`/`targetSdk` 36, `minSdk` 24), Gradle 8.14.3 |

## Qué demuestra (los 8 mínimos del proyecto ABP)

| # | Mínimo | Dónde verlo |
|---|---|---|
| 1 | Ionic 8+ + Angular + Capacitor | `package.json`, [ADR-005](docs/01-arquitectura/decisiones/ADR-005-framework-angular.md) |
| 2 | Estructura por feature con capas y regla de dependencias | `src/app/features/*/{presentation,domain,data}`, `eslint.config.js`, [estructura](docs/01-arquitectura/estructura-del-proyecto.md) |
| 3 | Un solo patrón de estado en ADR y ≥ 3 ADR | [ADR-001](docs/01-arquitectura/decisiones/ADR-001-patron-de-estado.md) + 4 ADR más |
| 4 | Tabla de rutas central con guard | `src/app/app.routes.ts`, `src/app/core/sesion/auth.guard.ts`, [navegación](docs/01-arquitectura/navegacion.md) |
| 5 | Cliente HTTP único con interceptores, refresh de token, tokens en almacenamiento seguro | `src/app/core/di/core.providers.ts`, `src/app/core/network/`, `src/app/core/sesion/sesion.service.ts`, `src/app/core/storage/secure-token-store.ts` |
| 6 | Estrategia offline documentada y aplicada | `features/visitas/data/visitas-http.repository.ts`, [offline](docs/03-api-y-datos/offline.md) |
| 7 | Cámara y geolocalización como adaptadores de un puerto, permisos *just-in-time* | `src/app/core/nativo/`, `features/visitas/domain/casos-de-uso/capturar-evidencia.ts` |
| 8 | Pruebas de casos de uso y ViewModels + AAB/APK firmado + checklist | `npm run test:ci` (81), [firma](docs/05-release/firma-y-tiendas.md), [checklist v1.0.0](docs/05-release/checklist-release-v1.0.0.md) |

## Correr en el navegador

```bash
# Terminal 1 — API simulada
cd ../api-simulada && npm install && npm start          # http://localhost:3000 · usuario tecnico / campo123

# Terminal 2 — app
npm install
npm start                                               # ng serve → http://localhost:4200
```

En el navegador la cámara abre un selector de archivo (sin `@ionic/pwa-elements`) y el GPS usa
la geolocalización del navegador.

## Correr en el emulador de Android

```bash
cd ../api-simulada && npm start                         # la API escucha en 0.0.0.0:3000
# en bitacora-campo/
npx ng build --configuration development                # environment.ts → apiUrl automática
npx cap sync android
npx cap run android                                     # build debug + instala en el emulador
```

- Desde el emulador la API es **`http://10.0.2.2:3000`** (10.0.2.2 es el `localhost` del
  computador). `src/app/core/network/api-url.ts` lo resuelve solo cuando la plataforma es Android.
- Teléfono físico: misma red Wi-Fi, escriba `apiUrl: 'http://<IP-del-computador>:3000'` en
  `src/environments/environment.ts` y permita el puerto 3000 en el firewall.
- **HTTP sin TLS solo en desarrollo:** el permiso de texto plano está en
  `android/app/src/debug/AndroidManifest.xml` (Gradle lo incluye solo en builds **debug**) y
  `allowMixedContent` en `capacitor.config.ts` se apaga con `BITACORA_RELEASE=1`. El release
  usa `environment.prod.ts` (HTTPS) y `usesCleartextTraffic="false"`. Ver
  [seguridad móvil](docs/04-calidad/seguridad-movil.md).

## Comandos

| Comando | Qué hace |
|---|---|
| `npm start` | `ng serve` |
| `npm run build` | Build de producción en `www/` |
| `npm run test:ci` | Pruebas una vez (`ng test --watch=false`) |
| `npm test` | Pruebas en modo observación |
| `npm run lint` | ESLint, incluida la regla de capas |
| `py -3.11 scripts/generar_assets.py` | Fuentes de ícono y splash (Pillow) en `assets/` |
| `npx -y @capacitor/assets@3 generate --android …` | Íconos y splash en `android/app/src/main/res/` |
| `py -3.11 scripts/crear_keystore.py` | Keystore de release + `android/keystore.properties` (no versionados) |

Release firmado (AAB + APK): [docs/05-release/firma-y-tiendas.md](docs/05-release/firma-y-tiendas.md).

> **Node < 24.15:** Angular CLI 22 se niega a arrancar (`The Angular CLI requires a minimum
> Node.js version of v22.22.3 or v24.15.0`). Actualice Node a la LTS vigente. Mientras tanto, el
> mismo comando corre con `node node_modules/@angular/cli/bin/bootstrap.js <test|build|lint>`
> (salta solo la verificación de versión; úselo bajo su responsabilidad).

## Mapa del código

```
src/app/
  core/di/            raíz de composición (core.providers, auth.providers, visitas.providers)
  core/network/       api-url · interceptores (correlation-id, errores, auth+refresh, timeout) · mapear-error-http
  core/sesion/        SesionService (tokens, refresh serializado) · authGuard
  core/storage/       puertos TokenStore y CacheLocal + adaptadores (secure storage, Preferences)
  core/nativo/        puertos Camara y Ubicacion + adaptadores Capacitor · PermisoDenegadoError
  core/errores/       errores de dominio
  core/theme/         tokens.scss
  features/auth/      domain · data · presentation/login
  features/visitas/   domain (entidad, puerto, reglas, 6 casos de uso) · data (dto, mapper, repositorio con caché) · presentation (lista, form)
  shared/             estado-vacio · mensaje-error · banner-offline
  app.routes.ts       tabla de rutas central
src/testing/          dobles de prueba escritos a mano
docs/                 marco 00–05 diligenciado
```
