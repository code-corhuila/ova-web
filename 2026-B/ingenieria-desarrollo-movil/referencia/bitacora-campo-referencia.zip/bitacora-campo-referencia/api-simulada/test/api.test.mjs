import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import { once } from 'node:events';
import { mkdtemp, writeFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { crearApp } from '../server.mjs';

// Reloj controlado: las pruebas «adelantan el tiempo» sin dormir.
let ahora = Date.UTC(2026, 9, 9, 23, 0, 0);
const ACCESS_TTL_S = 60;

let server;
let base;

before(async () => {
  const dir = await mkdtemp(join(tmpdir(), 'bitacora-'));
  const dbPath = join(dir, 'db.json');
  await writeFile(dbPath, JSON.stringify({ visitas: [] }));
  server = crearApp({ dbPath, accessTtlS: ACCESS_TTL_S, refreshTtlS: 3600, reloj: () => ahora }).listen(0);
  await once(server, 'listening');
  base = `http://127.0.0.1:${server.address().port}`;
});
after(() => server.close());

const pedir = (metodo, cuerpo, token) => ({
  method: metodo,
  headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: `Bearer ${token}` } : {}) },
  body: cuerpo ? JSON.stringify(cuerpo) : undefined,
});

async function login() {
  const r = await fetch(`${base}/auth/login`, pedir('POST', { usuario: 'tecnico', clave: 'campo123' }));
  assert.equal(r.status, 200);
  return r.json();
}

test('login correcto entrega access token, refresh token y nombre', async () => {
  const s = await login();
  assert.equal(typeof s.accessToken, 'string');
  assert.equal(typeof s.refreshToken, 'string');
  assert.notEqual(s.accessToken, s.refreshToken);
  assert.equal(s.nombre, 'Técnica de campo');
});

test('login con clave equivocada responde 401', async () => {
  const r = await fetch(`${base}/auth/login`, pedir('POST', { usuario: 'tecnico', clave: 'x' }));
  assert.equal(r.status, 401);
  assert.equal((await r.json()).codigo, 'CREDENCIALES');
});

test('sin token, /visitas responde 401', async () => {
  assert.equal((await fetch(`${base}/visitas`)).status, 401);
});

test('token vencido responde 401 y /auth/refresh entrega uno nuevo que funciona', async () => {
  const { accessToken, refreshToken } = await login();
  assert.equal((await fetch(`${base}/visitas`, pedir('GET', null, accessToken))).status, 200);

  ahora += (ACCESS_TTL_S + 1) * 1000; // pasa la vida del access token
  const vencido = await fetch(`${base}/visitas`, pedir('GET', null, accessToken));
  assert.equal(vencido.status, 401);
  assert.equal((await vencido.json()).codigo, 'TOKEN_VENCIDO');

  const r = await fetch(`${base}/auth/refresh`, pedir('POST', { refreshToken }));
  assert.equal(r.status, 200);
  const nuevo = (await r.json()).accessToken;
  assert.notEqual(nuevo, accessToken);
  assert.equal((await fetch(`${base}/visitas`, pedir('GET', null, nuevo))).status, 200);
});

test('refresh token inválido o ausente responde 401', async () => {
  const r = await fetch(`${base}/auth/refresh`, pedir('POST', { refreshToken: 'no-existe' }));
  assert.equal(r.status, 401);
  assert.equal((await r.json()).codigo, 'REFRESH_INVALIDO');
  assert.equal((await fetch(`${base}/auth/refresh`, pedir('POST', {}))).status, 401);
});

test('logout revoca el refresh token', async () => {
  const { refreshToken } = await login();
  assert.equal((await fetch(`${base}/auth/logout`, pedir('POST', { refreshToken }))).status, 204);
  assert.equal((await fetch(`${base}/auth/refresh`, pedir('POST', { refreshToken }))).status, 401);
});

test('CRUD completo de una visita', async () => {
  const t = (await login()).accessToken;
  const c = await fetch(`${base}/visitas`, pedir('POST', { cliente: '  Acueducto La Plata ', estado: 'pendiente' }, t));
  assert.equal(c.status, 201);
  const v = await c.json();
  assert.ok(v.id);
  assert.equal(v.cliente, 'Acueducto La Plata');
  assert.equal(v.lat, null);
  assert.equal(v.foto, null);
  assert.ok(v.creada);

  const lista = await (await fetch(`${base}/visitas`, pedir('GET', null, t))).json();
  assert.ok(lista.some((x) => x.id === v.id));

  const uno = await fetch(`${base}/visitas/${v.id}`, pedir('GET', null, t));
  assert.equal((await uno.json()).cliente, 'Acueducto La Plata');

  const u = await fetch(`${base}/visitas/${v.id}`, pedir('PUT', {
    cliente: 'Acueducto La Plata', estado: 'realizada', foto: 'data:image/jpeg;base64,AAA', lat: 2.39, lng: -75.89,
  }, t));
  assert.equal(u.status, 200);
  const act = await u.json();
  assert.equal(act.estado, 'realizada');
  assert.equal(act.lat, 2.39);
  assert.equal(act.creada, v.creada);

  assert.equal((await fetch(`${base}/visitas/${v.id}`, pedir('DELETE', null, t))).status, 204);
  assert.equal((await fetch(`${base}/visitas/${v.id}`, pedir('GET', null, t))).status, 404);
  assert.equal((await fetch(`${base}/visitas/${v.id}`, pedir('DELETE', null, t))).status, 404);
  assert.equal((await fetch(`${base}/visitas/${v.id}`, pedir('PUT', { cliente: 'Otro', estado: 'pendiente' }, t))).status, 404);
});

test('valida el cuerpo: cliente corto, estado inválido, coordenadas a medias o JSON roto responden 400', async () => {
  const t = (await login()).accessToken;
  const casos = [
    { cliente: 'ab', estado: 'pendiente' },
    { cliente: '   ', estado: 'pendiente' },
    { cliente: 'Cliente', estado: 'otro' },
    { cliente: 'Cliente', estado: 'pendiente', lat: 2.9 },
    { cliente: 'Cliente', estado: 'pendiente', foto: 'http://x/foto.jpg' },
  ];
  for (const cuerpo of casos) {
    const r = await fetch(`${base}/visitas`, pedir('POST', cuerpo, t));
    assert.equal(r.status, 400, JSON.stringify(cuerpo));
    assert.equal((await r.json()).codigo, 'VALIDACION');
  }
  const roto = await fetch(`${base}/visitas`, { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${t}` }, body: '{mal' });
  assert.equal(roto.status, 400);
});

test('CORS: responde el preflight con 204 y permite Authorization', async () => {
  const r = await fetch(`${base}/visitas`, { method: 'OPTIONS' });
  assert.equal(r.status, 204);
  assert.equal(r.headers.get('access-control-allow-origin'), '*');
  assert.match(r.headers.get('access-control-allow-headers'), /Authorization/);
});

test('devuelve el X-Correlation-Id que envía la app', async () => {
  const r = await fetch(`${base}/auth/login`, {
    ...pedir('POST', { usuario: 'tecnico', clave: 'campo123' }),
    headers: { 'Content-Type': 'application/json', 'X-Correlation-Id': 'abc-123' },
  });
  assert.equal(r.headers.get('x-correlation-id'), 'abc-123');
});
