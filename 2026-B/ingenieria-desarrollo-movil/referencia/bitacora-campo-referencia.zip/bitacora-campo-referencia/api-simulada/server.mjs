// API simulada de Bitácora de Campo.
// - POST /auth/login    {usuario, clave}  -> {accessToken, refreshToken, nombre}
// - POST /auth/refresh  {refreshToken}    -> {accessToken}
// - POST /auth/logout   {refreshToken}    -> 204 (revoca el refresh token)
// - CRUD /visitas protegido con "Authorization: Bearer <accessToken>"
//
// SOLO PARA CLASE: tokens opacos en memoria (se pierden al reiniciar), sin HTTPS, usuario fijo.
// Una API real usaría JWT firmados o sesiones en una base de datos, TLS y contraseñas con hash.
import express from 'express';
import { copyFile, readFile, writeFile, access } from 'node:fs/promises';
import { randomUUID } from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { resolve } from 'node:path';

export const USUARIOS = [{ usuario: 'tecnico', clave: 'campo123', nombre: 'Técnica de campo' }];
export const ESTADOS = ['pendiente', 'realizada', 'cancelada'];

const ACCESS_TTL_S = Number(process.env.ACCESS_TTL_S ?? 900); // 15 min: corto a propósito
const REFRESH_TTL_S = Number(process.env.REFRESH_TTL_S ?? 7 * 24 * 3600); // 7 días

/** Devuelve el mensaje de error de validación o null si el cuerpo es válido. */
export function validarVisita(b) {
  if (!b || typeof b !== 'object') return 'cuerpo: se esperaba un objeto JSON';
  if (typeof b.cliente !== 'string' || b.cliente.trim().length < 3) return 'cliente: mínimo 3 caracteres';
  if (b.cliente.trim().length > 120) return 'cliente: máximo 120 caracteres';
  if (!ESTADOS.includes(b.estado)) return `estado: uno de ${ESTADOS.join(', ')}`;
  if (b.direccion !== undefined && (typeof b.direccion !== 'string' || b.direccion.length > 200)) {
    return 'direccion: texto de máximo 200 caracteres';
  }
  if (b.observaciones !== undefined && (typeof b.observaciones !== 'string' || b.observaciones.length > 500)) {
    return 'observaciones: texto de máximo 500 caracteres';
  }
  if (b.foto !== undefined && b.foto !== null && (typeof b.foto !== 'string' || !b.foto.startsWith('data:image/'))) {
    return 'foto: null o una imagen en data URL (data:image/...)';
  }
  const lat = b.lat ?? null;
  const lng = b.lng ?? null;
  if ((lat === null) !== (lng === null)) return 'lat/lng: ambas o ninguna';
  if (lat !== null && (typeof lat !== 'number' || lat < -90 || lat > 90)) return 'lat: número entre -90 y 90';
  if (lng !== null && (typeof lng !== 'number' || lng < -180 || lng > 180)) return 'lng: número entre -180 y 180';
  return null;
}

function limpiar(b) {
  const { cliente, direccion = '', estado, observaciones = '', foto = null, lat = null, lng = null } = b;
  return { cliente: cliente.trim(), direccion: direccion.trim(), estado, observaciones, foto, lat, lng };
}

/**
 * Crea la aplicación Express.
 * @param {object} opciones
 * @param {string} opciones.dbPath        archivo JSON con { visitas: [] }
 * @param {Array}  [opciones.usuarios]    usuarios válidos
 * @param {number} [opciones.accessTtlS]  vida del access token en segundos
 * @param {number} [opciones.refreshTtlS] vida del refresh token en segundos
 * @param {() => number} [opciones.reloj] milisegundos actuales (las pruebas lo adelantan)
 */
export function crearApp({
  dbPath,
  usuarios = USUARIOS,
  accessTtlS = ACCESS_TTL_S,
  refreshTtlS = REFRESH_TTL_S,
  reloj = () => Date.now(),
} = {}) {
  const app = express();
  const accessTokens = new Map(); // token -> { usuario, expira }
  const refreshTokens = new Map(); // token -> { usuario, expira }

  // Escrituras serializadas: dos peticiones simultáneas no se pisan el archivo.
  let cola = Promise.resolve();
  const leer = async () => JSON.parse(await readFile(dbPath, 'utf8'));
  const modificar = (fn) => {
    const tarea = cola.then(async () => {
      const db = await leer();
      const resultado = await fn(db);
      await writeFile(dbPath, JSON.stringify(db, null, 2));
      return resultado;
    });
    cola = tarea.catch(() => undefined);
    return tarea;
  };

  const emitirAccess = (usuario) => {
    const token = randomUUID();
    accessTokens.set(token, { usuario, expira: reloj() + accessTtlS * 1000 });
    return token;
  };

  app.disable('x-powered-by');

  // CORS abierto (solo clase) + preflight 204.
  app.use((req, res, next) => {
    res.set('Access-Control-Allow-Origin', '*');
    res.set('Access-Control-Allow-Headers', 'Content-Type, Authorization, X-Correlation-Id');
    res.set('Access-Control-Allow-Methods', 'GET,POST,PUT,DELETE,OPTIONS');
    res.set('Access-Control-Expose-Headers', 'X-Correlation-Id');
    if (req.method === 'OPTIONS') return res.sendStatus(204);
    next();
  });

  // Eco del correlation-id que envía la app (trazabilidad de una petición de punta a punta).
  app.use((req, res, next) => {
    const id = req.get('X-Correlation-Id');
    if (id) res.set('X-Correlation-Id', id);
    next();
  });

  app.use(express.json({ limit: '5mb' }));

  // ---------------------------------------------------------------- autenticación
  app.post('/auth/login', (req, res) => {
    const { usuario, clave } = req.body ?? {};
    const u = usuarios.find((x) => x.usuario === usuario && x.clave === clave);
    if (!u) return res.status(401).json({ error: 'Usuario o clave incorrectos', codigo: 'CREDENCIALES' });
    const refreshToken = randomUUID();
    refreshTokens.set(refreshToken, { usuario: u.usuario, expira: reloj() + refreshTtlS * 1000 });
    res.json({ accessToken: emitirAccess(u.usuario), refreshToken, nombre: u.nombre });
  });

  app.post('/auth/refresh', (req, res) => {
    const { refreshToken } = req.body ?? {};
    const r = typeof refreshToken === 'string' ? refreshTokens.get(refreshToken) : undefined;
    if (!r || r.expira <= reloj()) {
      if (r) refreshTokens.delete(refreshToken);
      return res.status(401).json({ error: 'Refresh token inválido o vencido', codigo: 'REFRESH_INVALIDO' });
    }
    res.json({ accessToken: emitirAccess(r.usuario) });
  });

  app.post('/auth/logout', (req, res) => {
    const { refreshToken } = req.body ?? {};
    if (typeof refreshToken === 'string') refreshTokens.delete(refreshToken);
    res.sendStatus(204);
  });

  const auth = (req, res, next) => {
    const token = (req.get('Authorization') ?? '').replace(/^Bearer /, '');
    const a = accessTokens.get(token);
    if (!a) return res.status(401).json({ error: 'Token inválido o ausente', codigo: 'TOKEN_INVALIDO' });
    if (a.expira <= reloj()) {
      accessTokens.delete(token);
      return res.status(401).json({ error: 'Token vencido', codigo: 'TOKEN_VENCIDO' });
    }
    next();
  };

  // ---------------------------------------------------------------------- visitas
  app.get('/visitas', auth, async (req, res) => res.json((await leer()).visitas));

  app.get('/visitas/:id', auth, async (req, res) => {
    const v = (await leer()).visitas.find((x) => x.id === req.params.id);
    if (!v) return res.status(404).json({ error: 'La visita no existe', codigo: 'NO_EXISTE' });
    res.json(v);
  });

  app.post('/visitas', auth, async (req, res) => {
    const error = validarVisita(req.body);
    if (error) return res.status(400).json({ error, codigo: 'VALIDACION' });
    const v = await modificar((db) => {
      const ahora = new Date(reloj()).toISOString();
      const nueva = { ...limpiar(req.body), id: randomUUID(), creada: ahora, actualizada: ahora };
      db.visitas.push(nueva);
      return nueva;
    });
    res.status(201).json(v);
  });

  app.put('/visitas/:id', auth, async (req, res) => {
    const error = validarVisita(req.body);
    if (error) return res.status(400).json({ error, codigo: 'VALIDACION' });
    const v = await modificar((db) => {
      const i = db.visitas.findIndex((x) => x.id === req.params.id);
      if (i < 0) return null;
      db.visitas[i] = { ...db.visitas[i], ...limpiar(req.body), actualizada: new Date(reloj()).toISOString() };
      return db.visitas[i];
    });
    if (!v) return res.status(404).json({ error: 'La visita no existe', codigo: 'NO_EXISTE' });
    res.json(v);
  });

  app.delete('/visitas/:id', auth, async (req, res) => {
    const borrada = await modificar((db) => {
      const antes = db.visitas.length;
      db.visitas = db.visitas.filter((x) => x.id !== req.params.id);
      return db.visitas.length < antes;
    });
    if (!borrada) return res.status(404).json({ error: 'La visita no existe', codigo: 'NO_EXISTE' });
    res.sendStatus(204);
  });

  app.use((req, res) => res.status(404).json({ error: 'Ruta no encontrada', codigo: 'RUTA' }));

  // JSON mal formado -> 400; cualquier otra falla -> 500 sin filtrar detalles.
  // eslint-disable-next-line no-unused-vars
  app.use((err, req, res, next) => {
    if (err?.type === 'entity.parse.failed') return res.status(400).json({ error: 'JSON mal formado', codigo: 'JSON' });
    if (err?.type === 'entity.too.large') return res.status(413).json({ error: 'Cuerpo demasiado grande', codigo: 'TAMANO' });
    console.error(err);
    res.status(500).json({ error: 'Error interno', codigo: 'INTERNO' });
  });

  return app;
}

if (process.argv[1] && fileURLToPath(import.meta.url) === resolve(process.argv[1])) {
  const port = Number(process.env.PORT ?? 3000);
  const dbPath = process.env.DB ?? fileURLToPath(new URL('./db.json', import.meta.url));
  try {
    await access(dbPath);
  } catch {
    await copyFile(fileURLToPath(new URL('./db.semilla.json', import.meta.url)), dbPath);
  }
  crearApp({ dbPath }).listen(port, '0.0.0.0', () =>
    console.log(`API simulada en http://localhost:${port} · access ${ACCESS_TTL_S}s · usuario de prueba en el README`));
}
