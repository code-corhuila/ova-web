# API simulada — Bitácora de Campo

Backend de juguete para la app de referencia **Bitácora de Campo** del módulo
*Ingeniería para el Desarrollo Móvil [G1-2026B]* (CORHUILA, posgrado). Node 24 + Express 5,
datos en un archivo JSON. **Solo para clase**: tokens en memoria, sin HTTPS, usuario fijo.

```bash
npm install
npm start          # http://localhost:3000  (crea db.json desde db.semilla.json si no existe)
npm test           # node --test: 10 pruebas
npm run reset      # restaura db.json con las 30 visitas semilla
```

Usuario de prueba: **`tecnico`** · clave **`campo123`**.

| Variable | Por defecto | Para qué |
|---|---|---|
| `PORT` | `3000` | Puerto HTTP |
| `ACCESS_TTL_S` | `900` (15 min) | Vida del access token. Póngalo en `20` para ver el refresh en vivo |
| `REFRESH_TTL_S` | `604800` (7 días) | Vida del refresh token |
| `DB` | `./db.json` | Archivo de datos |

```bash
ACCESS_TTL_S=20 npm start     # Git Bash: el access token vence a los 20 s
```

## Contrato

| Método y ruta | Cuerpo | Respuesta |
|---|---|---|
| `POST /auth/login` | `{usuario, clave}` | `200 {accessToken, refreshToken, nombre}` · `401` |
| `POST /auth/refresh` | `{refreshToken}` | `200 {accessToken}` · `401` si es inválido o venció |
| `POST /auth/logout` | `{refreshToken}` | `204` (revoca el refresh token) |
| `GET /visitas` | — | `200 Visita[]` |
| `GET /visitas/:id` | — | `200 Visita` · `404` |
| `POST /visitas` | `VisitaEntrada` | `201 Visita` · `400` |
| `PUT /visitas/:id` | `VisitaEntrada` | `200 Visita` · `400` · `404` |
| `DELETE /visitas/:id` | — | `204` · `404` |

Todo `/visitas*` exige `Authorization: Bearer <accessToken>`; sin token, con token inválido o
vencido responde `401`. Los errores tienen la forma `{error, codigo}` (`CREDENCIALES`,
`TOKEN_INVALIDO`, `TOKEN_VENCIDO`, `REFRESH_INVALIDO`, `VALIDACION`, `NO_EXISTE`, `JSON`).
CORS abierto (`*`) con preflight `204`; el encabezado `X-Correlation-Id` que manda la app vuelve
en la respuesta.

```ts
type EstadoVisita = 'pendiente' | 'realizada' | 'cancelada';
interface VisitaEntrada {            // POST y PUT
  cliente: string;                   // 3..120 caracteres (se recortan espacios)
  estado: EstadoVisita;
  direccion?: string;                // ≤ 200
  observaciones?: string;            // ≤ 500
  foto?: string | null;              // data URL "data:image/..." (≤ 5 MB el cuerpo)
  lat?: number | null; lng?: number | null;   // ambas o ninguna
}
interface Visita extends Required<VisitaEntrada> { id: string; creada: string; actualizada: string; }
```

## Desde el teléfono

- **Emulador de Android:** la API es `http://10.0.2.2:3000` (10.0.2.2 es el `localhost` del computador).
- **Teléfono físico:** `http://<IP-del-computador>:3000`, en la misma red Wi-Fi, con el puerto
  3000 permitido en el firewall.
- HTTP sin TLS solo funciona porque la app de referencia habilita *cleartext* en **desarrollo**;
  ver `../bitacora-campo/docs/04-calidad/seguridad-movil.md`.
