# Estructura de la carpeta `docs/` del proyecto

> **Instrucción:** crea esta estructura en la raíz del repositorio de la pareja **antes** de
> escribir código de producto. Es el marco de gobierno móvil del curso aplicado a tu app:
> seis secciones, de 00 Gobierno a 05 Release, que se diligencian en ese orden. Borra los
> bloques «Instrucción» cuando la estructura exista.

## Árbol del repositorio

~~~text
mi-app/                                   raíz del repositorio de la pareja
├── README.md                             qué es la app y cómo ejecutarla y probarla
├── docs/
│   ├── README.md                         índice del marco y estado de cada sección
│   ├── 00-gobierno/
│   │   ├── README.md                     acuerdos de la pareja y roles
│   │   ├── definicion-de-listo.md        (desde 00-definicion-de-listo.md)
│   │   ├── definicion-de-hecho.md        (desde 00-definicion-de-hecho.md)
│   │   ├── convenciones-git.md           (desde 00-convenciones-git.md)
│   │   ├── reglas-de-seguridad.md        reglas no negociables de la app
│   │   ├── backlog.md                    historias de usuario priorizadas (MoSCoW)
│   │   ├── _plantilla-retro-sprint.md    (desde 00-plantilla-retro-sprint.md)
│   │   └── retros/                       sprint-01.md, sprint-02.md …
│   ├── 01-arquitectura/
│   │   ├── README.md
│   │   ├── estructura-del-proyecto.md    árbol real de src/app y sus reglas
│   │   ├── capas-y-estado.md             presentation → domain ← data y patrón de estado
│   │   ├── navegacion.md                 tabla de rutas (espejo de app.routes.ts) y guards
│   │   ├── _plantilla-feature.md         (desde 01-plantilla-feature.md)
│   │   ├── _plantilla-pantalla.md        (desde 01-plantilla-pantalla.md)
│   │   ├── features/                     una ficha por feature
│   │   ├── pantallas/                    una ficha por pantalla
│   │   └── decisiones/
│   │       ├── README.md                 registro de ADR
│   │       ├── _plantilla-adr.md         (desde 01-plantilla-adr.md)
│   │       └── registros/                ADR-001-patron-de-estado.md …
│   ├── 02-codigo-y-ui/
│   │   ├── README.md
│   │   ├── estandares-de-codigo.md
│   │   ├── sistema-de-diseno.md          tokens (variables CSS de Ionic) y modos md/ios
│   │   ├── accesibilidad.md
│   │   ├── i18n.md
│   │   ├── _plantilla-componente.md      (desde 02-plantilla-componente.md)
│   │   └── componentes/
│   ├── 03-api-y-datos/
│   │   ├── README.md
│   │   ├── red.md                        cliente HTTP único e interceptores
│   │   ├── autenticacion.md              tokens, refresh y cierre de sesión
│   │   ├── persistencia.md               almacén local elegido y migraciones
│   │   ├── offline.md                    estrategia sin conexión por feature
│   │   ├── _plantilla-integracion-endpoint.md
│   │   ├── _plantilla-entidad-local.md
│   │   ├── endpoints/
│   │   └── entidades/
│   ├── 04-calidad/
│   │   ├── README.md
│   │   ├── estrategia-de-pruebas.md
│   │   ├── presupuestos-de-rendimiento.md
│   │   ├── seguridad-movil.md            checklist previo a cada release
│   │   ├── _plantilla-caso-de-prueba.md  (desde 04-plantilla-caso-de-prueba.md)
│   │   └── casos/
│   └── 05-release/
│       ├── README.md
│       ├── ci-cd.md
│       ├── firma-y-tiendas.md
│       ├── observabilidad.md
│       ├── _plantilla-checklist-release.md
│       └── releases/                     v1.0.0.md …
└── src/app/                              ver «Árbol del código» abajo
~~~

## Árbol del código (Ionic + Angular + Capacitor)

~~~text
src/app/
├── core/                       transversal a todas las features
│   ├── di/                     providers y tokens de inyección (raíz de composición)
│   ├── network/                cliente HTTP único e interceptores (token y refresh, timeout, errores)
│   ├── storage/                puertos y adaptadores: almacenamiento seguro y caché local
│   ├── nativo/                 puertos de capacidades nativas y sus adaptadores Capacitor
│   └── theme/                  tokens de diseño (o src/theme/variables.scss)
├── features/
│   └── <feature>/              kebab-case: registro-pedidos/
│       ├── presentation/       páginas, componentes propios y ViewModel (state holder)
│       ├── domain/             entidades, casos de uso e interfaces de repositorio
│       └── data/               repositorios, DTO, mappers y fuentes remota y local
├── shared/                     componentes de UI reutilizables, sin lógica de negocio
├── app.routes.ts               tabla de rutas central y guards
└── app.config.ts               providers raíz: router, HttpClient con interceptores
~~~

Reglas que el árbol debe cumplir:

- Una feature = una carpeta en `features/`. Ninguna feature importa de otra: lo común va a
  `core/` o a `shared/`.
- `domain/` no importa nada de Angular, de `HttpClient` ni de Capacitor.
- `presentation/` habla con `domain/` (casos de uso o interfaces), nunca con `data/`.
- Los plugins de Capacitor solo se importan dentro de un adaptador.

## De dónde sale cada archivo del paquete

| Archivo del paquete | Dónde va en tu repositorio | Tipo | Hito |
|---------------------|----------------------------|------|------|
| `00-definicion-de-listo.md` | `docs/00-gobierno/definicion-de-listo.md` | Acuerdo (una vez) | H1 |
| `00-definicion-de-hecho.md` | `docs/00-gobierno/definicion-de-hecho.md` | Acuerdo (una vez) | H1 |
| `00-convenciones-git.md` | `docs/00-gobierno/convenciones-git.md` | Acuerdo (una vez) | H1 |
| `00-plantilla-retro-sprint.md` | `docs/00-gobierno/_plantilla-retro-sprint.md` | Plantilla (se copia) | H1 → H4 |
| `01-plantilla-adr.md` | `docs/01-arquitectura/decisiones/_plantilla-adr.md` | Plantilla (se copia) | H1, H2 |
| `01-plantilla-feature.md` | `docs/01-arquitectura/_plantilla-feature.md` | Plantilla (se copia) | H1 |
| `01-plantilla-pantalla.md` | `docs/01-arquitectura/_plantilla-pantalla.md` | Plantilla (se copia) | H1 |
| `02-plantilla-componente.md` | `docs/02-codigo-y-ui/_plantilla-componente.md` | Plantilla (se copia) | H2 |
| `03-plantilla-integracion-endpoint.md` | `docs/03-api-y-datos/_plantilla-integracion-endpoint.md` | Plantilla (se copia) | H2 |
| `03-plantilla-entidad-local.md` | `docs/03-api-y-datos/_plantilla-entidad-local.md` | Plantilla (se copia) | H2 |
| `04-plantilla-caso-de-prueba.md` | `docs/04-calidad/_plantilla-caso-de-prueba.md` | Plantilla (se copia) | H3 |
| `05-plantilla-checklist-release.md` | `docs/05-release/_plantilla-checklist-release.md` | Plantilla (se copia) | H3, H4 |

> **Instrucción:** una plantilla (`_plantilla-*.md`) **nunca se edita en su sitio**. Se
> copia, se renombra (`_plantilla-feature.md` → `features/registro-pedidos.md`), se
> diligencia, se le borran los bloques «Instrucción» y se registra en la tabla del
> `README.md` de su sección.

## Documentos sin plantilla: qué debe responder cada uno

| Documento | Debe responder | Hito |
|-----------|----------------|------|
| `00-gobierno/README.md` | ¿Cómo planea, estima y cierra el trabajo la pareja? ¿Quién hace qué? | H1 |
| `00-gobierno/reglas-de-seguridad.md` | ¿Qué reglas de secretos, transporte, datos y permisos son innegociables? | H1 |
| `00-gobierno/backlog.md` | ¿Qué historias (≥ 10) componen el producto y en qué prioridad? | H1 |
| `01-arquitectura/estructura-del-proyecto.md` | ¿Dónde va el código de una feature nueva? | H1 |
| `01-arquitectura/capas-y-estado.md` | ¿Qué capa puede depender de cuál? ¿Qué único patrón de estado se usa? | H1 |
| `01-arquitectura/navegacion.md` | ¿Qué rutas existen, qué argumentos piden y cuáles protege el guard? | H1 |
| `02-codigo-y-ui/estandares-de-codigo.md` | ¿Cómo se nombra el código y cómo se manejan los errores y la asincronía? | H2 |
| `02-codigo-y-ui/sistema-de-diseno.md` | ¿De dónde salen colores, espaciados y tipografía? ¿Cómo se ve en md e ios? | H2 |
| `02-codigo-y-ui/accesibilidad.md` y `i18n.md` | ¿Cómo se garantiza que la app sea accesible? ¿Cómo se centralizan los textos? | H2 |
| `03-api-y-datos/red.md` y `autenticacion.md` | ¿Cómo se hacen y reintentan las peticiones? ¿Dónde viven los tokens y cómo se refrescan? | H2 |
| `03-api-y-datos/persistencia.md` y `offline.md` | ¿Qué se guarda localmente? ¿Qué pasa sin conexión en cada feature? | H2 |
| `04-calidad/estrategia-de-pruebas.md` | ¿Qué se prueba, en qué nivel y cuánto? | H3 |
| `04-calidad/presupuestos-de-rendimiento.md` | ¿Qué presupuestos tiene la app y cómo se detecta una regresión? | H3 |
| `04-calidad/seguridad-movil.md` | ¿Qué se revisa en seguridad antes de cada release? | H3 |
| `05-release/ci-cd.md` y `firma-y-tiendas.md` | ¿Cómo se convierte un commit en un artefacto firmado? ¿Dónde vive la llave? | H3 |
| `05-release/observabilidad.md` | ¿Cómo se observa la salud de la app en producción? | H3 |
