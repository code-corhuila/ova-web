# Retrospectiva — Sprint [N]

> **Instrucción:** copia este archivo a `docs/00-gobierno/retros/sprint-NN.md`. Una por
> sprint; en este módulo, como mínimo una al cerrar cada hito (H1, H2 y H3). La última
> alimenta la reflexión del Documento ABP. Borra este bloque al diligenciarla.

- **Sprint:** [N]
- **Hito del curso:** H1 | H2 | H3
- **Fecha:** AAAA-MM-DD
- **Participantes:** [nombres]

---

## Foto del sprint

| Métrica | Valor |
|---------|-------|
| Puntos comprometidos | [n] |
| Puntos completados (cumplen la DoD) | [n] |
| Puntos arrastrados al siguiente sprint | [n] |
| Pruebas unitarias en verde | [n de n] |
| Sesiones sin fallos (si ya hay release) | [%] |

---

## Qué salió bien

- [Ítem]

## Qué no salió bien

- [Ítem]

## Retroalimentación recibida y qué hacemos con ella

| Retroalimentación (tutor, clínica o foro) | Decisión | ¿Entra a la trazabilidad del Documento ABP? |
|-------------------------------------------|----------|---------------------------------------------|
| [qué nos dijeron] | [qué cambiamos o por qué no] | Sí / No |

## Qué vamos a cambiar (acciones)

| Acción | Responsable | Para |
|--------|-------------|------|
| [Acción concreta y verificable] | [nombre] | Sprint [N+1] |

---

> Al empezar la siguiente retro, revisen primero las acciones de esta. Una acción sin
> terminar se arrastra con una razón o se descarta de forma explícita.
